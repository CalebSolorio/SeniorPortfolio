import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

/**
 * This class is a singleton of the Election class. It holds all of the election data.
 * @author Austin Brinegar
 * @Version 1.0 (Mar 7 2017)
 */
public class Election {
    private List<Candidate> candidates;
    private List<PollingPlace> pollingPlaces;
    private boolean isOpen = true;
    private static Election instance = null;

    //private constructor method to be used in getInstance()
    private Election() throws IOException{
        candidates = readCandidates();
        pollingPlaces = new ArrayList<>();
        isOpen = true;
        instance = this;
    }

    //reads candidates from the list
    private List readCandidates() throws IOException{
        List<String> sList = new ArrayList<>();
        List<Candidate> cList = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new FileReader("candidates.txt"));
        String sentinel = "";
        while (sentinel != null) {
            try {
                sentinel = reader.readLine();
                if(sentinel != null) {
                    sList.add(sentinel);
                }
            }
            catch(NullPointerException e) {
                reader.close();
                break;
            }
        }
        for(String s: sList){
            String[] party = s.split(",");
            cList.add(Candidate.getInstance(party[0], Party.fromShortName(party[1])));
        }
        return cList;

    }

    public static Election getInstance() throws IOException{
        if(instance == null){
            instance = new Election();
            return instance;
        }
        return instance;
    }

    /**
     * method to add an instance of a poling place to the list
     * @param name The name of the polling place to add
     */
    public void addPollingPlace(String name) throws IOException{
        PollingPlace p = PollingPlace.getInstance(name);
        pollingPlaces.add(p);
    }

    /**
     * Method to set isOpen to false
     */
    public static void closePolls() throws IOException {
        Election.getInstance().isOpen = false;
    }

    /**
     * Methood to sum up votes per candidate for the overall election
     * @return winner of election
     */
    public Map<Candidate, Integer> getTotalResults() throws IOException {
        Map<Candidate, Integer> newMap = new HashMap<>();
        for(PollingPlace p: pollingPlaces) {
            Map<Candidate, Integer> temp = p.collectVotes();
            for (Candidate c : temp.keySet()) {
                if (candidates.contains(c)) {
                    for (Candidate c2 : candidates) {
                        if (c.matches(c2.getName())) {
                            c = c2;
                        }
                    }
                    newMap.put(c, newMap.containsKey(c) ? newMap.get(c) + temp.get(c) : temp.get(c));
                }
            }
        }
        return newMap;
    }

    /**
     * In the result of a tie, this method is invoked to remove a candidate from the running so that his votes may be
     * split among the Candidates still in the election.
     * @param candidate Candidate to be removed
     */
    public void eliminate(Candidate candidate){
        candidates.remove(candidate);
        for(PollingPlace p: pollingPlaces){
            p.eliminateCandidate(candidate);
        }
    }

    /**
     * Getter for pollingPlaces
     * @return list of polling places
     */
    public List<PollingPlace> getPollingPlaces() {
        return pollingPlaces;
    }

    /**
     * Getter for isOpen
     * @return isOpen, the boolean value determining whether the election is ongoing or closed.
     */
    public boolean isOpen() {
        return isOpen;
    }


}
