import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

/**
 * This class represents a single polling place.
 * @author Caleb Solorio
 * @author Austin Brinegar (eliminateCandidate)
 * @version 1.0 (Mar 1 2017)
 */

public class PollingPlace {
    private static Map instances = new HashMap<String, PollingPlace>();
    private final String name;
    private Map<Vote, Integer> votes;

    // Create instance of PollingPlace.
    private PollingPlace(String name, String fileName) throws IOException {
        this.name = name;
        String filePath = "ballots-"+fileName + ".txt";
        votes = readData(filePath);
    }

    /**
     * Return an instance of PollingPlace.
     * @param name The name of the polling place.
     * @throws IllegalArgumentException if no name is provided.
     * @throws IOException if no file matching the given name is found.
     * @return an instance of PollingPlace.
     */
    public static PollingPlace getInstance(String name) throws IllegalArgumentException, IOException{
        if(name.length() > 0) {
            String fileName = name.toLowerCase().replace(' ', '-');

            if(instances.containsKey(fileName)) {
                return (PollingPlace) instances.get(fileName);
            }

            instances.put(name, new PollingPlace(name, fileName));
            
            return (PollingPlace) instances.get(name);
        } else {
            throw new IllegalArgumentException("No name provided");
        }
    }

    /**
     * Collect the most-desired candidate from all voters.
     * @return a list of votes.
     */
    public Map collectVotes() { //votes that start with the correct candidate, but have a different second are not being added as the same
        Map<Candidate, Integer> results = new HashMap<>();
        Iterator<Vote> iterator = votes.keySet().iterator();
        while(iterator.hasNext()) {
            Vote vote = iterator.next();
            Candidate candidate = vote.getNextCandidate();
            results.put(candidate, results.containsKey(candidate) ? results.get(candidate) + votes.get(vote) : votes.get(vote));
        }
        return results;
    }

    public String getName() { return name; }

    /**
     * Eliminates a specific candidate from the race.
     * @param candidate The candidate to eliminate.
     */
    public void eliminateCandidate(Candidate candidate) {
        List<Vote> voteList = new ArrayList<Vote>(votes.keySet());
        List<Integer> numList = new ArrayList<Integer>(votes.values());
        Map<Vote, Integer> map = new HashMap<>();

        for(int i = 0; i < voteList.size(); i++) {
            Vote v = voteList.get(i);
            int voteNum = numList.get(i);
            v.eliminateCandidate(candidate);
            map.put(v, map.containsKey(v) ? map.get(v) + voteNum : voteNum);
        }

        votes = map;
    }

    // Read poling data from file.
    // Throws IOException if no file is found
    private Map readData(String filePath) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(filePath));
        Map<Vote, Integer> map = new HashMap<>();

        while (true) {
            try {
                Vote vote = new Vote(reader.readLine());
                //System.out.println(vote.hashCode());
                map.put(vote, map.containsKey(vote) ? map.get(vote) + 1 : 1);
            } catch(NullPointerException e) {
                reader.close();
                break;
            }
        }



        return map;
    }
}
