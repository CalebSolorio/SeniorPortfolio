
/**
 * This enum specifies political parties.
 * @author Caleb Solorio
 * @version 1.0 (Mar 1 2017)
 */

public enum Party {
    REPUBLICAN,
    DEMOCRAT,
    LIBERTARIAN,
    GREENPARTY,
    CONSTITUTIONPARTY,
    TEAPARTY,
    PIRATEPARTY,
    UNKNOWN;

    /**
     * Creates a Party instance based on the name given.
     * @param name The abbreviated name of the party.
     * @return the correlating Party object.
     */
    public static Party fromShortName(String name) {
        switch (name) {
            case "REP":
                return Party.REPUBLICAN;
            case "DEM":
                return Party.DEMOCRAT;
            case "LIB":
                return Party.LIBERTARIAN;
            case "GRN":
                return Party.GREENPARTY;
            case "CNS":
                return Party.CONSTITUTIONPARTY;
            case "TEA":
                return Party.TEAPARTY;
            case "ARR":
                return Party.PIRATEPARTY;
            default:
                return Party.UNKNOWN;
        }
    }

    /**
     * Gets an abbreviation of this objects political party.
     * @return a 3 letter string specifying the party.
     */
    public String getShortName() {
        switch (this) {
            case REPUBLICAN:
                return "REP";
            case DEMOCRAT:
                return "DEM";
            case LIBERTARIAN:
                return "LIB";
            case GREENPARTY:
                return "GRN";
            case CONSTITUTIONPARTY:
                return "CNS";
            case TEAPARTY:
                return "TEA";
            case PIRATEPARTY:
                return "ARR";
            default:
                return "???";
        }
    }
}
