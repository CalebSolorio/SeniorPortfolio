import java.util.*;

/**
 * This class specifies an individual's vote.
 * @author Caleb Solorio
 * @version 1.0 (Mar 1 2017)
 */

public class Vote {
    private List<Candidate> candidates;

    /**
     * Creates a new Vote based on a given string.
     * @param candidateString The string of desired candidates, separated by commas.
     */
    public Vote(String candidateString) {
        if(candidateString.length() > 0) {
            candidates = new ArrayList<>();
            String[] candidateArr = candidateString.split(",");
            for(String string: candidateArr) {
                candidates.add(Candidate.getInstance(string, Party.UNKNOWN));
            }
        } else {
            throw new IllegalArgumentException("Empty string provided");
        }
    }

    /**
     * Eliminates a candidate from the vote list.
     * @param candidate The candidate to eliminate
     */
    public void eliminateCandidate(Candidate candidate) throws NoSuchElementException {
        for(int i = 0; i < candidates.size(); i++) {
            if(candidate.equals(candidates.get(i))) {
                candidates.remove(i);
                return;
            }
        }
        throw new NoSuchElementException("No candidate found");
    }

    /**
     * Gets the name of the most-desired candidate.
     * @return the string at the beginning of the list.
     */
    public Candidate getNextCandidate() throws IndexOutOfBoundsException {
        return candidates.get(0);
    }

    public Candidate getCandidate(int i) throws IndexOutOfBoundsException {
        return candidates.get(i);
    }

    /**
     *
     * @param o Object to test equality for.
     * @return true if the objects are equal, false otherwise.
     */
    public boolean equals(Object o) {
        if (o != null && getClass() == o.getClass()) {
            return hashCode() == o.hashCode();
        } else {
            return false;
        }
    }

    /**
     * Calculates this object's hash code.
     * @return the integer hash code.
     */
    public int hashCode() {
        int code = 0;

        for(int i = 0; i < candidates.size(); i++) {
            code += i * candidates.get(i).hashCode();
        }

        return code;
    }
}
