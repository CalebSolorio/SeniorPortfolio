import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import static jdk.nashorn.internal.objects.NativeMath.min;

/**
 * This class details a specific candidate.
 * @author Caleb Solorio
 * @version 1.0 (Mar 1 2017)
 */

public class Candidate {
    private static Map<Integer, Candidate> instances = new HashMap();
    private final String name;
    private final Party party;

    // Creates an instance of Candidate.
    private Candidate(String name, Party party) {
        this.name = name;
        this.party = party;
    }

    /**
     * Returns a instance of Candidate.
     * @param name The name of the candidate.
     * @param party The political party the candidates identifies with.
     * @return a Candidate instance.
     */
    public static Candidate getInstance(String name, Party party) {
        if(name.length() > 0 && party != null) {
            int hash = hashString(name);

            if(!instances.containsKey(hash)) {
                instances.put(hash, new Candidate(name, party));
            }

            return instances.get(hash);
        } else {
            throw new IllegalArgumentException("Both name and party must be provided");
        }
    }

    /**
     * Gets the name of this candidate.
     * @return this object's name value.
     */
    public String getName() {
        return name;
    }

    /**
     * Gets the name of this candidate's political party.
     * @return the short name of this objects party variable.
     */
    public String getPartyName() {
        return party.getShortName();
    }

    /**
     * Compare a name to this candidate's name and determine if it matches.
     * @param name The name to compare to this object's name value.
     * @return true if the string matches this candidate's name; otherwise, false.
     */
    public boolean matches(String name) {
        return minDistance(this.name, name) <= 3;
    }

    /**
     * Compare two names and determine if they match.
     * @param name1 The first name to compare.
     * @param name2 The second name to compare.
     * @return true if the string matches this candidate's name; otherwise, false.
     */
    public static boolean matches(String name1, String name2) {
        return minDistance(name1, name2) <= 3;
    }

    /**
     * Determines if this object is equal to the given object.
     * @param o The object to compare.
     * @return true if the objects are equal, false otherwise.
     */
    public boolean equals(Object o) {
        if (o != null && getClass() == o.getClass()) {
            return hashCode() == o.hashCode();
        } else {
            return false;
        }
    }

    /**
     * Calculates the hashcode of this object.
     * @return the corresponding integer.
     */
    public int hashCode() {
        return hashString(name);
    }

    // Creates a hashcode when given a string.
    private static int hashString(String string) {
        int hash = 0;
        for (int i = 0; i < string.length(); i++) {
            hash = 31 * hash + string.charAt(i);
        }
        return hash;
    }

    // Calculates and returns the edit distance of two strings.
    private static int minDistance(String s1, String s2) {
        int m = s1.length();
        int n = s2.length();
        int d[][] = new int[m+1][n+1];
        for(int i = 1 ; i <= m ; i++)
            d[i][0] = i;
        for(int j = 1 ; j <= n ; j++)
            d[0][j] = j;
        for(int j = 1 ; j <= n; j++){
            for(int i = 1 ; i <= m; i++){
                int cost = (s1.charAt(i-1) == s2.charAt(j-1)) ? 0 : 1;
                d[i][j] = Math.min(d[i-1][j] + 1, Math.min(d[i][j-1] + 1, d[i-1][j-1] + cost));
            }
        }
        return d[m][n];
    }
}
