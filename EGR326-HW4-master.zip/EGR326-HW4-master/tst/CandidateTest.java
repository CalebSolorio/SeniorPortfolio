import org.junit.Assert;
import org.junit.Test;

/**
 * This class contains unit tests for the Candidate class.
 * @author Caleb Solorio
 * @version 1.0 (Mar 1 2017)
 */

public class CandidateTest {
    /**
     * Tests the constructor of the Candidate class.
     */
    @Test
    public void getInstanceTest() {
        Candidate candidate = Candidate.getInstance("Donald Trump", Party.REPUBLICAN);

        constructorHelper("", Party.DEMOCRAT);
        constructorHelper("Hilary Clinton", null);
    }

    // Helps constructorTest test for invalid uses of Candidate's constructor.
    private void constructorHelper(String name, Party party) {
        try {
            Candidate candidate = Candidate.getInstance(name, party);
            Assert.fail();
        } catch (IllegalArgumentException e) {}
    }

    /**
     * Tests the getter methods of the Candidate class.
     */
    @Test
    public void getterTest() {
        Candidate candidate = Candidate.getInstance("Mikie Han", Party.UNKNOWN);
        String name = candidate.getName();
        String party = candidate.getPartyName();

        Assert.assertEquals("Incorrect name", "Mikie Han", name);
        Assert.assertEquals("Incorrect party", "???", party);
    }

    /**
     * Tests the matches() methods of the Candidate class.
     */
    @Test
    public void matchesTest() {
        Candidate candidate = Candidate.getInstance("Caleb", Party.UNKNOWN);
        boolean match1 = candidate.matches("Caleb");
        boolean match2 = candidate.matches("caleb");
        boolean match3 = candidate.matches("caled");
        boolean match4 = candidate.matches("le");
        boolean match5 = candidate.matches("e");

        String name = "Caleb";
        boolean match6 = Candidate.matches(name, "Caleb");
        boolean match7 = Candidate.matches(name, "caleb");
        boolean match8 = Candidate.matches(name, "caled");
        boolean match9 = Candidate.matches(name, "le");
        boolean match10 = Candidate.matches(name, "e");

        Assert.assertTrue("match1 should be true", match1);
        Assert.assertTrue("match2 should be true", match2);
        Assert.assertTrue("match3 should be true", match3);
        Assert.assertTrue("match4 should be true", match4);
        Assert.assertFalse("match5 should be true", match5);
        Assert.assertTrue("match6 should be true", match6);
        Assert.assertTrue("match7 should be true", match7);
        Assert.assertTrue("match8 should be true", match8);
        Assert.assertTrue("match9 should be true", match9);
        Assert.assertFalse("match10 should be true", match10);
    }

    /**
     * Tests the equals() and hashCode() method of the Candidate class.
     */
    @Test
    public void equalsHashCodeTest() {
        Candidate c1 = Candidate.getInstance("A", Party.REPUBLICAN);
        Candidate c2 = Candidate.getInstance("B", Party.DEMOCRAT);
        Candidate c3 = Candidate.getInstance("A", Party.PIRATEPARTY);

        Assert.assertTrue("c1 and c2 should both reference the same place in memory", c1 == c3);
        Assert.assertTrue("c1 should equal c3", c1.equals(c3));
        Assert.assertTrue("c3 should equal c1", c3.equals(c1));
        Assert.assertTrue("The hash codes of c1 and c3 should be equal",
                c1.hashCode() == c3.hashCode());
        Assert.assertTrue("The hash code of c1 should equal 65", c1.hashCode() == 65);

        Assert.assertFalse("c1 and c2 should both reference the same place in memory", c2 == c3);
        Assert.assertFalse("c1 should not equal c2", c1.equals(c2));
        Assert.assertFalse("c2 should not equal c3", c2.equals(c3));
        Assert.assertFalse("c1 should not equal null", c1.equals(null));
        Assert.assertFalse("The hash codes of c1 and c2 should not be equal",
                c1.hashCode() == c2.hashCode());
        Assert.assertFalse("The hash codes of c3 and c3 should not be equal",
                c2.hashCode() == c3.hashCode());
        Assert.assertFalse("c1 should not equal 65", c1.equals(65));
    }
}
