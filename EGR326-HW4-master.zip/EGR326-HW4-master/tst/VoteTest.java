import org.junit.Assert;
import org.junit.Test;

import java.util.NoSuchElementException;

/**
 * This class contains unit tests for the Vote class.
 * @author Caleb Solorio
 * @version 1.0 (Mar 1 2017)
 */

public class VoteTest {
    /**
     * Tests both a legitimate and illegitimate use of the Vote constructor.
     */
    @Test
    public void constructorTest() {
        Vote vote = new Vote("Caleb,Anthony,Solorio");
        vote = new Vote("Caleb Anthony Solorio");
        try {
            vote = new Vote("");
            Assert.fail();
        } catch (IllegalArgumentException e) {}
    }

    /**
     * Tests both the getNextCandidate() and eliminateCandidate() methods of the Vote class.
     */
    @Test
    public void manipulateVote() {
        Vote vote = new Vote("Caleb,Anthony,Solorio,Austin,Thomas,Brinegar");

        Candidate candidate1 = vote.getNextCandidate();
        vote.eliminateCandidate(candidate1);
        Candidate candidate2 = vote.getNextCandidate();
        vote.eliminateCandidate(candidate2);
        Candidate candidate3 = Candidate.getInstance("Austin", Party.UNKNOWN);
        vote.eliminateCandidate(candidate3);

        try {
            vote.eliminateCandidate(candidate3);
            Assert.fail();
        } catch (NoSuchElementException e){}

        Candidate candidate4 = vote.getNextCandidate();
        vote.eliminateCandidate(candidate4);

        vote.eliminateCandidate(vote.getNextCandidate());
        vote.eliminateCandidate(vote.getNextCandidate());

        try {
            candidate1 = vote.getNextCandidate();
            Assert.fail();
        } catch (IndexOutOfBoundsException e){}

        Assert.assertEquals("Candidate1 should be 'Caleb'", "Caleb", candidate1.getName());
        Assert.assertEquals("Candidate2 should be 'Anthony'", "Anthony", candidate2.getName());
        Assert.assertEquals("Candidate3 should be 'Austin'", "Austin", candidate3.getName());
        Assert.assertEquals("Candidate4 should be 'Solorio'", "Solorio", candidate4.getName());
    }

    /**
     * Tests the equals() and hashCode() method of the Vote class.
     */
    @Test
    public void equalsHashCodeTest() {
        Vote v1 = new Vote("Caleb,Anthony,Solorio");
        Vote v2 = new Vote("Caleb,Anthony,Solorio");
        Vote v3 = new Vote("Anthony,Caleb,Solorio");

        Assert.assertFalse("v1 and v2 should not reference the same place in memory", v1 == v2);
        Assert.assertTrue("v1 and v2 should be equal", v1.equals(v2));
        Assert.assertTrue("v2 and v1 should be equal", v2.equals(v1));
        Assert.assertTrue("v1 and v2 should have equal hash codes", v1.hashCode() == v2.hashCode());

        Assert.assertFalse("v2 and v3 should not reference the same place in memory", v1 == v2);
        Assert.assertFalse("v2 and v3 should not be equal", v2.equals(v3));
        Assert.assertFalse("v3 and v2 should not be equal", v3.equals(v2));
        Assert.assertFalse("v2 and v3 should not have equal hash codes", v2.hashCode() == v3.hashCode());

        v2.eliminateCandidate(Candidate.getInstance("Anthony", Party.TEAPARTY));
        v3.eliminateCandidate(Candidate.getInstance("Anthony", Party.PIRATEPARTY));

        Assert.assertFalse("After elimination, v1 should not equal v2", v1.equals(v2));
        Assert.assertFalse("After elimination, the hashcode of v1 and v2 should not be equal",
                v1.hashCode() == v2.hashCode());
        Assert.assertTrue("After elimination, v2 should equal v3", v2.equals(v3));
        Assert.assertTrue("After elimination, the hashcode of v2 and v3 should be equal",
                v2.hashCode() == v3.hashCode());
    }

}
