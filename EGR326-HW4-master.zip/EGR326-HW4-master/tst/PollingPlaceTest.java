import org.junit.Assert;
import org.junit.Test;

import java.io.IOException;
import java.util.Iterator;
import java.util.Map;

/**
 * This class contains unit tests for the PollingPlace class.
 * @author  Austin
 */
public class PollingPlaceTest {
    @Test
    public void testGetInstance() throws IOException, IllegalArgumentException{
        Assert.assertNotNull(PollingPlace.getInstance("bellevue"));
    }

    @Test
    public void testGetName() throws IOException, IllegalArgumentException{
        Assert.assertEquals(PollingPlace.getInstance("bellevue").getName(), "bellevue");

        PollingPlace p = PollingPlace.getInstance("bellevue");

        Map<Candidate, Integer> map = p.collectVotes();
        Iterator iterator1 = map.keySet().iterator();
        while (iterator1.hasNext()) {
            Candidate candidate = (Candidate) iterator1.next();
            System.out.print(candidate.getName());
            System.out.println("has " + map.get(candidate) + " vote(s)");
        }
    }

    @Test
    public void testCollectVotes() throws IOException{
        Election.getInstance().addPollingPlace("bellevue");
        Assert.assertEquals( Election.getInstance().getTotalResults(), PollingPlace.getInstance("bellevue").collectVotes());
    }

    @Test
    public void testEliminateCandidate() throws IOException{
        Map map1 = PollingPlace.getInstance("bellevue").collectVotes();
        PollingPlace.getInstance("bellevue").eliminateCandidate(Candidate.getInstance("Barack Obama", Party.DEMOCRAT));
        Assert.assertNotEquals(map1, PollingPlace.getInstance("bellevue").collectVotes());
    }
}
