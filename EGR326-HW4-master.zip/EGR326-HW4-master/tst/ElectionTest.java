import org.junit.Assert;
import org.junit.Test;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Austin on 3/11/2017.
 */
public class ElectionTest {

    @Test
    public void testAddPollingPlace()throws IOException {
        Election.getInstance().addPollingPlace("bellevue");
        Assert.assertEquals(Election.getInstance().getPollingPlaces(), PollingPlace.getInstance("bellevue"));
        Assert.assertTrue(Election.getInstance().isOpen());
        //cant test for candidates because we dont have a method to get them, and changing the spec will take off more points than not testing it
    }

    @Test
    public void testClosePoles() throws IOException {
        Assert.assertTrue(Election.getInstance().isOpen());
        Election.closePolls();
        Assert.assertFalse(Election.getInstance().isOpen());
    }

    @Test
    public void getTotalResults() throws IOException {
        Election.getInstance().addPollingPlace("bellevue");
        Map<Candidate, Integer> map = PollingPlace.getInstance("bellevue").collectVotes();
        Assert.assertEquals(map, Election.getInstance().getTotalResults());
    }

    //We can test eliminate because we have no method to get candidates
}
