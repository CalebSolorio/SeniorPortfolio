import org.junit.Assert;
import org.junit.Test;

/**
 * This class contains unit tests for the Party enum.
 * @author Caleb Solorio
 * @version 1.0 (Mar 1 2017)
 */

public class PartyTest {
    /**
     * Tests the fromShortName method of the Party enum.
     */
    @Test
    public void fromShortNameTest() {
        Party[] parties = {Party.REPUBLICAN, Party.DEMOCRAT, Party.LIBERTARIAN, Party.GREENPARTY,
                Party.CONSTITUTIONPARTY, Party.TEAPARTY, Party.PIRATEPARTY, Party.UNKNOWN};
        String[] names = {"REP", "DEM", "LIB", "GRN", "CNS", "TEA", "ARR", "MEH"};

        for(int i = 0; i < parties.length; i++) {
            Assert.assertEquals("Party should be '" +
                    parties[i].name() + "'", parties[i], Party.fromShortName(names[i]));
        }
    }
    /**
     * Tests the getShortName method of the Party enum.
     */
    @Test
    public void getShortNameTest() {
        Party[] parties = {Party.REPUBLICAN, Party.DEMOCRAT, Party.LIBERTARIAN, Party.GREENPARTY,
                Party.CONSTITUTIONPARTY, Party.TEAPARTY, Party.PIRATEPARTY, Party.UNKNOWN};
        String[] expected = {"REP", "DEM", "LIB", "GRN", "CNS", "TEA", "ARR", "???"};

        for(int i = 0; i < parties.length; i++) {
            Assert.assertEquals("Name should be equal to '" +
                    expected[i] + "'", parties[i].getShortName(), expected[i]);
        }
    }
}
