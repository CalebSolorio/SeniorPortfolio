# egr223-planner
This was a project I completed for my course for Software Engineering Approach to Human and Computer Interaction (EGR223). The result is a planner which allows students to create and save events on a virtual calendar. The project was made with HTML, CSS, PHP, and JavaScript.
