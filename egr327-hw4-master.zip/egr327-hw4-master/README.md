# EGR327_HW4
Fourth homework assignment in Software Construction(EGR327).
Created by Caleb Solorio and Austin Brinegar.
