defmodule ProjectMeetingsWeb.PageView do
  use ProjectMeetingsWeb, :view
end
