defmodule ProjectMeetingsWeb.LayoutView do
  use ProjectMeetingsWeb, :view
end
