defmodule ProjectMeetings.Utils.Scheduler do
  use Quantum.Scheduler,
    otp_app: :your_app
end
