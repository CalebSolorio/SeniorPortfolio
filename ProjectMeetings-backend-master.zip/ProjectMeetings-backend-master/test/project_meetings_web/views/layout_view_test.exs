defmodule ProjectMeetingsWeb.LayoutViewTest do
  use ProjectMeetingsWeb.ConnCase, async: true
end
