defmodule ProjectMeetingsWeb.PageViewTest do
  use ProjectMeetingsWeb.ConnCase, async: true
end
