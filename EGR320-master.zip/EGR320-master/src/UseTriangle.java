import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by Caleb Solorio on 9/13/2016.
 */
public class UseTriangle {
    private JButton submitBtn;
    private JPanel panel1;
    private JTextField side1Text;
    private JTextField side2Text;
    private JTextField side3Text;

    public UseTriangle() {
        submitBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    if(Double.parseDouble(side1Text.getText()) <= 0 || Double.valueOf(side2Text.getText()) <= 0
                            || Double.valueOf(side3Text.getText()) <= 0) {
                        JOptionPane.showMessageDialog(null, "Typically, 'side lengths' refers to number values "
                                + "greater than 0. Try again, square.");
                    } else {
                        if(!Triangle.NotATriangle(Double.parseDouble(side1Text.getText()),
                                Double.parseDouble(side2Text.getText()), Double.parseDouble(side3Text.getText()))) {

                            Triangle t = new Triangle(Double.parseDouble(side1Text.getText()),
                                    Double.parseDouble(side2Text.getText()), Double.parseDouble(side3Text.getText()));

                            if(t.isEquilateral()) {
                                JOptionPane.showMessageDialog(null, "This here is an equilateral triangle, the most "
                                        + "pure of all triangles. Long live the equilateral master race.");
                            } else if(t.isIsosceles()) {
                                JOptionPane.showMessageDialog(null, "Ah, this is an isosceles triangle. They aren't"
                                        + " terrible offensive, but I'd watch out for their bad side.");
                            } else {
                                JOptionPane.showMessageDialog(null, "Gross, what you have on your hands is a scalene "
                                        + "triangle. Please, put that thing back and wash your hands of that filth.");
                            }
                        } else {
                            JOptionPane.showMessageDialog(null, "What do you take me for, a circle-sympathizer?!? "
                                    + "This isn't a triangle, this is a 2D abomination! Get this monstrosity out of "
                                    + "my sight!");
                        }
                    }
                } catch(NumberFormatException err) {
                    JOptionPane.showMessageDialog(null, "Typically, 'side lengths' refers to numbers, not words. "
                            + "Try again, square.");
                }
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("TriangleGUI");
        frame.setContentPane(new UseTriangle().panel1);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}
