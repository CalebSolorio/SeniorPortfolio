/**
 * Created by Caleb Solorio on 9/9/2016.
 */
public class Triangle {
    private double sideA;
    private double sideB;
    private double sideC;

    public Triangle(double a, double b, double c) {
        sideA = a;
        sideB = b;
        sideC = c;
    }

    boolean isEquilateral() {
        if (sideA == sideB && sideB == sideC) {
            return true;
        }
        return false;
    }

    boolean isIsosceles() {
        if (((sideA == sideB) && (sideC < (sideA + sideB))) || ((sideB == sideC) && (sideA < (sideB + sideC)))
                || ((sideC == sideA) && (sideB < (sideA + sideC)))) {
            return true;
        }
        return false;
    }

    static boolean NotATriangle(double a, double b, double c) {
        if(a >= b && a >= c) {
            if((b + c) > a) {
                return false;
            }
        } else if (b >= a && b >= c) {
            if((c + a) > b) {
                return false;
            }
        } else if (c >= a && c >= b) {
            if((a + b) > c) {
                return false;
            }
        }
        return true;
    }
}
