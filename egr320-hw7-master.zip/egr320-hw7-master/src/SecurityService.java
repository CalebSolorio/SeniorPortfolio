/**
 * Created by Caleb Solorio on 10/17/2016.
 */
public interface SecurityService {
    String md5(String passwordMd5);
}
