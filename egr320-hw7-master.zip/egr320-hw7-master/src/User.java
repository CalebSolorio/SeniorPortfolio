/**
 * Created by Caleb Solorio on 10/17/2016.
 */
public interface User {
    String getPassword();
    void setPassword(String password);
}
