/**
 * Created by Caleb Solorio on 10/17/2016.
 */
public interface UserDAO {
    void updateUser(User user);
}
