import org.junit.Assert;
import org.junit.Test;

import static org.mockito.Mockito.*;
/**
 * Created by Caleb Solorio on 10/16/2016.
 */
public class USITest {
    // Set up objects to be used.
    private UserDAO userDAO = mock(UserDAO.class);
    private SecurityService securityService = mock(SecurityService.class);
    private User user = mock(User.class);
    private UserServiceImpl userServiceImpl = new UserServiceImpl(userDAO, securityService);

    @Test
    public void userGetsNewPasswordTest() {
        // Set mock passwords.
        String password = "password123";
        String newPassword = "hashedPassword123";

        // Ensure that mock passwords are returned when certain methods are called.
        when(user.getPassword()).thenReturn(password);
        when(securityService.md5(password)).thenReturn(newPassword);

        // Make sure that the methods return the correct values.
        Assert.assertEquals("Password not returned",
                password, user.getPassword());
        Assert.assertEquals("New password not returned",
                newPassword, securityService.md5(password));

        // Run the main method to be tested
        try {
            userServiceImpl.assignPassword(user);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Verify that the appropriate methods were called.
        verify(user).setPassword(newPassword);
        verify(userDAO).updateUser(user);
    }
}
