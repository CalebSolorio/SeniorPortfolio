package main;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * This class stores information about a collection of courses.
 * @author Caleb Solorio
 * @version 1.0 (Feb 1 2017)
 */

public class Schedule implements Cloneable {
    private List<Course> courses;

    /**
     * Creates a new empty schedule.
     */
    public Schedule() {
        courses = new ArrayList<>();
    }

    /**
     * Assuming no conflicts exist, add a new course to the schedule.
     * @param newCourse The proposed course to add to the schedule.
     * @throws ScheduleConflictException if the given course conflicts
     * with a course in the schedule.
     */
    public void add(Course newCourse) {
        for(Course course : courses) {
            if(newCourse.conflictsWith(course)) {
                throw new ScheduleConflictException(newCourse, course);
            }
        }

        courses.add(newCourse.clone());
    }

    /**
     * Creates a deep copy of this Schedule object
     * @return copy of the object, null if exception occurs.
     */
    public Schedule clone() {
        try {
            Schedule copy = (Schedule) super.clone();
            copy.courses = new ArrayList<>(courses);
            return copy;
        } catch (CloneNotSupportedException e) {
            return null;
        }
    }

    /**
     * Gets a course overlapping with a given time on a given day.
     * @param day The day with which we can check for overlap.
     * @param time The time with which we can check for overlap.
     * @return course object if one is found to overlap with the given time;
     * otherwise, return false.
     */
    public Course getCourse(Weekday day, Time time) {
        for(Course course: courses) {
            if(course.contains(day, time)) {
                return course;
            }
        }

        return null;
    }

    /**
     * Removes a course from the Schedule, given a day and time,
     * if overlap exists.
     * @param day The day with which we can check for overlap.
     * @param time The time with which we can check for overlap.
     */
    public void remove(Weekday day, Time time) {
        Course removeCourse = null;
        for(Course course: courses) {
            if(course.contains(day, time)) {
                removeCourse = course;
                break;
            }
        }

        courses.remove(removeCourse);
    }

    /**
     * Writes a sorted list to a file.
     * @param stream The PrintStream through which we will write our data.
     * @param comparator The comparator specifying how to sort the objects.
     */
    public void save(PrintStream stream, Comparator<Course> comparator) {
        List<Course> out = new ArrayList<>(courses);

        if (out.size() > 0) {
            quickSort(out,0, out.size() - 1, comparator);
        }

        for(Course course : out) {
            stream.println(course.toString());
        }
    }

    // Take in a list of courses, lower/higher index to start from, and comparison criteria.
    // Use a variation of the quick-sort algorithm to sort the courses.
    private void quickSort(List<Course> courses, int lowerIndex, int higherIndex, Comparator<Course> comparator) {
        int i = lowerIndex;
        int j = higherIndex;
        Course pivot = courses.get(lowerIndex+(higherIndex-lowerIndex)/2);

        while (i <= j) {
            while (comparator.compare(courses.get(i), pivot) < 0) {
                i++;
            }
            while (comparator.compare(courses.get(j), pivot) > 0) {
                j--;
            }
            if (i <= j) {
                exchangeCourses(courses, i, j);
                i++;
                j--;
            }
        }

        if (lowerIndex < j) {
            quickSort(courses, lowerIndex, j, comparator);
        }
        if (i < higherIndex) {
            quickSort(courses, i, higherIndex, comparator);
        }
    }

    // Given a list of courses and two indexes, switch the values of two courses
    // att the given indexes.
    private void exchangeCourses(List<Course> courses, int i, int j) {
        Course temp = courses.get(i);
        courses.set(i, courses.get(j));
        courses.set(j, temp);
    }

    /**
     * Calculates the total number of credits in this Schedule object.
     * @return integer specifying the total credit number.
     */
    public int totalCredits() {
        int total = 0;
        for(Course course: courses) {
            total += course.getCredits();
        }

        return total;
    }

    /** NOTE: Though not required in the spec, this class was created
     * due to the given test cases in the ScheduleInstructorTest class.
     * @return a clone of the course list.
     */
    public List<Course> getAllCourses() {
        return new ArrayList<>(courses);
    }

}
