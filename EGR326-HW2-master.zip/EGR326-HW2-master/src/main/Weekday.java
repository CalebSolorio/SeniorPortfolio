package main;

/**
 * This class represents the five days provided for courses.
 * @author Caleb Solorio
 * @version 1.0 (Jan 27 2017)
 */

public enum Weekday {
    MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY;

    /**
     * Takes in a string and returns the correlating enumeration value.
     * @param s String to parse Weekday from.
     * @return the parse Weekday object.
     * @throws IllegalArgumentException if no Weekday object can be parsed.
     */
    public static Weekday fromString(String s) {
        s = s.toLowerCase();

        if(s.toLowerCase().equals("monday") || s.equals("m")) {
            return MONDAY;
        } else if(s.toLowerCase().equals("tuesday") || s.equals("t")) {
            return TUESDAY;
        } else if(s.toLowerCase().equals("wednesday") || s.equals("w")) {
            return WEDNESDAY;
        } else if(s.toLowerCase().equals("thursday") || s.equals("r")) {
            return THURSDAY;
        } else if(s.toLowerCase().equals("friday") || s.equals("f")) {
            return FRIDAY;
        }

        throw new IllegalArgumentException("String given does not match a weekday");
    }

    /**
     * Determines the one letter string correlating to the object's current state.
     * @return the correlating string.
     */
    public String toShortName() {
        switch(this) {
            case MONDAY:
                return "M";
            case TUESDAY:
                return "T";
            case WEDNESDAY:
                return "W";
            case THURSDAY:
                return "R";
            default: FRIDAY:
                return "F";
        }
    }

    /**
     * Calculates the string value of the weekday in an appropriate case.
     * @return the correlating string.
     */
    public String toString() {
        return this.name().substring(0,1).toUpperCase()
                + this.name().substring(1).toLowerCase();
    }
}

