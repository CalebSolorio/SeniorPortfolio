package main;

import java.util.Comparator;

/**
 * TThis class helps compare the credit number of two Course objects.
 * @author Caleb Solorio
 * @version 1.0 (Feb 1 2017)
 */

public class CourseCreditComparator implements Comparator<Course> {
    /**
     * Compares the credit numbers of two courses. If the result is
     * equal to zero, return result of a course name comparison.
     * @param course1 The first course given for comparison.
     * @param course2 The second course given for comparison.
     * @return integer value specifying the result of the comparison.
     */
    public int compare(Course course1, Course course2) {
        int comparison = course1.getCredits() - course2.getCredits();
        if(comparison != 0) {
            return comparison;
        }

        CourseNameComparator comparator = new CourseNameComparator();
        return comparator.compare(course1, course2);
    }
}
