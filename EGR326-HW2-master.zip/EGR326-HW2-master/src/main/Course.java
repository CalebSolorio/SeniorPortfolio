package main;

import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

/**
 * This class stores information about a specific course.
 * @author Caleb Solorio
 * @version 1.0 (Jan 27 2017)
 */

public class Course implements Cloneable {
    private String name;
    private int credits;
    private Set<Weekday> days;
    private Time startTime;
    private int duration;

    /**
     * Checks that arguments pass certain qualifications before creating an instance.
     * @param name The course's name.
     * @param credits Number of credits associated with the course.
     * @param days Specifies which days class is held.
     * @param startTime Time class starts.
     * @param duration How many minutes in a single class session.
     * @throws IllegalArgumentException if the parameters don't pass qualifications.
     */
    public Course(String name, int credits, Set<Weekday> days,
                  Time startTime, int duration) {
        if (name != null && name.length() > 0 && name.matches(".*\\s+.*") &&
                credits > 0 && credits < 5 && days != null && days.size() > 0 &&
                startTime != null && duration > 0) {
            this.name = name;
            this.credits = credits;
            this.days = new TreeSet<>(days);
            this.startTime = startTime.clone();
            this.duration = duration;
        } else {
            throw new IllegalArgumentException();
        }
    }

    /**
     * Takes in a course and checks if it will form a scheduling conflict.
     * @param other The other course to compare the current course with.
     * @return true if the given course conflicts with this one, false otherwise.
     */
    public boolean conflictsWith(Course other) {
        for(Weekday day: days) {
            for(Weekday otherDay: other.days) {
                if(day.compareTo(otherDay) == 0) {
                    if(startTime.compareTo(other.getStartTime()) >= 0
                            && startTime.compareTo(other.getEndTime()) >= 0) {
                        return false;
                    } else if(startTime.compareTo(other.getStartTime()) <= 0
                            && getEndTime().compareTo(other.getStartTime()) <= 0){
                        return false;
                    }

                    return true ;
                }
            }
        }

        return false;
    }

    /**
     * Checks if a certain time on a certain day falls within the duration of this course.
     * @param day Specifies the day on which to check for overlap.
     * @param time Specifies the exact time to check for overlap.
     * @return true if this course contains the given day and time, false otherwise.
     */
    public boolean contains(Weekday day, Time time) {
        for(Weekday courseDay: days) {
            if(courseDay.equals(day)) {
                return startTime.compareTo(time) <= 0
                        && getEndTime().compareTo(time) > 0;
            }
        }
        return false;
    }

    /**
     * Creates a hash code for Course objects.
     * @return this object's hash code.
     */
    @Override
    public int hashCode() {
        int hash = 31 * name.hashCode();
        hash = hash * 31 + credits;
        hash = hash * 31 + days.hashCode();
        hash = hash * 31 + startTime.hashCode();
        hash = hash * 31 + duration;

        return hash;
    }

    /**
     * Checks if this Course objects has the same state as this one.
     * @param o The object to compare this object's state with.
     * @return true if the two objects have the same state, false otherwise.
     */
    @Override
    public boolean equals(Object o) {
        if(o instanceof Course) {
            Course course = (Course) o;
            return toString().equals(course.toString());
        }

        return false;
    }

    /**
     * Creates a deep copy of this object (NOTE: This wasn't in the spec
     * but it was requested in the instructor tst cases, so I've added it.).
     * @return the clone of this object.
     */
    public Course clone() {
        try {
            Course clone = (Course) super.clone();
            clone.days = new TreeSet<>(days);
            clone.startTime = startTime.clone();
            return clone;
        } catch (CloneNotSupportedException e) {
            return null;
        }
    }

    /**
     * @return credits value from this object.
     */
    public int getCredits() {
        return credits;
    }

    /**
     * @return duration value from this object.
     */
    public int getDuration() {
        return duration;
    }

    /**
     * @return name value from this object.
     */
    public String getName() {
        return name;
    }

    /**
     * @return startTime value from this object.
     */
    public Time getStartTime() {
        return startTime;
    }

    /**
     * Calculates the end time of this object.
     * @return this object's end time.
     */
    public Time getEndTime() {
        Time endTime = startTime.clone();
        endTime.shift(duration);
        return endTime;
    }

    /**
     * Creates a summary of this object.
     * @return string detailing this object's state.
     */
    public String toString(){
        String string = name + "," + credits + ",";
        Iterator<Weekday> iterator = days.iterator();

        while(iterator.hasNext()) {
            string += iterator.next().toShortName();
        }

        string += "," + startTime.toString() + "," + duration;

        return string;
    }

}
