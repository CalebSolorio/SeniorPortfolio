package main;

/**
 * This class represents a specific time of day in the form of HH:MM AM/PM.
 * @author Caleb Solorio
 * @version 1.0 (Jan 27 2017)
 */

public class Time implements Cloneable, Comparable<Time> {
    private int hour;
    private int minute;
    private boolean pm;

    /**
     * Takes in hour, minute, and am/pm boolean and assigns the variables accordingly.
     * @param hour The hour of the specified time.
     * @param minute The minute of the specified time.
     * @param pm Specifies whether the time is in the A.M. or P.M.
     * @throws IllegalArgumentException if the arguments do not pass qualification tests.
     */
    public Time(int hour, int minute, boolean pm) {
        if(hour > 0 && hour <=12
                && minute >= 0 && minute < 60) {
            this.hour = hour;
            this.minute = minute;
        } else {
            throw new IllegalArgumentException();
        }

        this.pm = pm;
    }

    /**
     * Creates a Time object from a given string, then returns the object.
     * @param str the string to parse a Time object from
     * @return the newly created Time object
     * @throws IllegalArgumentException if unable to parse Time object from string.
     */
    public static Time fromString(String str) {
        String[] components = str.split(":| ");

        if(components[0].length() != 2 || components[1].length() != 2
                || (!components[2].equals("AM") && !components[2].equals("PM"))) {
            throw new IllegalArgumentException();
        }

        int hour = Integer.parseInt(components[0]);
        int minute = Integer.parseInt(components[1]);
        boolean pm = components[2].equals("PM");

        return new Time(hour, minute, pm);
    }

    /**
     * Clones this Time object.
     * @return the clone of this object.
     */
    public Time clone() {
        try {
            return (Time) super.clone();
        } catch (CloneNotSupportedException e) {
            return null;
        }
    }

    /**
     * Compares the hash code of a given Time object to this object's hash code.
     * @param time Time object to compare with this one
     * @return integer specifying the result of this comparison.
     */
    public int compareTo(Time time) {
        return this.hashCode() - time.hashCode();
    }

    /**
     * Creates a hash code for Time objects
     * @return hash code integer value.
     */
    @Override
    public int hashCode() {
        return 65531 * (pm ? 1 : 0)
                + 67 * (hour == 12 ? 0 : hour) + minute;
    }

    /**
     * Determines if the given object has the same state as this object.
     * @return true if the given object is equal in state to this object; false otherwise.
     */
    @Override
    public boolean equals(Object o) {
        if(o instanceof Time) {
            Time time = (Time) o;
            return pm == time.pm && hour == time.getHour() && minute == time.getMinute();
        }

        return false;
    }

    /**
     * @return hour value of this object.
     */
    public int getHour() {
        return hour;
    }

    /**
     * @return minute value of this object.
     */
    public int getMinute() {
        return minute;
    }

    /**
     * @return boolean value of this object specifying whether or not the time is in AM or PM.
     */
    public boolean isPM() {
        return pm;
    }

    /**
     * Shift the current state of this object by a given about of minutes.
     * @param minutes Specifies how many minutes forward to shift this Time object.
     */
    public void shift(int minutes) {
        if (minutes >= 0) {
            minute += minutes;

            do {
                if (minute >= 60) {
                    hour++;
                    minute -= 60;
                }
                if (hour == 12) {
                    pm = !pm;
                } else if (hour > 12) {
                    hour -= 12;
                }
            } while (minute >= 60);

            return;
        }

        throw new IllegalArgumentException("A negative number was provided");
    }

    /**
     * Create a string summarizing this object's state
     * @return the created string.
     */
    public String toString() {
        String hourString = String.format("%02d", hour);
        String minuteString = String.format("%02d", minute);
        String pmString;
        if(pm) {
            pmString = "PM";
        } else {
            pmString = "AM";
        }

        return hourString + ":" + minuteString + " " + pmString;
    }
}
