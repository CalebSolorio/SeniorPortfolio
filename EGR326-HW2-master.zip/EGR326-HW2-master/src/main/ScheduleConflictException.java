package main;

/**
 * This class represents a throwable exception in case of schedule conflict.
 * @author Caleb Solorio
 * @version 1.0 (Feb 1 2017)
 */

public class ScheduleConflictException extends RuntimeException {
    /**
     * Create an exception with an appropriate message.
     * @param course1 First course to reference in the message.
     * @param course2 Second course to reference in the message.
     */
    public ScheduleConflictException(Course course1, Course course2) {
        super("Whoops! " + course1.getName() +
                " conflicts with " + course2.getName() + " :(");
    }
}
