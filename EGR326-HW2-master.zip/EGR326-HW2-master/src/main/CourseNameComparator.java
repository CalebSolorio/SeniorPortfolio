package main;

/**
 * TThis class helps compare the name of two Course objects.
 * @author Caleb Solorio
 * @version 1.0 (Feb 1 2017)
 */

import java.util.Comparator;

public class CourseNameComparator implements Comparator<Course> {
    /**
     * Compares the names of two courses.
     * @param course1 The first course given for comparison.
     * @param course2 The second course given for comparison.
     * @return integer value specifying the result of the comparison.
     */
    public int compare(Course course1, Course course2) {
        return course1.getName().compareTo(course2.getName());
    }
}
