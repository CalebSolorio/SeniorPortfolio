package main;

import java.util.Comparator;

/**
 * This class helps compare the start times of two Course objects.
 * @author Caleb Solorio
 * @version 1.0 (Feb 1 2017)
 */

public class CourseTimeComparator implements Comparator<Course> {
    /**
     * Compares the start times of two courses. If the result is
     * equal to zero, return result of an end time comparison.
     * If the result is equal to zero, return result of a name comparison.
     * @param course1 The first course given for comparison.
     * @param course2 The second course given for comparison.
     * @return integer value specifying the result of the comparison.
     */
    public int compare(Course course1, Course course2) {
        int comparison = course1.getStartTime().hashCode() -
                course2.getStartTime().hashCode();
        if(comparison != 0) {
            return comparison;
        }

        comparison = course1.getEndTime().hashCode() -
                course2.getEndTime().hashCode();

        if(comparison != 0) {
            return comparison;
        }

        CourseNameComparator comparator = new CourseNameComparator();
        return comparator.compare(course1, course2);
    }
}
