package main;// Scheduler Homework
// Instructor-provided code; do not modify.

/**
 * This class contains the main method to run the overall program.
 *
 * @author Mikyung Han
 * @version Fall 2016 v1.0
 */
public class SchedulerMain {
    public static void main(String[] args) {
        new SchedulerGui();
    }
}