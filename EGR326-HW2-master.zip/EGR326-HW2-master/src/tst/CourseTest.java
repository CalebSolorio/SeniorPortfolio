package tst;

import main.Course;
import main.Time;
import main.Weekday;
import org.junit.Assert;
import org.junit.Test;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;


/**
 * This class stores test cases for the Course class.
 * @author Caleb Solorio
 * @version 1.0 (Jan 27 2017)
 */
public class CourseTest {
    /**
     * Tests the conditions on which the Course constructor with throw an exception.
     */
    @Test
    public void constructorIllegalArgumentTest() {
        int testCount = 0;
        String name = "EGR 326";
        int credits = 3;
        Set<Weekday> days = new TreeSet<>();
        Time startTime = Time.fromString("02:00 PM");
        int duration = 90;

        constructorHelper(testCount, name, credits, null, startTime, duration);
        testCount++;
        constructorHelper(testCount, name, credits, days, startTime, duration);
        testCount++;
        days.add(Weekday.TUESDAY);
        credits = 0;
        constructorHelper(testCount, name, credits, days, startTime, duration);
        testCount++;
        credits = 5;
        constructorHelper(testCount, name, credits, days, startTime, duration);
        testCount++;
        credits = 3;
        name = "EGR326";
        constructorHelper(testCount, name, credits, days, startTime, duration);
        testCount++;
        name = null;
        constructorHelper(testCount, name, credits, days, startTime, duration);
        testCount++;
        name = "";
        constructorHelper(testCount, name, credits, days, startTime, duration);
        testCount++;
        startTime = null;
        constructorHelper(testCount, name, credits, days, startTime, duration);
        testCount++;
        duration = 0;
        constructorHelper(testCount, name, credits, days, startTime, duration);
    }

    // Helps verify the constructor will fail under certain conditions.
    private void constructorHelper(int testNum, String name, int credits, Set<Weekday> days, Time startTime, int duration) {
        try {
            Course course = new Course(name, credits, days, startTime, duration);
            Assert.fail("Test #" + testNum + " should fail");
        } catch(IllegalArgumentException e) {}
    }

    /**
     * Tests the getName() method of the Course class.
     */
    @Test
    public void getNameTest() {
        String nameExpected = "EGR 326";
        int credits = 3;
        Set<Weekday> days = new TreeSet<>();
        days.add(Weekday.TUESDAY);
        Time startTime = Time.fromString("02:00 PM");
        int duration = 90;
        Course course = new Course(nameExpected, credits, days, startTime, duration);

        String nameActual = course.getName();

        Assert.assertEquals("Incorrect name", nameExpected, nameActual);
    }

    /**
     * Tests the getCredits() method of the Course class.
     */
    @Test
    public void getCreditsTest() {
        String name = "EGR 326";
        int creditsExpected = 3;
        Set<Weekday> days = new TreeSet<>();
        days.add(Weekday.TUESDAY);
        Time startTime = Time.fromString("02:00 PM");
        int duration = 90;
        Course course = new Course(name, creditsExpected, days, startTime, duration);

        int creditsActual = course.getCredits();

        Assert.assertEquals("Incorrect number of credits", creditsExpected, creditsActual);
    }

    /**
     * Tests the getStartTime() method of the Course class.
     */
    @Test
    public void getStartTimeTest() {
        String name = "EGR 326";
        int credits = 3;
        Set<Weekday> days = new TreeSet<>();
        days.add(Weekday.TUESDAY);
        Time startTimeExpected = Time.fromString("02:00 PM");
        int duration = 90;
        Course course = new Course(name, credits, days, startTimeExpected, duration);

        Time startTimeActual = course.getStartTime();

        Assert.assertTrue("Incorrect start time", startTimeExpected.equals(startTimeActual));
        Assert.assertFalse("Incorrect start time", startTimeExpected == startTimeActual);
    }

    /**
     * Tests the getDuration() method of the Course class.
     */
    @Test
    public void getDurationTest() {
        String name = "EGR 326";
        int credits = 3;
        Set<Weekday> days = new TreeSet<>();
        days.add(Weekday.TUESDAY);
        Time startTime = Time.fromString("02:00 PM");
        int durationExpected = 90;
        Course course = new Course(name, credits, days, startTime, durationExpected);

        int durationActual = course.getDuration();

        Assert.assertEquals("Incorrect duration", durationExpected, durationActual);
    }

    /**
     * Tests the getEndTime() method of the Course class.
     */
    @Test
    public void getEndTimeTest() {
        String name = "EGR 326";
        int credits = 3;
        Set<Weekday> days = new TreeSet<>();
        days.add(Weekday.TUESDAY);
        Time startTime = Time.fromString("02:00 PM");
        int duration = 90;
        Course course = new Course(name, credits, days, startTime, duration);

        Time endTimeExpected = Time.fromString("03:30 PM");
        Time endTimeActual = course.getEndTime();

        Assert.assertTrue("Incorrect end time", endTimeExpected.equals(endTimeActual));
    }

    /**
     * Tests the toString() method of the Course class.
     */
    @Test
    public void toStringTest() {
        String name = "EGR 326";
        int credits = 3;
        Set<Weekday> days = new TreeSet<>();
        days.add(Weekday.TUESDAY);
        days.add(Weekday.THURSDAY);
        Time startTime = Time.fromString("02:00 PM");
        int duration = 90;
        Course course = new Course(name, credits, days, startTime, duration);

        String stringExpected = "EGR 326,3,TR,02:00 PM,90";
        String stringActual = course.toString();

        Assert.assertTrue("Incorrect string returned", stringExpected.equals(stringActual));
    }

    /**
     * Tests the conflictsWith() method of the Course class.
     */
    @Test
    public void conflictsWithTest() {
        Set<Weekday> days = new TreeSet<>();
        days.add(Weekday.TUESDAY);
        days.add(Weekday.THURSDAY);
        Course course1 = new Course("EGR 326", 3, days, Time.fromString("02:00 PM"), 90);
        days.clear();
        days.add(Weekday.MONDAY);
        days.add(Weekday.THURSDAY);

        boolean conflict1 = course1.
                conflictsWith(new Course("EGR 420", 3, days, Time.fromString("02:00 PM"), 89));
        boolean conflict2 = course1.
                conflictsWith(new Course("EGR 420", 3, days, Time.fromString("02:00 PM"), 90));
        boolean conflict3 = course1.
                conflictsWith(new Course("EGR 420", 3, days, Time.fromString("02:00 PM"), 91));
        boolean conflict4 = course1.
                conflictsWith(new Course("EGR 420", 3, days, Time.fromString("12:30 PM"), 89));
        boolean conflict5 = course1.
                conflictsWith(new Course("EGR 420", 3, days, Time.fromString("12:30 PM"), 90));
        boolean conflict6 = course1.
                conflictsWith(new Course("EGR 420", 3, days, Time.fromString("12:30 PM"), 91));
        boolean conflict7 = course1.
                conflictsWith(new Course("EGR 420", 3, days, Time.fromString("03:30 PM"), 30));

        Assert.assertTrue("conflict1 should be false", conflict1);
        Assert.assertTrue("conflict2 should be false", conflict2);
        Assert.assertTrue("conflict3 should be false", conflict3);
        Assert.assertFalse("conflict4 should be false", conflict4);
        Assert.assertFalse("conflict5 should be false", conflict5);
        Assert.assertTrue("conflict6 should be false", conflict6);
        Assert.assertFalse("conflict7 should be false", conflict7);
    }


    /**
     * Tests the contains() method of the Course class.
     */
    @Test
    public void containsTest() {
        String name = "EGR 326";
        int credits = 3;
        Set<Weekday> days1 = new TreeSet<>();
        days1.add(Weekday.TUESDAY);
        days1.add(Weekday.THURSDAY);
        Time startTime = Time.fromString("02:00 PM");
        int duration = 90;
        Course course = new Course(name, credits, days1, startTime, duration);

        boolean contains1 = course.contains(Weekday.WEDNESDAY, Time.fromString("02:30 PM"));
        boolean contains2 = course.contains(Weekday.THURSDAY, Time.fromString("01:59 PM"));
        boolean contains3 = course.contains(Weekday.THURSDAY, Time.fromString("03:31 PM"));
        boolean contains4 = course.contains(Weekday.THURSDAY, Time.fromString("02:00 PM"));
        boolean contains5 = course.contains(Weekday.THURSDAY, Time.fromString("02:30 PM"));
        boolean contains6 = course.contains(Weekday.THURSDAY, Time.fromString("03:30 PM"));

        Assert.assertFalse("contains1 should be false", contains1);
        Assert.assertFalse("contains2 should be false", contains2);
        Assert.assertFalse("contains3 should be false", contains3);
        Assert.assertTrue("contains4 should be true", contains4);
        Assert.assertTrue("contains5 should be true", contains5);
        Assert.assertFalse("contains6 should be true", contains6);
    }

    /**
     * Tests the equals() method of the Course class.
     */
    @Test
    public void equalsTest() {
        String name = "EGR 326";
        int credits = 3;
        Set<Weekday> days = new TreeSet<>();
        days.add(Weekday.TUESDAY);
        Time startTime = Time.fromString("02:00 PM");
        int duration = 90;
        Course course1 = new Course(name, credits, days, startTime, duration);
        Course course2 = new Course(name, credits, days, startTime, duration);

        boolean equalsTrue = course1.equals(course2);
        days.add(Weekday.THURSDAY);
        course2 = new Course(name, credits, days, startTime, duration);
        boolean equalsFalse = course1.equals(course2);


        Assert.assertTrue("Courses should be equal", equalsTrue);
        Assert.assertFalse("Courses should not be equal", equalsFalse);
    }

    /**
     * Tests the clone() method of the Course class.
     */
    @Test
    public void cloneTest(){
        Time start = new Time (2, 0, true);
        Set<Weekday> days =  new TreeSet<>();
        days.add(Weekday.TUESDAY);
        days.add(Weekday.THURSDAY);
        Course egr222 = new Course("EGR 326", 3, days, start, 90);
        Course copy = egr222.clone();

        boolean comparison = egr222.equals(copy);
        boolean referenceCompare1 = egr222.getStartTime() == start;
        boolean referenceCompare2 = egr222.getStartTime() == copy.getStartTime();

        Assert.assertTrue("The course should have the same state as it's copy", comparison);
        Assert.assertFalse("The course's start time shouldn't have the same " +
                        "reference point as start", referenceCompare1);
        Assert.assertFalse("The course's start time shouldn't have the same " +
                        "reference point as the copy's start time", referenceCompare2);
    }

    /**
     * Tests the hashCode() method of the Course class.
     */
    @Test
    public void hashCodeTest() {
        Time startTime = new Time (2, 0, true);
        Set<Weekday> days = new TreeSet<>();
        days.add(Weekday.TUESDAY);
        days.add(Weekday.THURSDAY);
        Course course = new Course("EGR 326", 3, days, startTime, 60);
        Course courseCopy = new Course("EGR 326", 3, days, startTime, 60);

        Set<Course> courses = new HashSet<>();
        courses.add(course);
        boolean contains1 = courses.contains(course);
        boolean contains2 = courses.contains(courseCopy);
        boolean equals = course.hashCode() == courseCopy.hashCode();

        Assert.assertTrue("The hash set should contain the original course", contains1);
        Assert.assertTrue("The set should contain a course with the same state as the copy", contains2);
        Assert.assertTrue("Both hash codes should be equal", equals);
    }
}
