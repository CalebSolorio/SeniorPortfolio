package tst;

import main.*;
import org.junit.Test;

import java.util.Set;
import java.util.TreeSet;

/**
 * This class stores test cases for the ScheduleConflictException class.
 * @author Caleb Solorio
 * @version 1.0 (Feb 1 2017)
 */
public class ScheduleConflictExceptionTest {
    /**
     * Verifies that ScheduleConflictException is thrown appropriately.
     * @throws ScheduleConflictException if courses can't be initialized (as expected).
     */
    @Test(expected = ScheduleConflictException.class)
    public void throwTest() {
        Set<Weekday> days = new TreeSet<>();
        days.add(Weekday.TUESDAY);
        days.add(Weekday.THURSDAY);
        Course course1 = new Course("EGR 326", 3, days, Time.fromString("02:00 PM"), 90);
        days.remove(Weekday.THURSDAY);
        Course course2 = new Course("EGR 304", 1, days, Time.fromString("03:45 PM"), 60);

        throw new ScheduleConflictException(course1, course2);
    }
}
