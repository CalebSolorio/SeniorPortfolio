package tst;

import main.Time;
import org.junit.Assert;
import org.junit.Test;

import java.util.HashSet;
import java.util.Set;

/**
 * This class stores test cases for the Time class.
 * @author Caleb Solorio
 * @version 1.0 (Jan 27 2017)
 */
public class TimeTest {
    /**
     * Tests the constructor of the Time class.
     */
    @Test
    public void constructorTest() {
        Time time = new Time(12,30, true);

        try {
            time = new Time(0, 30, true);
            Assert.fail("Time object with hour less than or equal to zero should fail");
        } catch(IllegalArgumentException e) { }

        try {
            time = new Time(13, 30, true);
            Assert.fail("Time object with hour above 13 should fail");
        } catch(IllegalArgumentException e) { }

        try {
            time = new Time(12, -1, true);
            Assert.fail("Time object with minute less than zero should fail");
        } catch(IllegalArgumentException e) { }

        try {
            time = new Time(0, 60, true);
            Assert.fail("Time object with minute greater than or equal to 60 should fail");
        } catch(IllegalArgumentException e) { }
    }

    /**
     * Tests the getHour(), getMinute(), and isPM() methods of the Time class.
     */
    @Test
    public void getterTest() {
        int hourExpected = 7;
        int minuteExpected = 45;
        boolean pmExpected = false;
        Time time = new Time(hourExpected, minuteExpected, pmExpected);

        int hourActual = time.getHour();
        int minuteActual = time.getMinute();
        boolean pmActual = time.isPM();

        Assert.assertEquals("Hour should equal " + hourExpected, hourExpected, hourActual);
        Assert.assertEquals("Minute should equal " + minuteExpected, minuteExpected, minuteActual);
        Assert.assertFalse("P.M. should be " + pmExpected, pmActual);
    }

    /**
     * Tests the toString() method of the Time class.
     */
    @Test
    public void toStringTest() {
        Time time = new Time(7, 45, false);

        String expected = "07:45 AM";
        String actual = time.toString();

        Assert.assertTrue("String should equal '" + expected + "'", expected.equals(actual));
    }

    /**
     * Tests the fromString() method of the Time class.
     */
    @Test
    public void fromStringTest() {
        String expected1 = "07:45 AM";
        Time time = Time.fromString(expected1);
        String actual1 = time.toString();

        String expected2 = "07:45 PM";
        time = Time.fromString(expected2);
        String actual2 = time.toString();

        Assert.assertTrue("String should equal '" + expected1 + "'", expected1.equals(actual1));
        Assert.assertTrue("String should equal '" + expected2 + "'", expected2.equals(actual2));

        try {
            time = Time.fromString("o hai");
            Assert.fail("Time object not following the time format should fail");
        } catch(IllegalArgumentException e) { }

        try {
            time = Time.fromString("007:45 PM");
            Assert.fail("Time object initialized with hour string greater than 2 should fail");
        } catch(IllegalArgumentException e) { }

        try {
            time = Time.fromString("7:45 PM");
            Assert.fail("Time object initialized with hour string less than 2 should fail");
        } catch(IllegalArgumentException e) { }

        try {
            time = Time.fromString("07:045 PM");
            Assert.fail("Time object initialized with minute string greater than 2 should fail");
        } catch(IllegalArgumentException e) { }

        try {
            time = Time.fromString("07:5 PM");
            Assert.fail("Time object initialized with minute string less than 2 should fail");
        } catch(IllegalArgumentException e) { }

        try {
            time = Time.fromString("07:5 HI");
            Assert.fail("Time object initialized with pm string not equal to 'AM' or 'PM' should fail");
        } catch(IllegalArgumentException e) { }
    }

    /**
     * Tests the equals() method of the Time class.
     */
    @Test
    public void equalsTest() {
        String string = "07:45 AM";
        Time time1 = Time.fromString(string);
        Time time2 = Time.fromString(string);

        boolean equalsTrue = time1.equals(time2);
        string = "07:45 PM";
        time2 = Time.fromString(string);
        boolean equalsFalse = time1.equals(time2);

        Assert.assertTrue("Time objects should be equal", equalsTrue);
        Assert.assertFalse("Time objects should not be equal", equalsFalse);
    }

    /**
     * Tests the clone() method of the Time class.
     */
    @Test
    public void cloneTest() {
        Time time1 = Time.fromString("07:45 AM");
        Time time2 = time1.clone();

        boolean equals = time1.equals(time2);

        Assert.assertTrue("Cloned Time object should be equal", equals);
    }

    /**
     * Tests the compareTo() method of the Time class.
     */
    @Test
    public void compareToTest() {
        Time time1 = Time.fromString("07:45 AM");
        Time time2 = Time.fromString("10:45 AM");

        int comparison1 = time1.compareTo(time2);
        time1 = Time.fromString("10:45 PM");
        int comparison2 = time1.compareTo(time2);
        time2 = Time.fromString("10:45 PM");
        int comparison3 = time1.compareTo(time2);

        Assert.assertTrue("Comparison should be negative", comparison1 < 0);
        Assert.assertTrue("Comparison should be positive", comparison2 > 0);
        Assert.assertEquals("Comparison should be zero", 0, comparison3);
    }

    /**
     * Tests the hashCode() method of the Time class.
     */
    @Test
    public void hashCodeTest(){
        Time time1 = new Time(12, 0, true);
        Time time2 = new Time(4, 20, true);

        boolean hashCodeGreater = time1.hashCode() < time2.hashCode();
        time1 = new Time(4, 20, true);
        boolean hashCodeEquals = time1.hashCode() == time2.hashCode();

        Set<Time> set = new HashSet<>();
        set.add(time1);
        boolean contains1 = set.contains(time2);
        boolean contains2 = set.contains(new Time(4, 20, true));

        Assert.assertTrue("Hash code 1 should be less than hash code 2", hashCodeGreater);
        Assert.assertTrue("Both hash codes should be equal", hashCodeEquals);
        Assert.assertTrue(contains1);
        Assert.assertTrue(contains2);
    }

    /**
     * Tests the shift() method of the Time class.
     */
    @Test(expected = IllegalArgumentException.class)
    public void shiftTest() {
        Time time1 = Time.fromString("07:45 AM");
        Time time2 = Time.fromString("07:45 PM");

        time1.shift(-13);
        time1.shift(720);

        Assert.assertTrue("The two times after shifting should be equal", time1.equals(time2));
    }
}
