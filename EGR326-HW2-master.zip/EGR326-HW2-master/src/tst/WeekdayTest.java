package tst;

import main.Weekday;
import org.junit.Assert;
import org.junit.Test;

/**
 * This class stores test cases for the Weekday enum.
 * @author Caleb Solorio
 * @version 1.0 (Jan 27 2017)
 */
public class WeekdayTest {
    /**
     * Tests the toString() method of the Weekday enum.
     */
    @Test
    public void toStringTest() {
        Weekday day = Weekday.MONDAY;

        String stringM = day.toString();
        day = Weekday.TUESDAY;
        String stringT = day.toString();
        day = Weekday.WEDNESDAY;
        String stringW = day.toString();
        day = Weekday.THURSDAY;
        String stringR = day.toString();
        day = Weekday.FRIDAY;
        String stringF = day.toString();

        Assert.assertEquals("Return value should be 'Monday'","Monday", stringM);
        Assert.assertEquals("Return value should be 'Tuesday'","Tuesday", stringT);
        Assert.assertEquals("Return value should be 'Wednesday'","Wednesday", stringW);
        Assert.assertEquals("Return value should be 'Thursday'","Thursday", stringR);
        Assert.assertEquals("Return value should be 'Friday'","Friday", stringF);
    }

    /**
     * Tests the toShortName() method of the Weekday enum.
     */
    @Test
    public void toShortNameTest() {
        Weekday day = Weekday.MONDAY;

        String shortNameM = day.toShortName();
        day = Weekday.TUESDAY;
        String shortNameT = day.toShortName();
        day = Weekday.WEDNESDAY;
        String shortNameW = day.toShortName();
        day = Weekday.THURSDAY;
        String shortNameR = day.toShortName();
        day = Weekday.FRIDAY;
        String shortNameF = day.toShortName();

        Assert.assertEquals("Return value should be 'M'","M", shortNameM);
        Assert.assertEquals("Return value should be 'T'","T", shortNameT);
        Assert.assertEquals("Return value should be 'W'","W", shortNameW);
        Assert.assertEquals("Return value should be 'R'","R", shortNameR);
        Assert.assertEquals("Return value should be 'F'","F", shortNameF);
    }

    /**
     * Tests the fromString() method of the Weekday enum.
     */
    @Test
    public void fromStringTest() {
        String shortName1 = Weekday.fromString("Monday").toShortName();
        String shortName2 = Weekday.fromString("M").toShortName();
        String shortName3 = Weekday.fromString("tUesDaY").toShortName();
        String shortName4 = Weekday.fromString("t").toShortName();
        String shortName5 = Weekday.fromString("wednesday").toShortName();
        String shortName6 = Weekday.fromString("W").toShortName();
        String shortName7 = Weekday.fromString("THURSDAY").toShortName();
        String shortName8 = Weekday.fromString("r").toShortName();
        String shortName9 = Weekday.fromString("FrIDay").toShortName();
        String shortName10 = Weekday.fromString("F").toShortName();

        try {
            Weekday day = Weekday.fromString("friday ");
            Assert.fail("Weekday initialized with string not matching full day name should fail");
        } catch (IllegalArgumentException e){}

        try {
            Weekday day = Weekday.fromString("Z");
            Assert.fail("Weekday initialized with string not matching short day name should fail");
        } catch (IllegalArgumentException e){}

        Assert.assertEquals("Return value 1 should be 'M'", "M", shortName1);
        Assert.assertEquals("Return value 2 should be 'M'", "M", shortName2);
        Assert.assertEquals("Return value 3 should be 'T'", "T", shortName3);
        Assert.assertEquals("Return value 4 should be 'T'", "T", shortName4);
        Assert.assertEquals("Return value 5 should be 'W'", "W", shortName5);
        Assert.assertEquals("Return value 6 should be 'W'", "W", shortName6);
        Assert.assertEquals("Return value 7 should be 'R'", "R", shortName7);
        Assert.assertEquals("Return value 8 should be 'R'", "R", shortName8);
        Assert.assertEquals("Return value 9 should be 'F'", "F", shortName9);
        Assert.assertEquals("Return value 10 should be 'F'", "F", shortName10);
    }

    /**
     * Verifies that Weekday comparisons are correct.
     */
    @Test
    public void comparisonTest() {
        boolean comparison1 = Weekday.MONDAY.compareTo(Weekday.TUESDAY) < 0;
        boolean comparison2 = Weekday.TUESDAY.compareTo(Weekday.WEDNESDAY) < 0;
        boolean comparison3 = Weekday.WEDNESDAY.compareTo(Weekday.THURSDAY) < 0;
        boolean comparison4 = Weekday.THURSDAY.compareTo(Weekday.FRIDAY) < 0;

        Assert.assertTrue("Monday should be considered less than Tuesday", comparison1);
        Assert.assertTrue("Tuesday should be considered less than Wednesday", comparison2);
        Assert.assertTrue("Wednesday should be considered less than Thursday", comparison3);
        Assert.assertTrue("Thursday should be considered less than Friday", comparison4);
    }
}
