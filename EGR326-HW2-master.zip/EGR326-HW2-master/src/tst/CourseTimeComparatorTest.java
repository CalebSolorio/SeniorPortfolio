package tst;

import main.*;
import org.junit.Assert;
import org.junit.Test;

import java.util.Set;
import java.util.TreeSet;

/**
 * This class stores test cases for the CourseCreditComparator class.
 * @author Caleb Solorio
 * @version 1.0 (Feb 1 2017)
 */
public class CourseTimeComparatorTest {
    /**
     * Tests the comparator's ability to compare by time.
     */
    @Test
    public void comparatorTest() {
        CourseTimeComparator comparator = new CourseTimeComparator();
        Set<Weekday> days = new TreeSet<>();
        days.add(Weekday.TUESDAY);
        days.add(Weekday.THURSDAY);
        Course course1 = new Course("EGR 326", 3, days, Time.fromString("02:00 PM"), 90);
        days.remove(Weekday.THURSDAY);
        Course course2 = new Course("EGR 304", 1, days, Time.fromString("03:45 PM"), 60);

        int comparison1 = comparator.compare(course1, course2);
        int comparison2 = comparator.compare(course2, course1);

        course1 = new Course("EGR 326", 3, days, Time.fromString("03:45 AM"), 90);
        int comparison3 = comparator.compare(course1, course2);

        course1 = new Course("EGR 326", 3, days, Time.fromString("03:45 PM"), 90);
        int comparison4 = comparator.compare(course1, course2);

        course1 = new Course("EGR 326", 3, days, Time.fromString("03:45 PM"), 59);
        int comparison5 = comparator.compare(course1, course2);

        course1 = new Course("EGR 326", 3, days, Time.fromString("03:45 PM"), 60);
        int comparison6 = comparator.compare(course1, course2);

        Assert.assertTrue(comparison1 < 0);
        Assert.assertTrue(comparison2 > 0);
        Assert.assertTrue(comparison3 < 0);
        Assert.assertTrue(comparison4 > 0);
        Assert.assertTrue(comparison5 < 0);
        Assert.assertTrue(comparison6 > 0);
    }
}
