package tst;

import main.*;
import org.junit.Assert;
import org.junit.Test;

import java.io.*;
import java.util.Set;
import java.util.TreeSet;

/**
 * This class stores test cases for the Schedule class.
 * @author Caleb Solorio
 * @version 1.0 (Feb 1 2017)
 */
public class ScheduleTest {
    /**
     * Tests the add() and totalCredits() functions of the Schedule class.
     */
    @Test
    public void addTotalCreditsTest() {
        Schedule schedule = new Schedule();

        Set<Weekday> days = new TreeSet<>();
        days.add(Weekday.TUESDAY);
        days.add(Weekday.THURSDAY);
        Course course1 = new Course("EGR 326", 3, days, Time.fromString("02:00 PM"), 90);
        days.remove(Weekday.THURSDAY);
        Course course2 = new Course("EGR 304", 1, days, Time.fromString("03:45 PM"), 60);

        schedule.add(course1);
        schedule.add(course2);
        int totalCredits = schedule.totalCredits();

        ScheduleConflictException error = null;
        try {
            schedule.add(course2);
        } catch (ScheduleConflictException e) {
            error = e;
        }

        Assert.assertEquals("The total number of credits should be 4", 4, totalCredits);
        Assert.assertTrue("Adding conflicting courses should throw an error", error != null);

    }

    /**
     * Tests the clone() function of the Schedule class.
     */
    @Test
    public void cloneTest() {
        Schedule schedule = new Schedule();

        Set<Weekday> days = new TreeSet<>();
        days.add(Weekday.TUESDAY);
        schedule.add(new Course("EGR 326", 3, days, Time.fromString("02:00 PM"), 90));
        days.add(Weekday.THURSDAY);
        schedule.add(new Course("EGR 304", 1, days, Time.fromString("03:45 PM"), 60));
        Schedule copy = schedule.clone();

        boolean comparison1 = schedule.totalCredits() == copy.totalCredits();
        schedule.add(new Course("EGR 325", 3, days, Time.fromString("07:00 AM"), 60));
        boolean comparison2 = schedule.totalCredits() == copy.totalCredits();

        Assert.assertTrue("The original and copy objects should be equal", comparison1);
        Assert.assertFalse("The original and copy objects should not reference the same list", comparison2);
    }

    /**
     * Tests the getCourse() method of the Schedule class.
     */
    @Test
    public void getCourseTest() {
        Schedule schedule = new Schedule();

        Set<Weekday> days = new TreeSet<>();
        days.add(Weekday.TUESDAY);
        schedule.add(new Course("EGR 326", 3, days, Time.fromString("02:00 PM"), 90));
        days.add(Weekday.THURSDAY);
        schedule.add(new Course("EGR 304", 1, days, Time.fromString("03:45 PM"), 60));

        boolean courseExists1 = schedule.getCourse(Weekday.TUESDAY, Time.fromString("01:59 PM")) != null;
        boolean courseExists2 = schedule.getCourse(Weekday.TUESDAY, Time.fromString("02:00 PM")) != null;
        boolean courseExists3 = schedule.getCourse(Weekday.TUESDAY, Time.fromString("03:00 PM")) != null;
        boolean courseExists4 = schedule.getCourse(Weekday.THURSDAY, Time.fromString("03:00 PM")) != null;
        boolean courseExists5 = schedule.getCourse(Weekday.TUESDAY, Time.fromString("03:30 PM")) != null;
        boolean courseExists6 = schedule.getCourse(Weekday.TUESDAY, Time.fromString("03:37 PM")) != null;
        boolean courseExists7 = schedule.getCourse(Weekday.THURSDAY, Time.fromString("03:37 PM")) != null;
        boolean courseExists8 = schedule.getCourse(Weekday.TUESDAY, Time.fromString("03:47 PM")) != null;
        boolean courseExists9 = schedule.getCourse(Weekday.THURSDAY, Time.fromString("03:47 PM")) != null;

        Assert.assertFalse(courseExists1);
        Assert.assertTrue(courseExists2);
        Assert.assertTrue(courseExists3);
        Assert.assertFalse(courseExists4);
        Assert.assertFalse(courseExists5);
        Assert.assertFalse(courseExists6);
        Assert.assertFalse(courseExists7);
        Assert.assertTrue(courseExists8);
        Assert.assertTrue(courseExists9);
    }

    /**
     * Tests the remove() method of the Schedule class.
     */
    @Test
    public void removeTest() {
        Schedule schedule = new Schedule();

        Set<Weekday> days = new TreeSet<>();
        days.add(Weekday.TUESDAY);
        schedule.add(new Course("EGR 326", 3, days, Time.fromString("02:00 PM"), 90));
        days.add(Weekday.THURSDAY);
        schedule.add(new Course("EGR 304", 1, days, Time.fromString("03:45 PM"), 60));

        Schedule copy = schedule.clone();
        boolean comparison1 = schedule.totalCredits() == copy.totalCredits();
        schedule.remove(Weekday.WEDNESDAY, Time.fromString("03:47 PM"));
        boolean comparison2 = schedule.totalCredits() == copy.totalCredits();
        schedule.remove(Weekday.TUESDAY, Time.fromString("03:47 PM"));
        boolean comparison3 = schedule.totalCredits() == copy.totalCredits();

        Assert.assertTrue("The original and copy objects should be equal", comparison1);
        Assert.assertTrue("The original and copy objects should be equal even after removal " +
                "of a non-existent course", comparison2);
        Assert.assertFalse("The original and copy objects should not reference the same list", comparison3);
    }

    /**
     * Tests the save() method of the Schedule class.
     */
    @Test
    public void saveTest() {
        Schedule schedule = new Schedule();

        Set<Weekday> days = new TreeSet<>();
        days.add(Weekday.TUESDAY);
        Course course1 = new Course("EGR 304", 1, days, Time.fromString("03:45 PM"), 60);
        schedule.add(course1);
        days.add(Weekday.THURSDAY);
        Course course2 = new Course("EGR 326", 3, days, Time.fromString("02:00 PM"), 90);
        schedule.add(course2);
        Course course3 = new Course("CSC 329", 3, days, Time.fromString("07:00 AM"), 60);
        schedule.add(course3);

        try {
            String nameAddress = "src/resources/nameSort.txt";
            String creditAddress = "src/resources/creditSort.txt";
            String timeAddress = "src/resources/timeSort.txt";

            schedule.save(new PrintStream(nameAddress), new CourseNameComparator());
            schedule.save(new PrintStream(creditAddress), new CourseCreditComparator());
            schedule.save(new PrintStream(timeAddress), new CourseTimeComparator());

            boolean verify1 = verifySort(new FileReader(nameAddress),
                    course3, course1, course2);
            boolean verify2 = verifySort(new FileReader(creditAddress),
                    course1, course3, course2);
            boolean verify3 = verifySort(new FileReader(timeAddress),
                    course3, course2, course1);

            Assert.assertTrue("Incorrect name sort", verify1);
            Assert.assertTrue("Incorrect credit sort", verify2);
            Assert.assertTrue("Incorrect time sort", verify3);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    // Helps saveTest() by verifying the integrity of the save() method of the Schedule class.
    private boolean verifySort(FileReader file, Course course1, Course course2, Course course3) {
        BufferedReader reader = new BufferedReader(file);
        try {
            boolean matches1 = reader.readLine().equals(course1.toString());
            boolean matches2 = reader.readLine().equals(course2.toString());
            boolean matches3 = reader.readLine().equals(course3.toString());

            return matches1 && matches2 && matches3 ? true : false;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }
}
