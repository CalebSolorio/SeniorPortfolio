# EGR326-HW2
Docs: https://calebsolorio.github.io/EGR326-HW2/index.html
