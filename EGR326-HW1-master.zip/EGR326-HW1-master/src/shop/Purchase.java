package shop;// Caleb Solorio
// Assigment #1: Shopping Cart
// Friday, January 20, 2017
// EGR 326, Section A
//
// This class stores information about an order of a specific items for a specific amount.

public class Purchase {
    private Item item;
    private int quantity;

    // Takes in an item object and the desired quantity of this item,
    // assigning them to variables accordingly.
    public Purchase(Item item, int quantity) {
        this.item = item;
        this.quantity = quantity;
    }

    // Returns the price for the purchase item at the purchase quantity.
    public double getPrice() {
        return item.priceFor(quantity);
    }

    // Returns the purchase quantity.
    public int getQuantity() {
        return quantity;
    }

    // Takes in a new quantity amount and assigns that value accordingly.
    public void updateQuantity(int newQuantity) {
        quantity = newQuantity;
    }

    // Returns true if the purchase quantity is zero. Otherwise, return false.
    public boolean isEmpty() { return quantity == 0; }

    // Takes in a purchase object and determines if the purchase item is the same in each.
    // If so, return true; otherwise, return false.
    public boolean matches(Purchase purchase) {
        return this.item == purchase.item;
    }
}
