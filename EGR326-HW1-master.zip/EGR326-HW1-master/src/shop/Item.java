package shop;// Caleb Solorio
// Assigment #1: Shopping Cart
// Friday, January 20, 2017
// EGR 326, Section A
//
// This class stores information about a single item available for purchase.

public class Item {
    private String name;
    private double price;

    // Takes in a name and price and assigns these variables accordingly
    public Item(String name, double price) {
        this.name = name;
        this.price = price;
    }

    // Returns this item's name
    public String getName() {
        return name;
    }

    // Takes in a quantity. Calculates how much this quantity of this item would cost
    // and returns the result.
    public double priceFor(int quantity) {
        return quantity * price;
    }

    // Returns a string summarizing the name of the item and it's price (eg. "Eggs, $3.99");
    public String toString() {
        return name + ", $" + String.format("%.2f", price);
    }
}
