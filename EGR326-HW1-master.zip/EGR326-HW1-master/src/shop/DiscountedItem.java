package shop;

// Caleb Solorio
// Assigment #1: Shopping Cart
// Friday, January 20, 2017
// EGR 326, Section A
//
// This class is a subclass of Item. It stores information about an item's
// discounted price when a certain quantity of the item is purchased.

import java.text.DecimalFormat;
import java.text.NumberFormat;

public class DiscountedItem extends Item {
    private int bulkQuantity;
    private double bulkPrice;

    // Takes in an item name, price for one of that item,
    // the quantity of the item required for a discount, and the price for that quantity of an item.
    // It calls the Item's constructore to assign the name and single-item price before assigning
    // the bulk quantity and bulk price.
    public DiscountedItem(String name, double price,
                          int bulkQuantity, double bulkPrice) {
        super(name, price);

        this.bulkQuantity = bulkQuantity;
        this.bulkPrice = bulkPrice;
    }

    // Calls the toString method of the Item class to return a summary the item's name and price.
    // That string is then concatenated with a string summarizing the bulk quantity and bulk price.
    // This string is returned.
    public String toString() {
        return super.toString() + " (" + bulkQuantity + " for $"
                + String.format("%.2f", bulkPrice) + ")";
    }

    // Takes in a certain quantity and checks to see if that number qualifies for a discount.
    // Returns the total cost to two decimal places, applying discounts if applicable.
//    @Override
    public double priceFor(int quantity) {
        if(quantity >= bulkQuantity) {
            int appliedNum = quantity / bulkQuantity;
            int remainder = quantity % bulkQuantity;

            return Double.valueOf(String.format("%.2f", bulkPrice * appliedNum + super.priceFor(remainder)));
        }
        return super.priceFor(quantity);
    }

}
