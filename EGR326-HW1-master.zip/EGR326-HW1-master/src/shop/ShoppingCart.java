package shop;

import java.util.ArrayList;
import java.util.List;

// Caleb Solorio
// Assigment #1: Shopping Cart
// Friday, January 20, 2017
// EGR 326, Section A
//
// This class stores information about all of the customer's current purchase orders.

public class ShoppingCart {
    private boolean applyDiscount;
    private List<Purchase> purchases;

    // Returns the assigned discountPercentage amount.
    public static double getDiscountPercentage() {
        return 10;
    }

    // Returns the assigned discountQuantity amount.
    public static int getDiscountQuantity() {
        return 20;
    }

    // Initializes an empty collection of purchases.
    // Indicates that a discount should not yet be applied.
    public ShoppingCart() {
        purchases = new ArrayList<>();
        applyDiscount = false;
    }

    // Takes in a purchase object. If the purchase item is already in the collection of purchases,
    // simply update the order with the new purchase object's quantity.
    // Otherwise, add the given object to the collection of purchases.
    public void add(Purchase purchase) {
        for(Purchase p: purchases) {
            if(p.matches(purchase)) {
                p.updateQuantity(purchase.getQuantity());
                return;
            }
        }

        purchases.add(purchase);
    }

    // Empties the collection of purchases by reinitializing it.
    public void clearAll() {
        purchases = new ArrayList<>();
    }

    // Calculates the amount required to pay for
    // all the purchase orders and returns this value, discounting if appropriate.
    public double getTotal() {
        double sum = 0;
        int count = 0;

        for(Purchase purchase: purchases) {
            sum += purchase.getPrice();
            count += purchase.getQuantity();
        }
        if(applyDiscount && count >= getDiscountQuantity()) {
            sum *= .01 * (100- getDiscountPercentage());
        }

        return sum;
    }

    // Returns the value of the variable determining if a discount should be applied.
    public boolean hasDiscount() {
        return applyDiscount;
    }

    // Takes in a boolean value and sets applyDiscount to this value.
    public void setDiscount(boolean applyDiscount) {
        this.applyDiscount = applyDiscount;
    }

    // Calculates the total number of items ordered and returns this value.
    public int totalQuantity() {
        int count = 0;

        for(Purchase purchase: purchases) {
            count += purchase.getQuantity();
        }

        return count;
    }
}
