package shop;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

// Caleb Solorio
// Assigment #1: Shopping Cart
// Friday, January 20, 2017
// EGR 326, Section A
//
// This class stores store name and information about a every item available for purchase.

public class Catalog implements Iterable<Item> {
    private String storeName;
    private List<Item> items;

    // Takes in a name for the store and assigns it accordingly
    // before initializing an empty item list.
    public Catalog(String storeName) {
        this.storeName = storeName;
        this.items = new ArrayList<>();
    }

    // Takes in an Item and adds it to the catalog list.
    public void add(Item item) {
        items.add(item);
    }

    // Takes in a string and returns an item in the catalog,
    // if any, whose name matches the string.
    public Item getItem(String name) {
        for(Item item: items) {
            if(item.getName() == name) {
                return item;
            }
        }

        return null;
    }

    // Returns the name of the store.
    public String getStoreName() {
        return storeName;
    }

    // Returns an iterator over all items in the catalog
    // in the order they were added to the catalog.
    public Iterator<Item> iterator() {
        return items.iterator();
    }

}
