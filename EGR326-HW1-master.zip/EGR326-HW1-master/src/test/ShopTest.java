package test;

import org.junit.Assert;
import org.junit.Test;
import shop.*;

import java.util.Iterator;

// Caleb Solorio
// Assigment #1: Shopping Cart
// Friday, January 20, 2017
// EGR 326, Section A
//
// This class contain JUnit tests to ensure maximum functionality/code coverage.

public class ShopTest {
    // Tests the getName() method of class Item.
    @Test
    public void itemGetNameTest() {
        String name = "Alan Greenspan's Autobiography";
        double price = 17.99;
        Item item = new Item(name, price);

        String nameReturn = item.getName();

        Assert.assertEquals("Incorrect name", name, nameReturn);
    }

    // Tests the priceFor() method of class Item.
    @Test
    public void itemPriceForTest() {
        String name = "Alan Greenspan's Autobiography";
        double price = 17.99;
        int quantity = 70;
        Item item = new Item(name, price);

        double expectedPriceReturn = price * quantity;
        double actualPriceReturn = item.priceFor(quantity);

        Assert.assertEquals("Incorrect price calculation", expectedPriceReturn, actualPriceReturn, 0.00);
    }

    // Tests the toString() method of class Item.
    @Test
    public void itemToStringTest() {
        String name = "Alan Greenspan's Autobiography";
        double price = 17.99;
        Item item = new Item(name, price);

        String stringReturn = item.toString();

        Assert.assertEquals("Incorrect string value",
                "Alan Greenspan's Autobiography, $17.99", stringReturn);
    }

    // Tests the various methods of class DiscountedItem.
    @Test
    public void discountedItemToStringTest() {
        String name = "'I'm With Her' T-Shirt";
        double price = 12.99;
        int bulkQuantity = 5;
        double bulkPrice = 49.99;
        DiscountedItem item = new DiscountedItem(name, price, bulkQuantity, bulkPrice);

        String expectedString = "'I'm With Her' T-Shirt, $12.99 (5 for $49.99)";
        String actualString = item.toString();

        Assert.assertEquals("Incorrect return string", expectedString, actualString);
    }

    // Tests the various methods of class DiscountedItem.
    @Test
    public void discountedItemPriceForTest() {
        String name = "'I'm With Her' T-Shirt";
        double price = 12.99;
        int bulkQuantity = 5;
        double bulkPrice = 49.99;
        DiscountedItem item = new DiscountedItem(name, price, bulkQuantity, bulkPrice);

        double price1 = item.priceFor(4);
        double price2 = item.priceFor(5);
        double price3 = item.priceFor(6);

        Assert.assertEquals("Incorrect price1", 51.96, price1, 0.00);
        Assert.assertEquals("Incorrect price2", 49.99, price2, 0.00);
        Assert.assertEquals("Incorrect price3", 62.98, price3, 0.00);
    }

    // Tests the various methods of class Catalog.
    @Test
    public void catalogGetItemTest() {
        String storeName = "Mom and Pop Thrift Shop";
        String itemName = "Antique 3-legged chair";
        double itemPrice = 17.99;
        Item item1 = new Item(itemName, itemPrice);
        itemName = "Encyclopedia Brown and the Mystery of Declining Book Sales";
        Item item2 = new Item(itemName, itemPrice);

        Catalog catalog = new Catalog(storeName);
        catalog.add(item1);
        catalog.add(item2);

        Item getItemRet = catalog.getItem(itemName);
        Item getItemRetNull = catalog.getItem("Customer");

        Assert.assertEquals("Incorrect item returned", item2, getItemRet);
        Assert.assertEquals("Return item should be null", null, getItemRetNull);
    }

    // Tests the various methods of class Catalog.
    @Test
    public void catalogGetStoreNameTest() {
        String storeName = "Mom and Pop Thrift Shop";
        Catalog catalog = new Catalog(storeName);

        String storeNameRet = catalog.getStoreName();

        Assert.assertEquals("Incorrect string returned", storeName, storeNameRet);
    }

    @Test
    public void catalogIteratorTest() {
        String storeName = "Mom and Pop Thrift Shop";
        String itemName = "Antique 3-legged chair";
        double itemPrice = 17.99;
        Item item1 = new Item(itemName, itemPrice);
        itemName = "Encyclopedia Brown and the Mystery of Declining Book Sales";
        Item item2 = new Item(itemName, itemPrice);

        Catalog catalog = new Catalog(storeName);
        catalog.add(item1);
        catalog.add(item2);
        Iterator<Item> itr = catalog.iterator();

        Item itrItemRet = itr.next();

        Assert.assertEquals("Iterator results are out of order", item1, itrItemRet);
    }

    // Tests the methods updateQuantity() and getPrice() of class Purchase.
    @Test
    public void purchaseGetPriceTest() {
        String name = "Silver Spork Set";
        double price = 19.99;
        int quantity = 0;
        Item item = new Item(name, price);
        Purchase purchase = new Purchase(item, quantity);

        quantity = 2;
        purchase.updateQuantity(quantity);
        double actualPrice = purchase.getPrice();

        Assert.assertEquals("Incorrect price", price * quantity, actualPrice, 0.00);
    }

    // Tests the isEmpty() method of class Purchase.
    @Test
    public void purchaseIsEmptyTest() {
        String name = "Silver Spork Set";
        double price = 19.99;
        int quantity = 0;
        Item item = new Item(name, price);
        Purchase purchase = new Purchase(item, quantity);

        boolean isEmpty1 = purchase.isEmpty();
        purchase.updateQuantity(1);
        boolean isEmpty2 = purchase.isEmpty();


        Assert.assertTrue("Should be considered empty", isEmpty1);
        Assert.assertFalse("Should not be considered empty", isEmpty2);
    }

    // Tests the getQuantity() method of class Purchase.
    @Test
    public void purchaseGetQuantityTest() {
        String name = "Silver Spork Set";
        double price = 19.99;
        int quantity = 2;
        Item item = new Item(name, price);
        Purchase purchase = new Purchase(item, quantity);

        int actualQuantity = purchase.getQuantity();

        Assert.assertEquals("Incorrect quantity", quantity, actualQuantity);
    }

    // Tests the matches() method of class Purchase.
    @Test
    public void purchaseMatchesTest() {
        String name = "Silver Spork Set";
        double price = 19.99;
        int quantity = 0;
        Item item = new Item(name, price);
        Purchase purchase1 = new Purchase(item, quantity);
        Purchase purchase2 = new Purchase(item, quantity + 1);

        boolean matches1 = purchase1.matches(purchase2);
        name = "Plastic Spork Set";
        item = new Item(name, price);
        purchase2 = new Purchase(item, quantity);
        boolean matches2 = purchase1.matches(purchase2);

        Assert.assertTrue("Should be considered true", matches1);
        Assert.assertFalse("Should be considered false", matches2);
    }

    // Tests the hasDiscount() method of class ShoppingCart.
    @Test
    public void shoppingCartHasDiscountTest() {
        ShoppingCart shoppingCart = new ShoppingCart();

        boolean hasDiscount1 = shoppingCart.hasDiscount();
        shoppingCart.setDiscount(true);
        boolean hasDiscount2 = shoppingCart.hasDiscount();

        Assert.assertFalse("Discount should not be applied", hasDiscount1);
        Assert.assertTrue("Discount should be applied", hasDiscount2);
    }

    // Tests the getDiscountPercentage() method of class ShoppingCart.
    @Test
    public void shoppingCartGetDiscountPercentageTest() {
        ShoppingCart shoppingCart = new ShoppingCart();
        double discountPercentage = shoppingCart.getDiscountPercentage();

        Assert.assertEquals("Incorrect Percentage", 10, discountPercentage, 0.00);
    }

    // Tests the getDiscountQuantity() method of class ShoppingCart.
    @Test
    public void shoppingCartGetDiscountQuantityTest() {
        ShoppingCart shoppingCart = new ShoppingCart();
        double discountQuantity = shoppingCart.getDiscountQuantity();

        Assert.assertEquals("Incorrect Percentage", 20, discountQuantity, 0.00);
    }

    // Tests the getTotal and clearAll() methods of class ShoppingCart.
    @Test
    public void shoppingCartGetTotalTest() {
        String name = "Apple";
        double price = .89;
        int quantity = 1;
        double expectedTotal1 = price * quantity;
        Item item = new Item(name, price);
        Purchase purchase1 = new Purchase(item, quantity);

        name = "Banana";
        price = 1;
        quantity = 20;
        expectedTotal1 += (price * quantity);
        Item item2 = new Item(name, price);
        Purchase purchase2 = new Purchase(item2, quantity);

        ShoppingCart shoppingCart = new ShoppingCart();

        shoppingCart.add(purchase1);
        shoppingCart.clearAll();
        shoppingCart.add(purchase1);
        shoppingCart.add(purchase2);

        double actualTotal = shoppingCart.getTotal();

        shoppingCart.setDiscount(true);
        double expectedTotal2 = expectedTotal1 * ((100 - shoppingCart.getDiscountPercentage()) / 100);
        double actualTotal2 = shoppingCart.getTotal();

        Assert.assertEquals("Incorrect total", expectedTotal1, actualTotal, 0.00);
        Assert.assertEquals("Incorrect total", expectedTotal2, actualTotal2, 0.00);
    }

    // Tests the totalQuantity method of class ShoppingCart.
    @Test
    public void shoppingCartTest() {
        String name = "Apple";
        double price = .89;
        int quantity = 1;
        int expectedQuantity = quantity;
        Item item = new Item(name, price);
        Purchase purchase1 = new Purchase(item, quantity);

        name = "Banana";
        price = 1;
        quantity = 20;
        expectedQuantity += quantity;
        Item item2 = new Item(name, price);
        Purchase purchase2 = new Purchase(item2, quantity);

        ShoppingCart shoppingCart = new ShoppingCart();
        shoppingCart.add(purchase1);
        shoppingCart.add(purchase2);

        int actualQuantity = shoppingCart.totalQuantity();

        Assert.assertEquals("Incorrect Quantity", expectedQuantity, actualQuantity);
    }

}
