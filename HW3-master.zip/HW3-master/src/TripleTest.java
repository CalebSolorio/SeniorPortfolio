import org.junit.Assert;
import org.junit.Test;

/**
 * Created by Caleb Solorio on 9/26/2016.
 */
public class TripleTest {

    @Test
    public void leftTest() {
        Triple triple = new Triple(1, 1, 1);

        Assert.assertEquals("Integer wrong", 1, triple.getLeft());

        triple.setLeft(1.111);
        Assert.assertEquals("Double wrong", 1.111, triple.getLeft());

        triple.setLeft("one");
        Assert.assertEquals("String wrong", "one", triple.getLeft());
    }

    @Test
    public void middleTest() {
        Triple triple = new Triple(2, 2, 2);

        Assert.assertEquals("Integer wrong", 2, triple.getMiddle());

        triple.setMiddle(2.222);
        Assert.assertEquals("Double wrong", 2.222, triple.getMiddle());

        triple.setMiddle("two");
        Assert.assertEquals("String wrong", "two", triple.getMiddle());
    }

    @Test
    public void rightTest() {
        Triple triple = new Triple(3, 3, 3);

        Assert.assertEquals("Integer wrong", 3, triple.getRight());

        triple.setRight(3.333);
        Assert.assertEquals("Double wrong", 3.333, triple.getRight());

        triple.setRight("three");
        Assert.assertEquals("String wrong", "three", triple.getRight());
    }

    @Test
    public void toStringTest() {
        Triple triple = new Triple(1, 2.222, "three");

        Assert.assertEquals("Returned incorrect string", "(1, 2.222, three)", triple.toString());
    }
}
