// This function returns all the drugs from the database.

console.log('Loading getDrug function...');

var mysql = require('mysql');

exports.handler = function(event, context, callback) {
	// Establish a connection with our RDS instance.
	var connection = mysql.createConnection({
	  host     : '<HOST>',
	  user     : '<USER>',
	  password : '<PASSWORD>',
	  port     : '3306',
	  database : '<DATABASE>',
	});
	
	connection.connect();
	
	var iComplete = false;
	var tComplete = false;
	var tgComplete = false;
	var data = [{}];
	
	var tagged = [];
	
	// First find the drugs. Then add the misc. details.
	connection.query('SELECT * FROM Drugs', function(err, result) {
		if(err) {
			context.fail(err);
		} else {
			for(var i = 0; i < result.length; i++)(function(i) {
				data[i] = {
					SubjectId: result[i].D_Id,
					title: decodeURIComponent(result[i].title),
					toxicity: result[i].toxicity,
					isDraft: Boolean(result[i].isDraft),
					propic: decodeURIComponent(result[i].propic),
				};
				
				// Add relevant images.
				connection.query('SELECT * FROM Images WHERE D_Id = ?', 
						result[i].D_Id, function(err, iResult) {
					if(err) {
						context.fail(err);	
					} else {
						if(iResult.length > 0) {
							data[i].images = [];
							for(var j = 0; j < iResult.length; j++)(function(j) {
								data[i].images[j] = 
									decodeURIComponent(iResult[j].address);
								
								if(i == result.length - 1 && j == iResult.length - 1) {
									iComplete = true;
									if(iComplete && tComplete && tgComplete) {
										// Return data.
										callback(null, data);
										connection.end();
									}	
								}
								
							})(j);	
						} else {
							if(i == result.length - 1) {
								iComplete = true;
								if(iComplete && tComplete && tgComplete) {
									// Return data.
									callback(null, data);
									connection.end();
								}
							}	
						}
					}
				});
				
				// Add relevant topics
				connection.query('SELECT * FROM Topics WHERE D_Id = ?', 
						result[i].D_Id, function(err, tResult) {
					if(err) {
						context.fail(err);	
					} else {
						if(tResult.length > 0) {
							data[i].topics = [];
							for(var j = 0; j < tResult.length; j++)(function(j) {
								
								data[i].topics[j] = {
									title: decodeURIComponent(tResult[j].title),
									body: decodeURIComponent(tResult[j].body)
								};
								
								if(i == result.length - 1 && j == tResult.length - 1) {
									tComplete = true;
									if(iComplete && tComplete && tgComplete) {
										// Return data.
										callback(null, data);
										connection.end();
									}	
								}
								
							})(j);	
						} else {
							if(i == result.length - 1) {
								tComplete = true;
								if(iComplete && tComplete && tgComplete) {
									// Return data.
									callback(null, data);
									connection.end();
								}	
							}
						}
					}
				});
				
				// Record the locations of the relevant tags.
				// Then use assignTags() to add them to the return data.
				connection.query('SELECT * FROM Tagged WHERE D_Id = ?', 
						result[i].D_Id, function(err, tdResult) {
					if(err) {
						context.fail(err);	
					} else {
						if(tdResult.length > 0) {
							tagged.push({
								i: i,
								tdResult: tdResult
							});
						}
						
						if(i == result.length - 1) {
							assignTags(tagged);
						}
					}
				});
			})(i);
		}
	});
	
	// Find tags from the given information and add them to the return object.
	// Fix to a bug that caused 0 tags to return unless the last drug added had tags.
	function assignTags(tagged) {
		if(tagged.length > 0) {
			for(var i = 0; i < tagged.length; i++)(function(i){
				data[tagged[i].i].tags = [];
				
				for(var j = 0; j < tagged[i].tdResult.length; j++)(function(j) {
					connection.query('SELECT * FROM Tags WHERE T_Id = ' 
							+ tagged[i].tdResult[j].T_Id + ' LIMIT 1', 
							function(err, tgResult) {
						if(err) {
							context.fail();	
						} else {
							data[tagged[i].i].tags[j] = 
								decodeURIComponent(tgResult[0].title);
							
							if(j == tagged[i].tdResult.length - 1){
								if(i == tagged.length - 1) {
									tgComplete = true;
									if(iComplete && tComplete && tgComplete) {
										// Return data.
										callback(null, data);
										connection.end();
									}
								}	
							}
						}
					});
				})(j);
			})(i);	
		} else {
			tgComplete = true;
			if(iComplete && tComplete && tgComplete) {
				// Return data.
				callback(null, data);
				connection.end();
			}
		}
	}
};
