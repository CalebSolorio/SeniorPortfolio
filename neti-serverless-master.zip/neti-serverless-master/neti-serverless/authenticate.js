// This function will run before any manipulation of the database and check for authorization.

console.log('Loading authentication function...');

var mysql = require('mysql');
var cryptojs = require('crypto-js');

exports.handler = function(event, context, callback) {
	// Establish a connection with our RDS instance.
	var connection = mysql.createConnection({
	  host     : '<HOST>',
	  user     : '<USER>',
	  password : '<PASSWORD>',
	  port     : '3306',
	  database : '<DATABASE>',
	});
	
	connection.connect();
	
	// Pick out the authentication token from the request body.
	var token = event.authorizationToken;
	
	// Find a hashed token that matches the clients.
	if(token !== undefined) {
		connection.query('SELECT * FROM Tokens WHERE tkHash = "' + 
				cryptojs.MD5(token).toString() + '" LIMIT 1',
				function(err, result) {
			if(err)	{
				console.log(err);
				context.fail(err);
				connection.end();
			} else {
				if(result[0] !== undefined ) {
					context.succeed(generatePolicy('user', 'Allow', 
						"<RESOURCE>"));
					connection.end();
				} else {
					context.fail("Not valid token. Access Denied.");
					connection.end();
				}
			}		
		});
	} else {
		console.log("token undefined");
		context.fail("No token given.");
		connection.end();
	}
	
	// This function generates a policy for the end user.
	var generatePolicy = function(principalId, effect, resource) {
		console.log("Generating policy");
	    var authResponse = {};
	    authResponse.principalId = principalId;
	    if (effect && resource) {
	        var policyDocument = {};
	        policyDocument.Version = '2012-10-17'; // default version
	        policyDocument.Statement = [];
	        var statementOne = {};
	        statementOne.Action = 'execute-api:Invoke'; // default action
	        statementOne.Effect = effect;
	        statementOne.Resource = resource;
	        policyDocument.Statement[0] = statementOne;
	        authResponse.policyDocument = policyDocument;
	    }
	    return authResponse;
	}
};
