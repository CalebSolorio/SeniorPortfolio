// This function adds a drug and its respective info to the database.

console.log('Loading putDrug function...');

var mysql = require('mysql');
var _ = require('underscore');

exports.handler = function(req, res, callback) {
	// Pick out the values that we want to work with.
	var body = _.pick(req, 'id', 'title', 'toxicity', 'isDraft', 'propic', 
		'tags', 'topics', 'images');
	var dComplete;
	var iComplete;
	var tComplete;
	var tgComplete;
	var id;
	
	var putComplete = false;
	
	console.log(body);
	
	if(!body.propic)
		body.propic = 'https://s3.amazonaws.com/netiapp/Client/rsz_hidta_logo_14.png';
	
	// Establish a connection with our RDS instance.
	var connection = mysql.createConnection({
	  host     : '<HOST>',
	  user     : '<USER>',
	  password : '<PASSWORD>',
	  port     : '3306',
	  database : '<DATABASE>',
	});
	
	connection.connect();
	
	// Check to see if the drug exists in the db. 
	// If so, update it and delete it's topics/tags/photos.
	if(body.title !== undefined) {
		
		if(body.toxicity === undefined 
				|| body.toxicity < 0 || body.toxicity > 3) {
			body.toxicity = 1;
		}
		
		if(body.isDraft === undefined 
				|| (body.isDraft != true && body.isDraft != false)) {
			body.isDraft = true;
		}
		
		if(body.propic.match(new RegExp(/imgur.com\/(.{7})/)) == null) {
			body.propic = "https://s3.amazonaws.com/netiapp/Client/rsz_hidta_logo_14.png";
		}
		
		console.log("title exists");
		if(body.id !== undefined) {
			console.log("id exists");
			connection.query('SELECT * From Drugs WHERE D_Id = ' + body.id
					+ ' LIMIT 1', function(err, result) {
				if(err) {
					res.fail(err);
				} else if(result[0] !== undefined) {
					console.log("found a matching id");
					var dChecklist = 0;
					connection.query('UPDATE Drugs SET title = "' 
							+ encodeURIComponent(body.title) + '", toxicity = ' 
							+ body.toxicity + ', isDraft = ' 
							+ body.isDraft + ', propic = "' 
							+ encodeURIComponent(body.propic) 
							+ '" WHERE D_Id = ' + body.id, function(err, result) {
						if(err) {
							res.fail(err);
						} else {
							id = body.id;
							dChecklist++;
							if(dChecklist == 4) {
								dComplete = true;
								if(dComplete && iComplete && tComplete 
										&& tgComplete && !putComplete) {
							  		callback(null, { status : 201 });
							  		// Terminate the connection
									connection.end();
									putComplete = true;
							  	} else {
							  		insertMisc();
							  	}
							}
						}
					});
					connection.query('DELETE FROM Images WHERE D_Id = ' 
							+ body.id, function(err, result) {
						if(err) {
							res.fail(err);
						} else {
							dChecklist++;
							if(dChecklist == 4) {
								if(dChecklist == 4) {
									dComplete = true;
									if(dComplete && iComplete && tComplete 
											&& tgComplete && !putComplete) {
								  		callback(null, { status : 201 });
								  		// Terminate the connection
										connection.end();
										putComplete = true;
								  	} else {
								  		insertMisc();
								  	}
								}
							}
						}
					});
					connection.query('DELETE FROM Topics WHERE D_Id = ' 
							+ body.id, function(err, result) {
						if(err) {
							res.fail(err);
						} else {
							dChecklist++;
							if(dChecklist == 4) {
								dComplete = true;
								if(dComplete && iComplete && tComplete 
										&& tgComplete && !putComplete) {
							  		callback(null, { status : 201 });
							  		// Terminate the connection
									connection.end();
									putComplete = true;
							  	} else {
							  		insertMisc();
							  	}
							}
						}
					});
					connection.query('DELETE FROM Tagged WHERE D_Id = ' 
							+ body.id, function(err, result) {
						if(err) {
							res.fail(err);
						} else {
							dChecklist++;
							if(dChecklist == 4) {
								dComplete = true;
								if(dComplete && iComplete && tComplete 
										&& tgComplete && !putComplete) {
							  		callback(null, { status : 201 });
							  		// Terminate the connection
									connection.end();
									putComplete = true;
							  	} else {
							  		insertMisc();
							  	}
							}
						}
					});
				} else {
					console.log("no id found");
					callback(null, { status: 404, 
						errorMessage: "Item not located." });
					connection.end();
				}
			});		
		} else {
			// Query the values in the DB instance.
			connection.query('INSERT INTO Drugs VALUES (NULL, "' 
					+ encodeURIComponent(body.title) 
					+ '", ' + body.toxicity + ', ' + Boolean(body.isDraft) 
					+ ', "' + encodeURIComponent(body.propic) + '")', 
					function(err, result) {
			  if (err) {
			  	res.fail(err);
			  } else {
			  	id = result.insertId;
			  	console.log(id);
			  	dComplete = true;
				if(dComplete && iComplete && tComplete 
						&& tgComplete && !putComplete) {
			  		callback(null, { status : 201 });
			  		// Terminate the connection
					connection.end();
					putComplete = true;
			  	} else {
			  		insertMisc();
			  	}
			  }
			});
		}
		
	} else {
		callback(null, { status : 400 });
		// Terminate the connection
		connection.end();
	}
	
	// Once the drug has been made/located, inset topics/tags/images.
	function insertMisc() {
		if(dComplete){
			console.log("dComplete");
			if(body.images !== undefined && body.images.length > 0) {
		  		for(var i = 0; i < body.images.length; i++)(function(i) {
		  			
		  			if(body.images[i].match(new RegExp(/imgur.com\/(.{7})/)) == null) {
						body.images[i] = "https://s3.amazonaws.com/netiapp/Client/rsz_hidta_logo_14.png";
					}
		  			
			  		connection.query('INSERT INTO Images VALUES (NULL, "' 
			  				+ encodeURIComponent(body.images[i]) 
						+ '", ' + id + ')', function(err, pResult) {
						if(err) {
							res.fail(err);
						} else {
							console.log("iComplete");
					  		iComplete = true;
					  		if(dComplete && iComplete && tComplete 
					  				&& tgComplete && !putComplete) {
					  			console.log("Finish 183");
						  		callback(null, { status : 201 });
						  		// Terminate the connection
								connection.end();
								putComplete = true;
						  	}
						}
					});
			  	})(i);	
		  	} else {
		  		console.log("No images");
		  		iComplete = true;
		  		if(dComplete && iComplete && tComplete 
		  				&& tgComplete && !putComplete) {
		  			console.log("finish 195");
			  		callback(null, { status : 201 });
			  		// Terminate the connection
					connection.end();
					putComplete = true;
			  	}
		  	}
		  	
		  	if(body.topics !== undefined && body.topics.length > 0) {
		  		for(var j = 0; j < body.topics.length; j++)(function(j) {
			  		connection.query('INSERT INTO Topics VALUES (NULL, "' 
			  				+ encodeURIComponent(body.topics[j].title) 
							+ '", "' + encodeURIComponent(body.topics[j].body) 
							+ '", ' + id + ')', function(err, aResult) {
						if(err) {
							res.fail(err);
						} else {
							console.log("tComplete");
					  		tComplete = true;
					  		if(dComplete && iComplete && tComplete 
					  				&& tgComplete && !putComplete) {
					  			console.log("finish 215");
						  		callback(null, { status : 201 });
						  		// Terminate the connection
								connection.end();
								putComplete = true;
						  	}
						}
					});
		  		})(j);
		  	} else {
		  		console.log("No topics");
		  		tComplete = true;
		  		if(dComplete && iComplete && tComplete 
		  				&& tgComplete && !putComplete) {
		  			console.log("finish 227");
			  		callback(null, { status : 201 });
			  		// Terminate the connection
					connection.end();
					putComplete = true;
			  	}
		  	}
		  	
		  	if(body.tags !== undefined && body.tags.length > 0) {
		  		for(var k = 0; k < body.tags.length; k++)(function(k) {
					connection.query('SELECT T_Id FROM Tags WHERE BINARY title = "' 
							+ encodeURIComponent(body.tags[k]) 
							+ '" LIMIT 1', function (err, tResult) {
						
						console.log(tResult);
						
						 if(err) {
						 	res.fail(err);
						 } else if (tResult.length > 0) {
						 	connection.query('INSERT INTO Tagged VALUES (NULL, ' 
						 			+ tResult[0].T_Id + ', ' + id + ')', 
						 			function(err, tResult) {
						 	    if (err) {
						 	    	res.fail(err);
						 	    } else {
						 	    	if(k == body.tags.length - 1) {
						 	    		console.log("tgComplete");
										tgComplete = true;
										if(dComplete && iComplete && tComplete 
												&& tgComplete && !putComplete) {
											console.log("finish 253");
									  		callback(null, { status : 201 });
									  		// Terminate the connection
											connection.end();
											putComplete = true;
									  	}
						 	    	}
						 	    }
				 	    	});
						 } else {
						 	connection.query('INSERT INTO Tags VALUES (NULL, "' 
						 			+ encodeURIComponent(body.tags[k]) + '")', 
						 			function(err, tResult) {
						 	    if (err) {
						 	    	res.fail(err);
						 	    } else {
						 	    	connection.query('INSERT INTO Tagged VALUES '
						 	    			+ '(NULL, ' + tResult.insertId + ', ' 
						 	    			+ id + ')', function(err, tResult) {
								 	    if (err) {
								 	    	res.fail(err);
								 	    } else {
								 	    	if(k == body.tags.length - 1) {
								 	    		console.log("tgComplete 275");
												tgComplete = true;
												if(dComplete && iComplete 
													&& tComplete && tgComplete
													&& !putComplete) {
													console.log("finish 279");
											  		callback(null, { status : 201 });
											  		// Terminate the connection
													connection.end();
													putComplete = true;
											  	}
								 	    	}
								 	    }
						 	    	});
						 	    }
						 	});
						 }
					});
			  	})(k);
		  	} else {
		  		tgComplete = true;
		  		if(dComplete && iComplete && tComplete 
		  				&& tgComplete && !putComplete) {
			  		callback(null, { status : 201 });
			  		// Terminate the connection
					connection.end();
					putComplete = true;
			  	}
		  	}	
		}
	}
};
