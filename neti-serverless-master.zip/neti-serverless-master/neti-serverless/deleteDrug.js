// This function deletes a drug and its associated info from the database.

console.log('Loading deleteDrug function...');

var mysql = require('mysql');
var _ = require('underscore');

exports.handler = function(req, res, callback) {
	// Pick out the values that we want to work with.
	var id = _.pick(req, 'id').id;
	
	// Establish a connection with our RDS instance.
	var connection = mysql.createConnection({
	  host     : '<HOST>',
	  user     : '<USER>',
	  password : '<PASSWORD>',
	  port     : '3306',
	  database : '<DATABASE>',
	});
	
	connection.connect();
	
	// Check to see if the drug exists in the db. If so, delete it.
	if(Number.isInteger(id)) {
		connection.query('SELECT * FROM Drugs WHERE D_Id = ' + id
				+ ' LIMIT 1', function(err, result) {
			if(err) {
				res.fail(err);
			} else if(result.length > 0) {
				var dChecklist = 0;
				connection.query('DELETE FROM Drugs WHERE D_Id = ' 
						+ parseInt(id), function(err, result) {
					if(err) {
						res.fail(err);
					} else {
						dChecklist++;
						if(dChecklist == 4) {
							callback(null, { status : 200 });
							connection.end();
						}
					}
				});
				connection.query('DELETE FROM Images WHERE D_Id = ' 
						+ parseInt(id), function(err, result) {
					if(err) {
						res.fail(err);
					} else {
						dChecklist++;
						if(dChecklist == 4) {
							callback(null, { status : 200 });
							connection.end();
						}
					}
				});
				connection.query('DELETE FROM Topics WHERE D_Id = ' 
						+ parseInt(id), function(err, result) {
					if(err) {
						res.fail(err);
					} else {
						dChecklist++;
						if(dChecklist == 4) {
							callback(null, { status : 200 });
							connection.end();
						}
					}
				});
				connection.query('DELETE FROM Tagged WHERE D_Id = ' 
						+ parseInt(id), function(err, result) {
					if(err) {
						res.fail(err);
					} else {
						dChecklist++;
						if(dChecklist == 4) {
							callback(null, { status : 200 });
							connection.end();
						}
					}
				});
			} else {
				callback(null, { status : 404 });
				connection.end();
			}
		});	
	} else {
		callback(null, { status : 400 });
		connection.end();
	}
};
