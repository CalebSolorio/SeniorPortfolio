// This function checks if the user's credentials match a set in the database.
// Then, the function creates a JSON web token and returns that.

console.log('Loading login function...');

var mysql = require('mysql');
var _ = require('underscore');
var bcrypt = require('bcrypt');
var cryptojs = require('crypto-js');
var jwt = require('jsonwebtoken');

exports.handler = function(req, context, callback) {
	// Establish a connection with our RDS instance.
	var connection = mysql.createConnection({
	  host     : '<HOST>',
	  user     : '<USER>',
	  password : '<PASSWORD>',
	  port     : '3306',
	  database : '<DATABASE>',
	});
	
	connection.connect();
	
	// Pick out the email and password from the request body.
	var body = _.pick(req, 'email', 'password');
	
	// First authenticate the user. Then, create a token.
	// Insert the token into the DB and send it back to the client.
	authenticate(body).then(function(user) {
		var token = generateToken(user, 'authentication');
		var hash = cryptojs.MD5(token).toString();
		
		connection.query('INSERT INTO Tokens VALUES(NULL, "' + hash + '", ' 
				+ Math.round(new Date().getTime()/1000) + ')', 
				function(err, result) {
		    if(err) {
		    	context.fail(err);
		    } else {
		    	callback(null, { status : 200, location: 'index.html',
		    		netiAuth: token });
		    		
		    	connection.end();
		    }
		});
	}).catch(function() {
		callback(401);
		connection.end();
	});
	
	// Compare request data to the email and encrypted password in the DB.
	function authenticate(body) {
		return new Promise(function(resolve, reject) {
			if (typeof body.email !== 'string' 
					|| typeof body.password !== 'string') {
				return reject();
			}
			
			connection.query('SELECT * FROM Users WHERE email = "' + body.email
					+ '" LIMIT 1', function(err, result) {
				if(err) {
					context.fail(err);
				} else {
					if (result.length <= 0 || !bcrypt.compareSync(body.password, 
							result[0].pHash)) {
						return reject();
					}
					resolve(result);
				}	
			});
		});
	}
	
	// Create a token using the clients encrypted and signed info.
	function generateToken(user, type) {
		if (!_.isString(type)) {
			return undefined;
		}

		try {
			var stringData = JSON.stringify({
				id: user.U_Id,
				type: type
			});
			var encryptedData = cryptojs.AES.encrypt(stringData, 
				'DUMMYKEY').toString();
			var token = jwt.sign({
				token: encryptedData
			}, 'DUMMYKEY');

			return token;
		} catch (e) {
			console.error(e);
			return undefined;
		}
	}
};
