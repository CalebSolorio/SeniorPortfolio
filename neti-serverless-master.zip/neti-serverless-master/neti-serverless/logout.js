// This function deletes the user's respective token from the database.

console.log('Loading logout function...');

var mysql = require('mysql');
var _ = require('underscore');
var cryptojs = require('crypto-js');

exports.handler = function(event, context, callback) {
	// Establish a connection with our RDS instance.
	var connection = mysql.createConnection({
	  host     : '<HOST>',
	  user     : '<USER>',
	  password : '<PASSWORD>',
	  port     : '3306',
	  database : '<DATABASE>',
	});
	
	connection.connect();
	
	// Pick out the authentication token from the request body.
	var token = _.pick(event, 'NetiAuth').NetiAuth;
	
	// Find a hashed token that matches the clients. Delete it.
	if(token !== undefined) {
		connection.query('DELETE FROM Tokens WHERE tkHash = "' 
				+ cryptojs.MD5(token).toString() + '"', 
				function(err, result) {
			if(err)	{
				context.fail(err);
			} else {
				console.log("RESULT:");
				console.log(result);
				if(result.affectedRows > 0) {
					callback(null, { status : 200 });
				} else {
					callback(null, { status : 401, 
						errorMessage: "Not valid token." });
				}
				connection.end();
			}		
		});	
	} else {
		// Get the time from 30 days ago
		var time = Math.round(new Date().getTime()/1000) - (24*60*60) * 30;
		
		// Take care of our old tokens.
		connection.query('DELETE FROM Tokens WHERE timeCreated < "' 
				+ time + '"', function(err, result) {
			if(err)	{
				console.log(err);
			}
			callback(null, { status: 401, errorMessage: "No token given." });
			connection.end();
		});	
	}
};
