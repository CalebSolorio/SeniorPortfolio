var root = {};

// Check if the user is authorized.
function checkCredentials() {
  
  $(".progress-menu").show();
  
  $.ajax({
		    url: 'https://7um0hkzst5.execute-api.us-east-1.amazonaws.com/prod/api/auth/',
		    type: 'POST',
		    crossDomain: true,
		    beforeSend: function(xhr){
		    	xhr.setRequestHeader('NetiAuth', readCookie("NetiAuth"));
		    },
		    success: function(data) {
		    	if(data.status == 200) {
		    	  initialize();
		    	} else {
		    	  logout(false);
		    	}
		    },
		    error: function(xhr, ajaxOptions, thrownError) {
		        $.ajax({
      		    url: 'https://7um0hkzst5.execute-api.us-east-1.amazonaws.com/prod/api/auth/',
      		    type: 'POST',
      		    crossDomain: true,
      		    beforeSend: function(xhr){
      		    	xhr.setRequestHeader('NetiAuth', readCookie("NetiAuth"));
      		    },
      		    success: function(data) {
      		    	if(data.status == 200) {
      		    	  initialize();
      		    	} else {
      		    	  logout(false);
      		    	}
      		    },
      		    error: function(xhr, ajaxOptions, thrownError) {
      		        console.log(thrownError);
      		        logout(false);
      		    }
      		});
		    }
		});
    	
}

// Logs out the user.
function logout(hasToken) {
  if(hasToken) {
		
		$(".progress-menu").show();
		
		var body = {
		  NetiAuth: readCookie("NetiAuth")
		};
		
		$.ajax({
		    url: 'https://7um0hkzst5.execute-api.us-east-1.amazonaws.com/prod/api/login/',
		    type: 'DELETE',
		    crossDomain: true,
		    contentType: 'application/json',
      	dataType: 'json',
      	data: JSON.stringify(body),
		    beforeSend: function(xhr){
		    	xhr.setRequestHeader('NetiAuth', readCookie("NetiAuth"));
		    },
		    success: function(data) {
		      eraseCookie("NetiAuth", function() {
		        $(".progress-menu").hide();
		    	  window.location = "login.html";
		    	});
		    },
		    error: function(xhr, ajaxOptions, thrownError) {
		        $.ajax({
				    url: 'https://7um0hkzst5.execute-api.us-east-1.amazonaws.com/prod/api/login/',
				    type: 'DELETE',
				    crossDomain: true,
				    contentType: 'application/json',
      	    dataType: 'json',
      	    data: JSON.stringify(body),
				    beforeSend: function(xhr){
				    	xhr.setRequestHeader('NetiAuth', readCookie("NetiAuth"));
				    },
				    success: function(data) {
				    	eraseCookie("NetiAuth", function() {
				    	  $(".progress-menu").hide();
    		    	  window.location = "login.html";
    		    	});
				    },
				    error: function(xhr, ajaxOptions, thrownError) {
				        console.log(thrownError);
				        eraseCookie("NetiAuth", function() {
				          $(".progress-menu").hide();
      		    	  window.location = "login.html";
      		    	});
				    }
				});	
		    }
		});	
    	
  } else {
    eraseCookie("NetiAuth", function() {
  	  window.location = "login.html";
  	});
  }
}

// Gets the info from the json database.
function initialize() {
  $.ajax({
		    url: 'https://7um0hkzst5.execute-api.us-east-1.amazonaws.com/prod/api/drugs/',
		    type: 'GET',
		    crossDomain: true,
		    success: function(data) {
		        root = data;

            $(".subjectList").show();
		        $(".subjectList").empty();
            $(".draftList").remove();
            for (var i = 0; i < data.length; i++) {
              displaySubject(i);
              if(i == data.length - 1) {
                $(".progress-menu").hide();
              }
              
            }
		    },
		    error: function(xhr, ajaxOptions, thrownError) {
		        console.log(thrownError);
		        Materialize.toast('Unable to get data. Please refresh and try again.',
		          3000, 'rounded');
		    }
		});
}

// Displays subjects/drafts/
function displaySubject(num) {
  if (!root[num].isDraft) {
    var string = '<a class="list-' + num + ' waves-effect waves-light list-item '
      + 'collection-item" onclick="changeSubject(' + num + ')">';
    $(string).text(root[num].title).appendTo($('.subjectList'));
  }
  else {
    if (!$(".draftList").length) {
      $('<div class="draftList collection z-depth-1"><h6 class="center-align '
        + 'hide-on-small-only">Drafts</h6></div>').insertBefore($(".progress-menu"));
    }
    var string = '<a class="draftList-' + num + ' waves-effect waves-light '
      + 'list-item collection-item" onclick="changeSubject(' + num + ')">';
    $(string).text(root[num].title).appendTo($('.draftList'));
  }
}

// Creates form for user to fill in about a new subject.
function newSubject() {
  $(".list-item").removeClass("active");
  showContent();

  $(".header").load("HTML/header/header-edit.html");

  $("#topic-card .card-details").load("HTML/topics/topics-edit.html");

  $("#gallery-card .gallery").load("HTML/gallery/gallery-edit.html");

  $(".action-btn").load("HTML/btn.html", function() {
    $(".submit-btn").attr("onclick", "subjectSubmit(-1, 0)");
    $(".save-btn").attr("onclick", "subjectSubmit(-1, 1)");
    $(".delete-btn").remove();
  });

  // If the user drops an image on the profile picture, upload/change the photo.
  $('.propic-upload').on('drop', function(e) {
    e.preventDefault();
    e.stopPropagation();
    var dt = e.dataTransfer || (e.originalEvent && e.originalEvent.dataTransfer);
    var files = e.target.files || (dt && dt.files);
    if (files) {
      upload(e.originalEvent.dataTransfer.files[0], 0);
    }
  });
  
  // If the user drops an image on the gallery, upload/add the photo.
  $('.gallery').on('drop', function(e) {
    e.preventDefault();
    e.stopPropagation();
    var dt = e.dataTransfer || (e.originalEvent && e.originalEvent.dataTransfer);
    var files = e.target.files || (dt && dt.files);
    if (files) {
      upload(e.originalEvent.dataTransfer.files[0], 1);
    }
  });
}

// Adds a tag to the webpage.
function addTag() {
  var $i = 1;

  while (document.getElementById('tag' + $i) != null) {
    $i++;
  }
  if (document.getElementById("tag_enter").value.length > 0) {
    $('<div id="tag' + $i + '" class="chip tag"><i class="material-icons" '
      + 'onclick="removeTag(' + $i + ')">clear</i>' 
      + document.getElementById("tag_enter").value 
      + '</div>').appendTo($(".tags"));
    document.getElementById("tag_enter").value = "";
    $('#tag0').remove();
  }
}

// Removes a tag from the webpage.
function removeTag($i) {
  $('#tag' + $i).remove();

  // If no tags exist, add the "none" chip.
  if (document.getElementsByClassName("tag").length == 0) {
    $('<div id="tag0" class="chip"/>').text('none').appendTo($('.tags'));
  }
}

// Removes an image from the webpage.
function removeImg($i) {
  if ($('#img' + $i + ' img').attr('src') == $('#profile-pic').attr('src')) {
    $('#img' + $i).remove();
    $('#profile-pic').attr('src', 
      "https://s3.amazonaws.com/netiapp/Client/HIDTA_Logo_14.png");
  }
  else {
    $('#img' + $i).remove();
  }

  // If no images exist, add the default logo.
  if (document.getElementsByClassName("gallery-pic").length == 0) {
    $('<div id="img0" class="col l3 m4 s6"><a class="gallery-delete btn-floating"'
    + ' onclick="removeImg(0)"><i class="material-icons">clear</i></a>'
    + '<img src="https://s3.amazonaws.com/netiapp/Client/HIDTA_Logo_14.png" '
    + 'class="gallery-pic responsive-img">').appendTo($('.gallery'))
    .insertBefore($('.gallery-upload'));
  }
}

// Uploads a photo to imgur and returns the associated address.
function upload(file, i) {
  ImageTools.resize(file, {
        width: 414, // maximum width
    }, function(blob, resized) {
        // resized will be true if it managed to resize it, otherwise false (and will return the original file as 'blob')
        console.log(resized);
        
        file = blob;

        // Checks if the file is an image
        if (!file || !file.type.match(/image.*/)) {
          return;
        }
      
        // Builds a FormData object.
        var fd = new FormData();
        // Append the file
        fd.append("image", file);
        // Create the XHR (Cross-Domain XHR FTW)
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "https://api.imgur.com/3/image.json");
        // Adds the image to the webpage using the link of the newly upladed image.
        xhr.onload = function() { 
          if (i == 0) {
            $("#profile-pic").attr('src', JSON.parse(xhr.responseText).data.link);
            while (document.getElementById('img' + i) != null) {
              i++;
            }
            $('<div id="img' + i + '" class="col l3 m4 s6"><a class="gallery-delete '
              + 'btn-floating" onclick="removeImg(' + i + ')"><i class="material-icons">'
              + 'clear</i></a><img src="' + JSON.parse(xhr.responseText).data.link 
              + '" class="gallery-pic responsive-img">').prependTo($('.gallery'));
          }
          else {
            while (document.getElementById('img' + i) != null) {
              i++;
            }
            $('<div id="img' + i + '" class="col l3 m4 s6"><a class="btn-floating" '
              + 'style="float:right" onclick="removeImg(' + i + ')">'
              + '<i class="material-icons">clear</i></a><img src="' 
              + JSON.parse(xhr.responseText).data.link 
              + '" class="gallery-pic responsive-img" style="padding:0px 20px">')
              .appendTo($('.gallery')).insertBefore($('.gallery-upload'));
          }
        }
        
        // Authorized by a custon ID. Currently using my personal account.
        xhr.setRequestHeader('Authorization', 'Client-ID 5a7fe72af44b980');
      
        // Now, we send the FormData.
        xhr.send(fd);
    });
}

// Reverts back to the intro card.
function clearCards() {
  $("#header-card").hide();
  $("#gallery-card").hide();
  $("#topic-card").hide();
  $(".action-btn").hide();
  $("#intro-card").show();

  $(".list-item").removeClass("active");
}

// Shows the content cards and clears their content.
function showContent() {
  $("#header-card").show();
  $("#gallery-card").show();
  $("#topic-card").show();
  $("#intro-card").hide();
  $(".action-btn").show();

  $(".propic").empty();
  $(".header-info").empty();
  $("#topic-card .card-details").empty();
  $(".gallery").empty();
  $(".action-btn").empty();
}

// Changes which subject's information is displayed.
function changeSubject(num) {
  $(".list-item").removeClass("active");
  var ref = root[num];
  
  if (!root[num].isDraft) {
    $('.list-' + num).addClass("active");
  } else {
    $('.draftList-' + num).addClass("active");
  }
  showContent();
  
  // Populate the header card.
  $('.header').load("HTML/header/header-view.html", function() {
    $(".propic").attr("class", "propic col m4 s12");
    $("#profile-pic").attr("src", ref.propic);
    $("#subject-name").text(ref.title);

    if (ref.toxicity == "3")
      $('#subject-toxicity').text("Toxicity: High");
    else if (ref.toxicity == "2")
      $('#subject-toxicity').text("Toxicity: Medium");
    else if (ref.toxicity == "1")
      $('#subject-toxicity').text("Toxicity: Low");
    if (ref.tags !== undefined && ref.tags.length > 0) {
      for (var j = 0; j < ref.tags.length; j++) {
        $('<div class="chip">').text(ref.tags[j]).appendTo($(".tags"));
      }  
    } else {
      $('<div class="chip">').text("None").appendTo($(".tags"));
    }
  });
  
  // Populate the middle card with topics.
  if(ref.topics !== undefined && ref.topics.length > 0) {
    for (var j = 0; j < ref.topics.length; j++) {
      $('<h5>').text(ref.topics[j].title).appendTo($("#topic-card .card-details"));
      $('<p>').text(ref.topics[j].body).appendTo($("#topic-card .card-details"));
    }  
  }
  
  // Populate the gallery.
  if(ref.images !== undefined && ref.images.length > 0) {
    for (var j = 0; j < ref.images.length; j++) {
      $('<div class="propic col l3 m4 s6"><img src="' + ref.images[j] 
        + '" class="gallery-pic responsive-img" style="padding-top:10px; '
        + 'padding-bottom: 10px">').appendTo($('.gallery'));
    }  
  }

  $('<a class="waves-effect waves-light btn" onclick="editSubject(' + num 
    + ')">Edit</a>').appendTo($(".action-btn"));
};

// Determines what radio button is checked when editing an existing subject.
function toxicity(toxicity) {
  if (toxicity == "3")
    document.getElementById("tchoice3").checked = true;
  else if (toxicity == "2")
    document.getElementById("tchoice2").checked = true;
  else if (toxicity == "1")
    document.getElementById("tchoice1").checked = true;
}

// Creates the form for a user to edit a pre-existing subject.
function editSubject(num) {
  var ref = root[num];
  var topicCount, imgCount;

  showContent();

  topicCount = 0;

  // Populate the header card.
  $('.header').load("HTML/header/header-edit.html", function() { 
    $("#profile-pic").attr("src", ref.propic);
    $("#edit-name").attr("value", ref.title);
    
    if(ref.toxicity === undefined) {
      ref.toxicity = 0;
    }
    
    toxicity(ref.toxicity);
    if(ref.tags !== undefined) {
      for (var j = 0; j < ref.tags.length; j++) {
        var k = 1;
        while (document.getElementById('tag' + k) != null) {
          k++;
        }
        $('<div id="tag' + k + '" class="chip tag"><i class="material-icons" '
          + 'onclick="removeTag(' + k + ')">clear</i>' + ref.tags[j] + '</div>')
          .appendTo($(".tags"));
      }  
    }

    if (document.getElementsByClassName("tag").length == 0) {
      $('<div id="tag0" class="chip"/>').text('none').appendTo($('.tags'));
    }
  });
  
  // Populate the topics card.
  if(ref.topics !== undefined) {
    for (var j = 0; j < ref.topics.length; j++) {
      $('<h5 class="topic' + topicCount + ' col s12" style="padding:0px">')
        .text("Topic:").appendTo($("#topic-card .card-details"));
      $('<input class="topic' + topicCount + ' edit-title" type="text" value="' 
        + ref.topics[j].title + '" placeholder="Enter Here">')
        .appendTo($("#topic-card .card-details"));
      $('<p class="topic' + topicCount + '">').text("Description:")
        .appendTo($("#topic-card .card-details"));
      $('<textarea class="topic' + topicCount + ' edit-description '
       + 'materialize-textarea" style="height:10rem" placeholder="Enter Here">')
       .text(ref.topics[j].body).appendTo($("#topic-card .card-details"));
      $('<a href="#" class="topic' + topicCount + '  edit" onclick="deleteTopic(' 
        + topicCount + ')">').text("Delete Topic")
        .appendTo($("#topic-card .card-details"));
      $('<a href="#" class="topic' + topicCount + ' edit" style="float:right" '
        + 'onclick="addTopic(' + topicCount + ')">').text("Add Topic").
        appendTo($("#topic-card .card-details"));
      topicCount++;
    }  
  }

  // Now populate the gallery, assigning unique ID's to each image.
  if(ref.images !== undefined) {
    imgCount = 0;
    for (var j = 0; j < ref.images.length; j++) { 
      while (document.getElementById('img' + imgCount) != null) {
        imgCount++;
      }
      $('<div id="img' + imgCount + '" class="col l3 m3 s6"><a class="btn-floating" style="float:right" onclick="removeImg(' + imgCount + ')"><i class="material-icons">clear</i></a><img src="' + ref.images[j] + '" class="gallery-pic responsive-img" style="padding:0px 20px">').prependTo($('.gallery'));
    }  
  }

  $('<h5 class="gallery-upload center-align col s12">Drag a photo here to add it to the gallery or</h5><div class="file-field input-field"><div class="btn btn-small col l4 m6 s12 push-l4 push-m3"><span>Click Here!</span><input type="file" onchange="upload(this.files[0],1)">').appendTo($('.gallery'));
  
  // Buttons for publishing, saving, or deleting a subject.
  $(".action-btn").load("HTML/btn.html", function() {
    $(".submit-btn").attr("onclick", "subjectSubmit(" + num + ", 0)");
    $(".save-btn").attr("onclick", "subjectSubmit(" + num + ", 1)");
    $(".delete-btn").attr("onclick", "deleteSubject(" + num + ")");
  });
  
   // When the user drags an image to the profile pic, upload and swap the pictures.
  $('.propic-upload').on('drop', function(e) {
    e.preventDefault();
    e.stopPropagation();
    var dt = e.dataTransfer || (e.originalEvent && e.originalEvent.dataTransfer);
    var files = e.target.files || (dt && dt.files);
    if (files) {
      upload(e.originalEvent.dataTransfer.files[0], 0);
    }
  });
  
  // When the user drags an image to the gallery, upload and add the photo.
  $('.gallery').on('drop', function(e) {
    e.preventDefault();
    e.stopPropagation();
    var dt = e.dataTransfer || (e.originalEvent && e.originalEvent.dataTransfer);
    var files = e.target.files || (dt && dt.files);
    if (files) {
      upload(e.originalEvent.dataTransfer.files[0], 1);
    }
  });
}

// Changes the values of a pre-existing subject in the database.
function subjectSubmit(num, where) {
  var name = document.getElementById("edit-name").value;
  var titles = document.getElementsByClassName("edit-title");
  var titleArray = new Array();
  var descriptions = document.getElementsByClassName("edit-description");
  var descriptionArray = new Array();
  var tagsArray = new Array();
  var galleryArray = new Array();
  var pass = true;

  // First, check to make sure the user has filled in all details.
  if (name == null || name == "") {
    alert("Whoops! Remember to fill every area.");
    return 0;
  }
  
  $(".progress-main").show();

  $(".gallery-pic").each(function() {
    galleryArray.push($(this).attr('src'));
  });

  Array.prototype.forEach.call(titles, function(title) {
    if (title.value == null || title.value == "")
      pass = false;
    titleArray.push(title.value);
  });

  Array.prototype.forEach.call(descriptions, function(description) {
    if (description.value == null || description.value == "" 
        || $('input[name=tox-choice]:checked').val() == null 
        || $('input[name=tox-choice]:checked').val() == "") {
      pass = false;
    }
    descriptionArray.push(description.value);
  });

  $(".tag").each(function() {
    tagsArray.push($(this).after($('i')).text());
  });

  $(".tags").remove();

  var ref = {};
  
  // If everything has been filled in, populate the ref object.
  if (pass) {
    if(num >= 0) {
      ref.id = root[num].SubjectId;  
    }
    ref.title = name;
    ref.toxicity = $('input[name=tox-choice]:checked').val();
    ref.propic = $('#profile-pic').attr('src');
    ref.tags = new Array();
    ref.topics = new Array();
    ref.images = new Array();


    for (var i = 0; i < titleArray.length; i++) {
      ref.topics.push({
        title: titleArray[i],
        body: descriptionArray[i]
      });
    }

    for (var i = 0; i < tagsArray.length; i++) {
      ref.tags.push(tagsArray[i]);
    }

    for (var i = 0; i < galleryArray.length; i++) {
      ref.images.push(galleryArray[i]);
    }

    $('<i class="large material-icons">add</i>').appendTo($('.add-btn'));
    $('<i class="material-icons">clear</i>').appendTo($('.gallery .btn-floating'));
    
    // Add or update the object to either the published subjects or drafts.
    if (where == 0) {
      ref.isDraft = false;
      if (num >= 0 &&  !root[num].isDraft) {
        root[num] = ref;
      }
      else {
        if (num >= 0 && !root[num].isDraft) {
          root[num] = ref;
          root[num].isDraft = false;
          $(".draftList .draftList-" + num).remove();
          if (!($(".draftList").length > 2)) {
            $('.draftList').remove();
          }
        } else {
          num = root.length;
          root.push(ref);
        }
      }
    }
    else if (where == 1) {
      ref.isDraft = true;
      if (num >= 0 &&  root[num].isDraft == 1) {
        root[num] = ref;
      }
      else {
        if (num >= 0 && root[num].isDraft == 0) {
          root[num] = ref;
          root[num].isDraft = true;
          $(".subjectList .list-" + num).remove();
        } else {
          num = root.length;
          root.push(ref);
        }
      }
    }
		
		$.ajax({
		    url: 'https://7um0hkzst5.execute-api.us-east-1.amazonaws.com/prod/api/drugs/',
		    type: 'POST',
		    crossDomain: true,
		    contentType: 'application/json',
		    data: JSON.stringify(root[num]),
		    dataType: 'json',
		    beforeSend: function(xhr){
		      //console.log(JSON.stringify(root[num]));
		    	xhr.setRequestHeader('NetiAuth', readCookie("NetiAuth"));
		    },
		    success: function(data) {
		      if(data.status == 201) {
		        $(".progress-main").hide();
            $.when(initialize()).done(changeSubject(num));
		      }
		    },
		    error: function(xhr, ajaxOptions, thrownError) {
		        $.ajax({
      		    url: 'https://7um0hkzst5.execute-api.us-east-1.amazonaws.com/prod/api/drugs/',
      		    type: 'POST',
      		    crossDomain: true,
      		    contentType: 'application/json',
      		    data: JSON.stringify(root[num]),
      		    dataType: 'json',
      		    beforeSend: function(xhr){
      		    	xhr.setRequestHeader('NetiAuth', readCookie("NetiAuth"));
      		    },
      		    success: function(data) {
      		      $(".progress-main").hide();
      		      if(data.status == 201) {
                  $.when(initialize()).done(changeSubject(num));
      		      }
      		    },
      		    error: function(xhr, ajaxOptions, thrownError) {
      		        console.log(thrownError);
      		        Materialize.toast('Unable to submit drug. Please try again.',
		                3000, 'rounded');
      		        $(".progress-main").hide();
      		    }
      		});
		    }
		});
		
    $("#mobile-nav").html('<i class="mdi-navigation-menu"></i>');
  }
  else {
    alert("Whoops! Remember to fill every area.");
  }
}

// Remove a subject from the database.
function deleteSubject(num) {
  var ans = confirm("Are you sure you want to delete all information on " 
    + root[num].title + "?");
  
  // If true, remove the subject from both the local object and the database.
  if (ans == true) {
    
    $(".progress-main").show();
    
    if (!root[num].isDraft) {
      $(".subjectList .list-" + num).remove();
    }
    else if (root[num].isDraft) {
      $(".draftList .draftlist-" + num).remove();
      if ($(".draftList").length < 2) {
        $('.draftList').remove();
      }
    }
    
    var subject = {
      id: root[num].SubjectId,
    };
      
    $.ajax({
	    url: 'https://7um0hkzst5.execute-api.us-east-1.amazonaws.com/prod/api/drugs/',
	    type: 'DELETE',
	    crossDomain: true,
	    contentType: 'application/json',
	    data: JSON.stringify(subject),
	    dataType: 'json',
	    beforeSend: function(xhr){
	    	xhr.setRequestHeader('NetiAuth', readCookie("NetiAuth"));
	    },
	    success: function(data) {
	        $(".progress-main").hide();
	        root.splice(num, 1);
	        clearCards();
	        initialize();
	    },
	    error: function(xhr, ajaxOptions, thrownError) {
	        $.ajax({
      	    url: 'https://7um0hkzst5.execute-api.us-east-1.amazonaws.com/prod/api/drugs/',
      	    type: 'DELETE',
      	    crossDomain: true,
      	    contentType: 'application/json',
      	    data: JSON.stringify(subject),
      	    dataType: 'json',
      	    beforeSend: function(xhr){
      	    	xhr.setRequestHeader('NetiAuth', readCookie("NetiAuth"));
      	    },
      	    success: function(data) {
      	        $(".progress-main").hide();
      	        root.splice(num, 1);
      	        clearCards();
                initialize();
      	    },
      	    error: function(xhr, ajaxOptions, thrownError) {
      	        console.log(thrownError);
      	        Materialize.toast('Unable to delete drug. Please try again.',
		                3000, 'rounded');
      	        $(".progress-main").hide();
      	        root.splice(num, 1);
      	        clearCards();
                initialize();
      	    }
      		});
	    }
		});
  }
}

// Removes a topic from a subject.
function deleteTopic(topicCount) {
  var position = document.body.scrollTop;
  
  $(".topic" + topicCount).remove();
  setTimeout(function() {window.scrollTo(0, position - 300);},500);
}

// Adds a topic to a subject.
function addTopic(topicCount) {
  var position = document.body.scrollTop;
  
  var count = 0;
  
  while ($(".topic" + count).length > 0) {
    count++;
  }

  $('<h5 class="topic' + count + '">').text("Topic:").insertAfter($(".topic" 
    + topicCount).last());
  $('<input class="topic' + count + ' edit-title" type="text" '
    + 'placeholder="Enter Here">').insertAfter($(".topic" + count).last());
  $('<p class="topic' + count + '">').text("Description:")
    .insertAfter($(".topic" + count).last());
  $('<textarea class="topic' + count + ' edit-description materialize-textarea" '
    + 'placeholder="Enter Here" style="height:10rem">')
    .insertAfter($(".topic" + count).last());
  $('<a href="#" class="topic' + count + ' edit" onclick="deleteTopic(' + count 
    + ')">').text("Delete Topic").insertAfter($(".topic" + count).last());
  $('<a href="#" class="topic' + count + ' edit" onclick="addTopic(' + count 
    + ')" style="float:right">').text("Add Topic").insertAfter($(".topic" 
    + count).last());
    
  setTimeout(function() {window.scrollTo(0, position + 300);},500);
}

// Creates a cookie for the user.
function createCookie(name,value,days) {
    if (days) {
        var date = new Date();
        date.setTime(date.getTime()+(days*24*60*60*1000));
        var expires = "; expires="+date.toGMTString();
    }
    else var expires = "";
    document.cookie = name+"="+value+expires+"; path=/";
}

// Returns a specific cookie's value.
function readCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for(var i=0;i < ca.length;i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1,c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
    }
    return null;
}

// Removes a specified cookie.
function eraseCookie(name, callback) {
    createCookie(name,"",-1);
    callback();
}

$(document).ready(function() {
  checkCredentials();
  clearCards();
  
  $(".subjectList").hide();
  $(".progress-main").hide();
  
  // For Materialize plugin.
  $('.materialboxed').materialbox();
  $('input#input_text, textarea#textarea1').characterCounter();
  
  // Initializes the search bar.
  $('.search').keyup(function() { 
    var valThis = $(this).val().toLowerCase();
    if (valThis == "") {
      $('.subjectList > a').show();
      $('.draftList > a').show();
    }
    else {
      $(".search").val($(this).val());
      $('.subjectList > a').each(function() {
        $(this).hide();
        for(var i = 0; i < $(".subjectList").length; i++) {
            if($(this).hasClass("list-" + i)) {
              var tags = root[i].tags;
              for(var j = 0; j < tags.length; j++) {
                if(tags[j].toLowerCase().indexOf(valThis) >= 0) {
                  $(this).show();
                }
              }
            }  
        }
        var text = $(this).text().toLowerCase();
        if(text.indexOf(valThis) >= 0) {
          $(this).show();  
        }
      });
      $('.draftList > a').each(function() {
        $(this).hide();
        for(var i = 0; i < $(".draftList").length; i++) {
            if($(this).hasClass("draftList-" + i)) {
              var draftTags = root[i].tags;
              for(var j = 0; j < draftTags.length; j++) {
                if(draftTags[j].toLowerCase().indexOf(valThis) >= 0) {
                  $(this).show();
                }
              }
            }  
        }
        var text = $(this).text().toLowerCase();
        if(text.indexOf(valThis) >= 0) {
          $(this).show();  
        }
      });
    };
  });
  
  // Initializes the side navigation bar (for mobile devices).
  $('.button-collapse').sideNav({
    closeOnClick: true
  });
  
  // Stops the browser from leaving the page if the user drag and drops a photo.
  window.ondragover = function(e) {
    e.preventDefault();
  }
});