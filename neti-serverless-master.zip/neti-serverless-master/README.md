# neti-serverless
This is (most of) the back end and associated web tool created for a mobile app sponsored by the National Emerging Threats Initiative(NETI). The backend utilizes Node.js, MySQL, Amazon Web Services, and a serverless architecture while the web tool employs HTML, CSS, and JavaScript.

The web tool allows for NETI admins to securely log in using JSON web tokens and quickly create, read, update, or delete a specific drug's information from the database that the mobile app draws information from. In addition, admins can choose to mark the drug profile as a draft, meaning that the drugs information will not show on the mobile app.

The app, titled "NETI", should be available on iOS very shortly as well as on Android not long after.
