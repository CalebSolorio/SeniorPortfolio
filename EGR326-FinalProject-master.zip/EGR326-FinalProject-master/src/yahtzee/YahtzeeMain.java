package yahtzee;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import static javafx.application.Application.launch;

/**
 * This class handles the initiation of a game.
 * @author Caleb Solorio
 * @version 1.0 (Apr 6 2017)
 */

public class YahtzeeMain extends Application {
    /**
     * Starts a new program.
     * @param args The arguments needed to launch the program.
     */
    public static void main(String[] args) { launch(args);   }

    @Override
    public void start(Stage stage) throws Exception {
        stage.setTitle("YAHTZEE");
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/yahtzee/gui/GameView.fxml"));
        VBox mainGUI = loader.load();

        Scene scene = new Scene(mainGUI);
        stage.setScene(scene);
        stage.show();
    }


}
