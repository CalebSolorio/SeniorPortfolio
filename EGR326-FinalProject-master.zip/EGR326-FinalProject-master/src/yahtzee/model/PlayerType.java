package yahtzee.model;

/**
 * This enum specifies the types of players that can exist.
 * @author Caleb Solorio
 * @version 1.0 (Apr 6 2017)
 */

public enum PlayerType {
    ONE,
    TWO
}
