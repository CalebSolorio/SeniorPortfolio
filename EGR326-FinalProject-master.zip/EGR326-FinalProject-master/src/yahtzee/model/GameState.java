package yahtzee.model;

/**
 * This enum specifies the various states a game can be in.
 * @author Caleb Solorio
 * @version 1.0 (Apr 6 2017)
 */

public enum GameState {
    NOTSTARTED,
    PLAYERONETURNONE,
    PLAYERONETURNTWO,
    PLAYERONETURNTHREE,
    PLAYERTWOTURNONE,
    PLAYERTWOTURNTWO,
    PLAYERTWOTURNTHREE,
    PLAYERONEWIN,
    PLAYERTWOWIN,
    TIE
}
