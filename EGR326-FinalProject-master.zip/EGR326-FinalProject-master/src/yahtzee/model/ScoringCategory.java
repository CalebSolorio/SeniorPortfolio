package yahtzee.model;

/**
 * This enum specifies the various categories a score can be applied to.
 * @author Caleb Solorio
 * @version 1.0 (Apr 6 2017)
 */

public enum ScoringCategory {
    ACES,
    TWOS,
    THREES,
    FOURS,
    FIVES,
    SIXES,
    BONUS,
    THREEOFAKIND,
    FOUROFAKIND,
    FULLHOUSE,
    SMALLSTRAIGHT,
    LARGESTRAIGHT,
    YAHTZEE,
    CHANCE
}
