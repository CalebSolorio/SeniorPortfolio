package yahtzee.model;

import yahtzee.util.ScoreCalculator;

import java.util.HashMap;
import java.util.Map;

/**
 * This class specifies the behaviors and associated data of a player.
 * @author Caleb Solorio
 * @version 1.0 (Apr 6 2017)
 */

public class Player implements Cloneable {
    private static HashMap<PlayerType, Player> instances = new HashMap();
    private HashMap<ScoringCategory, Integer> points;
    private boolean bonusAdded;
    private int wins;
    private int losses;

    // Initialize a Player object.
    private Player(PlayerType playerType) {
        this.points = new HashMap();
//        populatePoints();
        points.put(ScoringCategory.BONUS, 0);
        bonusAdded = false;
        this.wins = 0;
        this.losses = 0;
    }

    /**
     * Gets an instance of a specified Player object or creates one if it doesn't exist.
     * @param playerType The type of player to retrieve.
     * @return the specified Player object.
     * @throws IllegalArgumentException if invalid PlayerType is provided.
     */
    public static Player getInstance(PlayerType playerType) throws IllegalArgumentException {
        if(playerType != null) {
            if(instances.containsKey(playerType)) {
                return instances.get(playerType);
            }

            Player player = new Player(playerType);
            instances.put(playerType, player);

            return player;
        }

        throw new IllegalArgumentException("Player type must not be null.");
    }

    /**
     * Adds a win to this player object.
     */
    public void addWin() {
        wins++;
    }

    /**
     * Adds a loss to this player object.
     */
    public void addLoss() {
        losses++;
    }

    /**
     * Retrieve the number of wins associated with this player.
     * @return the value of wins.
     */
    public int getWins(){ return wins; }

    /**
     * Retrieve the number of losses associated with this player.
     * @return the value of losses.
     */
    public int getLosses(){ return losses; }

    /**
     * Adds a score.
     * @param category The scoring category.
     * @param dice The set of dice to evaluate point count from.
     * @throws IllegalArgumentException if an invalid ScoringCategory is provided.
     */
    public void addScore(ScoringCategory category, Dice dice) throws IllegalArgumentException {
        if(points.get(category) != null) {
            throw new IllegalArgumentException("Score already submitted.");
        } else if(category == ScoringCategory.BONUS) {
            throw new IllegalArgumentException("Bonus automatically assigned by program.");
        }

        points.put(category, ScoreCalculator.getScore(category, dice));
        updateBonus();
    }

    /**
     * Gets the points associated with this player.
     * @return the points Map.
     */
    public Map<ScoringCategory, Integer> getPoints() {
        return points;
    }

    /**
     * Get a copy of this player.
     * @return a clone of this object.
     */
    public Player clone() {
        Player player = null;

        try {
            player = (Player) super.clone();
            player.points = new HashMap(points);
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }

        return player;
    }

    /**
     * Resets this player's state.
     */
    public void reset() {
        points.clear();
        points.put(ScoringCategory.BONUS, 0);
        bonusAdded = false;
        wins = 0;
        losses = 0;
//        populatePoints();
    }

    // Update the bonus if the first six scores have been applied..
    private void updateBonus() {
        if(!bonusAdded && points.containsKey(ScoringCategory.ACES) && points.containsKey(ScoringCategory.TWOS) &&
                points.containsKey(ScoringCategory.THREES) && points.containsKey(ScoringCategory.FOURS) &&
                points.containsKey(ScoringCategory.FIVES) && points.containsKey(ScoringCategory.SIXES)) {
            points.put(ScoringCategory.BONUS, points.get(ScoringCategory.ACES) + points.get(ScoringCategory.TWOS) +
                    points.get(ScoringCategory.THREES) + points.get(ScoringCategory.FOURS) +
                    points.get(ScoringCategory.FIVES) + points.get(ScoringCategory.SIXES));
            bonusAdded = true;
        }
    }

//    private void populatePoints(){
//        points.put(ScoringCategory.ACES, -1);
//        points.put(ScoringCategory.TWOS, -1);
//        points.put(ScoringCategory.THREES, -1);
//        points.put(ScoringCategory.FOURS, -1);
//        points.put(ScoringCategory.FIVES, -1);
//        points.put(ScoringCategory.SIXES, -1);
//        points.put(ScoringCategory.THREEOFAKIND, -1);
//        points.put(ScoringCategory.FOUROFAKIND, -1);
//        points.put(ScoringCategory.FULLHOUSE, -1);
//        points.put(ScoringCategory.SMALLSTRAIGHT, -1);
//        points.put(ScoringCategory.LARGESTRAIGHT, -1);
//        points.put(ScoringCategory.YAHTZEE, -1);
//        points.put(ScoringCategory.CHANCE, -1);
//
//    }
}
