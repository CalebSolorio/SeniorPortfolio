package yahtzee.model;

import yahtzee.util.ScoreCalculator;

import java.util.*;

/**
 * This class handles game logic.
 * @author Caleb Solorio, Adam Rainey
 * @version 1.0 (Apr 25 2017)
 */

public class Game extends Observable {
    private static Game game = new Game();
    private Player p1;
    private Player p2;
    private Dice dice;
    private GameState state;

    // Creates an instance of ttt.yahtzee.modelee.Game.
    private Game() throws IllegalArgumentException {
        p1 = Player.getInstance(PlayerType.ONE);
        p2 = Player.getInstance(PlayerType.TWO);
        dice = new Dice();
        state = GameState.NOTSTARTED;
    }

    /**
     * Gets the instance of ttt.yahtzee.Gamedel.Game.
     * @return the Game object.
     */
    public static Game getInstance() {
        return game;
    }

    /**
     * Sets the game to a starting state.
     * @throws IllegalStateException if a game is already in progress.
     */
    public void startGame() throws IllegalStateException {
        if(gameInSession()) {
            throw new IllegalStateException("Game already in progress.");
        }

        dice.reset();
        state = GameState.PLAYERONETURNONE;

        setChanged();
        notifyObservers(state);
    }

    /**
     * Resets the state of the game.
     */
    public void reset() {

        p1.reset();
        setChanged();
        notifyObservers(p1);

        p2.reset();
        setChanged();
        notifyObservers(p2);

        state = GameState.NOTSTARTED;
        setChanged();
        notifyObservers(state);
    }

    /**
     * Gets a specific player.
     * @param playerType The type of player to return.
     * @return a clone of the specified Player object.
     */
    public Player getPlayer(PlayerType playerType) {
        return playerType == PlayerType.ONE ? p1.clone() : p2.clone();
    }

    /**
     * Gets the current state of the dice.
     * @return a cloned Dice object.
     */
    public Dice getDice() {
        return dice.clone();
    }

    /**
     * Rolls the dice.
     * @throws IllegalStateException if no game is in session.
     */
    public void rollDice() throws IllegalStateException {
        if(!gameInSession()) {
            throw new IllegalStateException("No game in session");
        }

        dice.roll();

        setChanged();
        notifyObservers(dice.clone());
    }

    /**
     * Choose to keep some unconfirmed die that you've rolled.
     * @param dice The index of the die to keep.
     * @throws IllegalStateException if no game is in progress.
     * @throws IllegalArgumentException if invalid die indexes are provided.
     */
    public void confirm(int[] dice) throws IllegalStateException, IllegalArgumentException {
        if (!gameInSession()) {
            throw new IllegalStateException("No game in progress.");
        }

        for(int die: dice) {
            this.dice.confirm(die);
        }
        nextState();

    }

    /**
     * Add a new score to the scoreboard, then checks for a winner.
     * @param category The scoring category to add to.
     * @throws IllegalStateException if no game is in progress.
     * @throws IllegalArgumentException if invalid category is provided.
     */
    public void addScore(ScoringCategory category) throws IllegalStateException, IllegalArgumentException {

        if (!gameInSession() || (state != GameState.PLAYERONETURNTHREE && state != GameState.PLAYERTWOTURNTHREE)) {
            throw new IllegalStateException(gameInSession() ? "Rolls still remain" : "No game in progress.");
        }

        if(state == GameState.PLAYERONETURNTHREE) {
            p1.addScore(category, dice.clone());
            state = GameState.PLAYERTWOTURNONE;
            dice.reset();

        } else {
            p2.addScore(category, dice.clone());
            state = GameState.PLAYERONETURNONE;
            dice.reset();
            // CHECK GAME END
            if (p2.getPoints().keySet().size() >= ScoringCategory.values().length){
                state = GameState.NOTSTARTED;
            }
        }

        if(!gameInSession()) {
            int p1Total = getTotalScore(PlayerType.ONE);
            int p2Total = getTotalScore(PlayerType.TWO);

            if(p1Total != p2Total) {
                if(p1Total > p2Total) {
                    state = GameState.PLAYERONEWIN;
                    p1.addWin();
                    p2.addLoss();
                } else {
                    state = GameState.PLAYERTWOWIN;
                    p2.addWin();
                    p1.addLoss();
                }
                setChanged();
                notifyObservers(p1);
                setChanged();
                notifyObservers(p2);
            } else {
                state = GameState.TIE;
            }
        }

        setChanged();
        notifyObservers(state);
    }

    /**
     * Gets the points currently assigned to a player in each category.
     * @param playerType The type of player to calculate scores for.
     * @return a Map object with the points scored in each category.
     * @throws IllegalArgumentException if invalid PlayerType is provided.
     */
    public Map getPoints(PlayerType playerType) throws IllegalArgumentException {
        if(playerType == null) {
            throw new IllegalArgumentException("Player type may not be null");
        }

        return playerType == PlayerType.ONE ? p1.getPoints() : p2.getPoints();
    }

    // Determines if a game is currently in session.
    private boolean gameInSession() {
        return state == GameState.PLAYERONETURNONE || state == GameState.PLAYERONETURNTWO ||
                state == GameState.PLAYERONETURNTHREE || state == GameState.PLAYERTWOTURNONE ||
                state == GameState.PLAYERTWOTURNTWO || state == GameState.PLAYERTWOTURNTHREE;
    }

    // Gets the total score of a specified player.
    public int getTotalScore(PlayerType playerType) {
        int total = 0;
        Iterator points = playerType == PlayerType.ONE ?
                p1.getPoints().values().iterator() :
                p2.getPoints().values().iterator();

        while (points.hasNext()) {
            total += (int) points.next();
        }
        return total;
    }

    private void nextState() throws IllegalStateException {
        switch (state) {
            case NOTSTARTED:
                state = GameState.PLAYERONETURNONE;
                break;
            case PLAYERONETURNONE:
                state = GameState.PLAYERONETURNTWO;
                break;
            case PLAYERONETURNTWO:
                state = GameState.PLAYERONETURNTHREE;
                break;
            case PLAYERTWOTURNONE:
                state = GameState.PLAYERTWOTURNTWO;
                break;
            case PLAYERTWOTURNTWO:
                state = GameState.PLAYERTWOTURNTHREE;
                break;
            default:
                throw new IllegalStateException("Next state not definite.");
        }

        setChanged();
        notifyObservers(state);
    }
}
