package yahtzee.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * This class specifies the behaviors of a set of 5 dice.
 * @author Caleb Solorio
 * @version 1.0 (Apr 6 2017)
 */

public class Dice implements Cloneable {
    private List<Integer> unconfirmed;
    private List<Integer> confirmed;
    private int rollsLeft;

    /**
     * Initializes a set of dice.
     */
    public Dice() {
        unconfirmed = new ArrayList<>(Collections.nCopies(5, 0));
        confirmed = new ArrayList<>();
        rollsLeft = 3;
    }

    /**
     * Rolls the dice.
     * @throws IllegalStateException if no rolls remain.
     */
    public void roll() throws IllegalStateException {
        if(rollsLeft < 1) {
            throw new IllegalStateException("Maximum rolls reached.");
        }

        for(int i = 0; i < unconfirmed.size(); i++) {
            unconfirmed.set(i, (int)(Math.random() * 6) + 1);
        }

        if(rollsLeft-- < 1){
            confirmed.addAll(unconfirmed);
        }
    }

    /**
     * Get the dice that have not yet been confirmed.
     * @return a List of unconfirmed dice.
     */
    public List<Integer> getUnconfirmed() {
        return unconfirmed;
    }

    /**
     * Get the dice that have been confirmed.
     * @return a List of confirmed dice.
     */
    public List<Integer> getConfirmed() {
        return confirmed;
    }

    /**
     * Confirm a particular die.
     * @param die The index of the die to confirm.
     */
    public void confirm(int die) {
        if(die < 0 || die >= unconfirmed.size()) {
            throw new IllegalArgumentException("Dice not found.");
        }

        int value = unconfirmed.remove(die);
        confirmed.add(value);
    }

    /**
     * Get a copy of the dice.
     * @return a clone of this object.
     */
    public Dice clone() {
        Dice copy = null;
        try {
            copy = (Dice) super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace(); // Probably won't happen.
        }
        copy.unconfirmed = new ArrayList<>(unconfirmed);
        copy.confirmed = new ArrayList<>(confirmed);

        return copy;
    }

    /**
     * Resets the dice.
     */
    public void reset() {
        unconfirmed = new ArrayList<>(Collections.nCopies(5, 0));
        confirmed.clear();
        rollsLeft = 3;
    }
}
