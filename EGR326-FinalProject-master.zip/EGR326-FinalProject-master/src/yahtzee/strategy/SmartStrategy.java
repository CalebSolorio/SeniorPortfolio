package yahtzee.strategy;

import yahtzee.model.*;

import java.util.*;

/**
 * This class implements the behavior of a bot with an intelligence level of SMART
 * @author Adam Rainey, Caleb Solorio
 * @version 1.0 (Apr 25 2017)
 */

public class SmartStrategy extends StrategySuper implements Strategy  {
    protected void confirmDice(Dice d) {
        Set<ScoringCategory> l = new HashSet<>();
        ArrayList<Integer> cur = new ArrayList<>();
        ArrayList<Integer> nums = new ArrayList<>();
        for (Map.Entry<ScoringCategory, Integer> e : getPlayer(GameState.PLAYERTWOTURNONE).getPoints().entrySet())
            if (e.getValue() != null) l.add(e.getKey());

        int count = 0;
        List<Integer> dice = d.getUnconfirmed();
        dice.addAll(d.getConfirmed());

        for (int i = 1; i <= 6; i++)
            if (dice.contains(i))
                count++;
        int index = 0;
        if (count > 3 && (l.contains(ScoringCategory.LARGESTRAIGHT) || l.contains(ScoringCategory.SMALLSTRAIGHT))) {
            for (Integer i : d.getUnconfirmed()){
                if (!nums.contains(i)) {
                    if ((i == 1 && !nums.contains(6)) || (i == 6 && !nums.contains(6))) {
                        nums.add(i);
                        cur.add(index);
                    } else if (i != 1 && i != 6){
                        nums.add(i);
                        cur.add(index);
                    }
                }
                index++;
            }
        } else {
            List<Integer> prev = d.getConfirmed();
            List<Integer> unconfirmed = d.getUnconfirmed();

            for (int i = 0; i < unconfirmed.size() - 1; i++) {
                if (prev.contains(unconfirmed.get(i))){
                    cur.add(i);
                    break;
                }

                for (int j = i + 1; j < unconfirmed.size(); j++)
                    if (unconfirmed.get(i).equals(unconfirmed.get(j))) {
                        if (!cur.contains(i)) cur.add(i);
                        if (!cur.contains(j)) cur.add(j);
                    }
            }
        }


        int[] die = new int[cur.size()];
        int j = 0;
        for (int i = cur.size() -1; i >= 0; i--)
            die[j++] = i;

        Game.getInstance().confirm(die);
    }
}
