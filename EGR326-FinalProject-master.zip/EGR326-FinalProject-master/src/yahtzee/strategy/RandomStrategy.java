package yahtzee.strategy;

import yahtzee.model.Dice;
import yahtzee.model.Game;
import yahtzee.model.GameState;
import yahtzee.model.ScoringCategory;

import java.util.ArrayList;
import java.util.Set;

/**
 * This class implements the behavior of a bot with an intelligence level of RANDOM.
 * @author Adam Rainey, Caleb Solorio
 * @version 1.0 (Apr 25 2017)
 */

public class RandomStrategy extends StrategySuper implements Strategy {
    // Randomly selects dice to confirm.
    protected void confirmDice(Dice d){
        ArrayList<Integer> cur = new ArrayList<>();
        for (int i = 0; i < d.getUnconfirmed().size(); i++)
            if (Math.random() * 3 > 2) cur.add(i); // Confirm roughly 1/3



        int[] die = new int[cur.size()];
        int j = 0;
        for (int i = cur.size() -1; i >= 0; i--)
            die[j++] = i;

        Game.getInstance().confirm(die);
    }
}
