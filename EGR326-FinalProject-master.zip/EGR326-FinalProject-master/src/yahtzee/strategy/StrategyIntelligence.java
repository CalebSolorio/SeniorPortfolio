package yahtzee.strategy;

/**
 * This enum denotes the possible intelligence levels of a bot.
 * @author Caleb Solorio
 * @version 1.0 (Apr 6 2017)
 */

public enum StrategyIntelligence {
    HUMAN,
    RANDOM,
    OFAKINDER,
    UPPERSECTIONER,
    FOURANDUP,
    SMART
}
