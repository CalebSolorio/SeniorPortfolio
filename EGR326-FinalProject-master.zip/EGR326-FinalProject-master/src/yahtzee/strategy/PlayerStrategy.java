package yahtzee.strategy;

import yahtzee.model.Game;
import yahtzee.model.GameState;
import yahtzee.model.PlayerType;

import java.util.HashMap;
import java.util.Observable;
import java.util.Observer;

/**
 * This class handles AI behavior.
 * @author Caleb Solorio
 * @version 1.0 (Apr 25 2017)
 */

public class PlayerStrategy implements Observer {
    private static PlayerStrategy playerStrategy = new PlayerStrategy();
    private static HashMap<PlayerType, StrategySuper> instances = new HashMap();

    // Instantiate a new instance of PlayerStrategy.
    private PlayerStrategy() {
        Game.getInstance().addObserver(this);
    }

    /**
     * Sets a bot for a given player.
     * @param playerType The desired player to set up a bot for.
     * @param intelligence The desired intelligence of the bot.
     * @throws IllegalArgumentException if invalid PlayerType is provided.
     */
    public static void setStrategy(PlayerType playerType, StrategyIntelligence intelligence) throws IllegalArgumentException {
        if(playerType != null && intelligence != null && intelligence != StrategyIntelligence.HUMAN) {
            Strategy strategy = StrategyFactory.createStrategy(intelligence);
            if(strategy != null) {
                instances.put(playerType, StrategyFactory.createStrategy(intelligence));
            }
        } else if(instances.containsKey(playerType)) {
            instances.remove(playerType);
        } else if(intelligence != StrategyIntelligence.HUMAN) {
            throw new IllegalArgumentException("PlayerStrategy has not yet been set for this player.");
        }
    }

    public static boolean isAI(GameState gs){
        if (gs == GameState.PLAYERONETURNONE || gs == GameState.PLAYERONETURNTWO || gs == GameState.PLAYERONETURNTHREE)
            return instances.containsKey(PlayerType.ONE);
        else if (gs == GameState.PLAYERTWOTURNONE || gs == GameState.PLAYERTWOTURNTWO || gs == GameState.PLAYERTWOTURNTHREE)
            return instances.containsKey(PlayerType.TWO);
        return false;
    }

    public static void turn(Object arg) {
        if (arg instanceof GameState) {
            GameState state = (GameState) arg;
            if (instances.containsKey(PlayerType.ONE) && (state == GameState.PLAYERONETURNONE || state == GameState.PLAYERONETURNTWO ||
                    state == GameState.PLAYERONETURNTHREE)) {
                instances.get(PlayerType.ONE).takeTurn(Game.getInstance().getDice(), state);
            } else if (instances.containsKey(PlayerType.TWO) && (state == GameState.PLAYERTWOTURNONE || state == GameState.PLAYERTWOTURNTWO ||
                    state == GameState.PLAYERTWOTURNTHREE)) {
                if (state != GameState.PLAYERTWOTURNTHREE)
                    Game.getInstance().rollDice();
                instances.get(PlayerType.TWO).takeTurn(Game.getInstance().getDice(), state);
            }
        }
    }

    /**
     * Instructs bot to take a turn depending on the given state.
     * @param o The component this object is observing.
     * @param arg The object the Observable component has provided.
     */
    @Override
    public void update(Observable o, Object arg) {
        /*if(arg instanceof GameState) {
            GameState state = (GameState) arg;
            if(instances.containsKey(PlayerType.ONE) && (state == GameState.PLAYERONETURNONE || state == GameState.PLAYERONETURNTWO ||
                    state == GameState.PLAYERONETURNTHREE)) {
                instances.get(PlayerType.ONE).takeTurn(Game.getInstance().getDice(), state);
            } else if(instances.containsKey(PlayerType.ONE)  && (state == GameState.PLAYERTWOTURNONE || state == GameState.PLAYERTWOTURNTWO ||
                    state == GameState.PLAYERTWOTURNTHREE)) {
                instances.get(PlayerType.TWO).takeTurn(Game.getInstance().getDice(), state);
            }
        }*/
    }
}
