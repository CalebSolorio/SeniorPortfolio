package yahtzee.strategy;

import yahtzee.model.Dice;
import yahtzee.model.Game;
import yahtzee.model.GameState;
import yahtzee.model.ScoringCategory;

import java.util.*;

/**
 * This class implements the behavior of a bot with an intelligence level of FOURANDUP.
 * @author Adam Rainey, Caleb Solorio
 * @version 1.0 (Apr 25 2017)
 */

public class FourUpStrategy extends StrategySuper implements Strategy {
    // Confirms alike dice
    protected void confirmDice(Dice d){
        List<Integer> unconfirmed = d.getUnconfirmed();
        ArrayList<Integer> cur = new ArrayList<>();
        for (int i = unconfirmed.size() - 1; i >= 0; i--)
            if (unconfirmed.get(i) > 3) cur.add(i);

        int[] die = new int[cur.size()];
        int j = 0;
        for (int i : cur)
            die[j++] = i;

        Game.getInstance().confirm(die);
    }
}
