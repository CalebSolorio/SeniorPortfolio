package yahtzee.strategy;

import yahtzee.model.Dice;
import yahtzee.model.Game;
import yahtzee.model.ScoringCategory;
import yahtzee.util.ScoreCalculator;

import java.util.*;

/**
 * This class implements the behavior of a bot with an intelligence level of RANDOM.
 * @author Adam
 * @version 1.0 (Apr 6 2017)
 */

public class UpperSectionStrategy extends OfAKinderStrategy {

    /**
     * Confirms alike dice
     */
    @Override
    protected void setCategory(Dice d, Set<ScoringCategory> l){
        ScoringCategory[] cats = {ScoringCategory.ACES, ScoringCategory.TWOS, ScoringCategory.THREES, ScoringCategory.FOURS, ScoringCategory.FIVES, ScoringCategory.SIXES};
        Set<ScoringCategory> upperCat = new HashSet<>(Arrays.asList(cats));
        upperCat.removeAll(l);
        if (upperCat.size() > 0) {
            Map.Entry<ScoringCategory, Integer> chosen = null;
            for (Map.Entry<ScoringCategory, Integer> e : ScoreCalculator.getScores(d).entrySet())
                if (chosen == null || e.getValue() > chosen.getValue() && upperCat.contains(e.getKey())) chosen = e;
            Game.getInstance().addScore(chosen.getKey());
        } else super.setCategory(d, l);
    }
}
