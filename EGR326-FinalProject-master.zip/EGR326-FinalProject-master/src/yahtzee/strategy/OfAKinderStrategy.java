package yahtzee.strategy;

import yahtzee.model.Dice;
import yahtzee.model.Game;
import yahtzee.model.GameState;
import yahtzee.model.ScoringCategory;

import java.util.*;

/**
 * This class implements the behavior of a bot with an intelligence level of OFAKINDER.
 * @author Adam Rainey, Caleb Solorio
 * @version 1.0 (Apr 25 2017)
 */

public class OfAKinderStrategy extends StrategySuper implements Strategy {

    // Confirms alike dice
    protected void confirmDice(Dice d){
        ArrayList<Integer> cur = new ArrayList<>();
        List<Integer> prev = d.getConfirmed();
        List<Integer> unconfirmed = d.getUnconfirmed();

        for (int i = 0; i < unconfirmed.size() - 1; i++) {
            if (prev.contains(unconfirmed.get(i))){
                cur.add(i);
                break;
            }

            for (int j = i + 1; j < unconfirmed.size(); j++)
                if (unconfirmed.get(i).equals(unconfirmed.get(j))) {
                    if (!cur.contains(i)) cur.add(i);
                    if (!cur.contains(j)) cur.add(j);
                }
        }

        int[] die = new int[cur.size()];
        int j = 0;
        for (int i = cur.size() -1; i >= 0; i--)
            die[j++] = i;

        Game.getInstance().confirm(die);
    }
}
