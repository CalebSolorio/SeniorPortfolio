package yahtzee.strategy;

import yahtzee.model.Dice;
import yahtzee.model.GameState;

/**
 * Created by csolo on 4/17/2017.
 */
public interface Strategy {
    void takeTurn(Dice d, GameState state);
}
