package yahtzee.strategy;

/**
 * This class assists with bot creation.
 * @author Caleb Solorio, Adam Rainey
 * @version 1.0 (Apr 25 2017)
 */

public class StrategyFactory {
    /**
     * Creates a new bot.
     * @param strategy The desired yahtzee.strategy of the bot.
     * @return the desired type of bot.
     */
    public static StrategySuper createStrategy(StrategyIntelligence strategy) {
        switch (strategy) {
            case RANDOM:
                return new RandomStrategy();
            case OFAKINDER:
                return new OfAKinderStrategy();
            case UPPERSECTIONER:
                return new UpperSectionStrategy();
            case FOURANDUP:
                return new FourUpStrategy();
            case SMART:
                return new SmartStrategy();
            default:
                return null;
        }
    }
}
