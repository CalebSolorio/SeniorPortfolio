package yahtzee.strategy;

import yahtzee.model.*;
import yahtzee.util.ScoreCalculator;

import java.util.*;

/**
 * This interface specifies the core bot behavior.
 * @author Caleb Solorio, Adam Rainey
 * @version 1.0 (Apr 6 2017)
 */

public abstract class StrategySuper implements Strategy {
    /**
     * Takes a turn an makes the appropriate moves.
     * @throws IllegalStateException If no game is in progress.
     */
    public void takeTurn(Dice d, GameState state) throws IllegalStateException {
        if (state == GameState.PLAYERTWOTURNTHREE) {
            Set<ScoringCategory> l = new HashSet<>();
            for (Map.Entry<ScoringCategory, Integer> e : getPlayer(state).getPoints().entrySet())
                if (e.getValue() != null) l.add(e.getKey());
            setCategory(d, l);
        } else {
            confirmDice(d);
        }
    }

    protected abstract void confirmDice(Dice d);

    protected Player getPlayer(GameState state) {
        if (state == GameState.PLAYERONETURNONE || state == GameState.PLAYERONETURNTWO || state == GameState.PLAYERONETURNTHREE)
            return Game.getInstance().getPlayer(PlayerType.ONE);
        else if (state == GameState.PLAYERTWOTURNONE || state == GameState.PLAYERTWOTURNTWO || state == GameState.PLAYERTWOTURNTHREE)
            return Game.getInstance().getPlayer(PlayerType.TWO);
        throw(new IllegalStateException("No active player"));
    }

    protected void setCategory(Dice d, Set<ScoringCategory> l){
        Map.Entry<ScoringCategory, Integer> chosen = null;
        for (Map.Entry<ScoringCategory, Integer> e : ScoreCalculator.getScores(d).entrySet())
            if ((chosen == null || (e.getValue() != null && e.getValue() > chosen.getValue())) && !l.contains(e.getKey())) chosen = e;
        Game.getInstance().addScore(chosen.getKey());
    }
}

