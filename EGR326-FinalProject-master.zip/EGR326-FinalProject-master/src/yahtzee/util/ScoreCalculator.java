package yahtzee.util;

import yahtzee.model.Dice;
import yahtzee.model.ScoringCategory;

import java.util.*;

/**
 * This class assists with score calculations.
 * @author Caleb Solorio
 * @version 1.0 (Apr 6 2017)
 */

public class ScoreCalculator {
    /**
     * Gets the score of a specified category, given a set of dice.
     * @param category The scoring category to evaluate.
     * @param dice The dice to evaluate a score from.
     * @return an integer denoting the highest score possible.
     */
    public static int getScore(ScoringCategory category, Dice dice) {
        return calculateScore(category, getValues(dice));
    }

    /**
     * Gets all possible scores, given a set of dice.
     * @param dice The dice to evaluate scores from.
     * @return a Map of possible scores.
     */
    public static Map<ScoringCategory, Integer> getScores(Dice dice) {
        return calculateScores(getValues(dice));
    }

    // Organizes the value of the dice into a map and returns it.
    private static Map getValues(Dice dice) {
        List<Integer> list = dice.getConfirmed();
        list.addAll(dice.getUnconfirmed());

        TreeMap<Integer, Integer> map = new TreeMap();

        for(int i = 6; i >= 1; i--) {
            map.put(i, 0);
        }

        for(int number: list) {
            if (number > 0)
                map.put(number, map.get(number) + 1);
        }

        return map;
    }

    // Calculates the store in a particular category, given a map of values.
    private static int calculateScore(ScoringCategory category, Map values) {
        switch (category) {
            case ACES:
                return ofAKind(values, 1, 0, 5);
            case TWOS:
                return ofAKind(values, 2, 0, 5);
            case THREES:
                return ofAKind(values, 3, 0, 5);
            case FOURS:
                return ofAKind(values, 4, 0, 5);
            case FIVES:
                return ofAKind(values, 5, 0, 5);
            case SIXES:
                return ofAKind(values, 6, 0, 5);
            case THREEOFAKIND:
                return ofAKind(values, 0, 3, 3);
            case FOUROFAKIND:
                return ofAKind(values, 0, 4, 4);
            case FULLHOUSE:
                return ofAKind(values, 0, 3, 3) > 0 &&
                        ofAKind(values, 0, 2, 2) > 0 ? 25 : 0;
            case YAHTZEE:
                return ofAKind(values, 0, 5, 5) > 0 ? 50 : 0;
            case SMALLSTRAIGHT:
                return consecutive(values, 4) ? 30 : 0;
            case LARGESTRAIGHT:
                return consecutive(values, 5) ? 40 : 0;
            case CHANCE:
                return chance(values);
            default:
                throw new IllegalArgumentException("Invalid scoring category provided");
        }
    }

    // Calculate the possible scores in all scoring categories, given a Map of values.
    private static Map<ScoringCategory, Integer> calculateScores(Map values) {
        TreeMap<ScoringCategory, Integer> scores = new TreeMap<>();

        scores.put(ScoringCategory.ACES, calculateScore(ScoringCategory.ACES, values));
        scores.put(ScoringCategory.TWOS, calculateScore(ScoringCategory.TWOS, values));
        scores.put(ScoringCategory.THREES, calculateScore(ScoringCategory.THREES, values));
        scores.put(ScoringCategory.FOURS, calculateScore(ScoringCategory.FOURS, values));
        scores.put(ScoringCategory.FIVES, calculateScore(ScoringCategory.FIVES, values));
        scores.put(ScoringCategory.SIXES, calculateScore(ScoringCategory.SIXES, values));
        scores.put(ScoringCategory.THREEOFAKIND, calculateScore(ScoringCategory.THREEOFAKIND, values));
        scores.put(ScoringCategory.FOUROFAKIND, calculateScore(ScoringCategory.FOUROFAKIND, values));
        scores.put(ScoringCategory.FULLHOUSE, calculateScore(ScoringCategory.FULLHOUSE, values));
        scores.put(ScoringCategory.SMALLSTRAIGHT, calculateScore(ScoringCategory.SMALLSTRAIGHT, values));
        scores.put(ScoringCategory.LARGESTRAIGHT, calculateScore(ScoringCategory.LARGESTRAIGHT, values));
        scores.put(ScoringCategory.YAHTZEE, calculateScore(ScoringCategory.YAHTZEE, values));
        scores.put(ScoringCategory.CHANCE, calculateScore(ScoringCategory.CHANCE, values));

        return scores;
    }

    // Find the highest value of a "of a kind" combination of cards.
    private static int ofAKind(Map<Integer, Integer> values, int diceNum, int minCount, int maxCount) {
        if(diceNum > 0 && diceNum <= 6) {
            int value = values.get(diceNum);
            if(value >= minCount && value <= maxCount) {
                return diceNum * value;
            }
        } else {
            Iterator keys = values.keySet().iterator();
            while (keys.hasNext()) {
                int key = (int) keys.next();
                int value = values.get(key);
                if(value >= minCount && value <= maxCount) {
                    return key * value;
                }
            }
        }

        return 0;
    }

    // Find the highest value of a "consecutive" combination of cards.
    private static boolean consecutive(Map values, int length) {
        Iterator keys = values.keySet().iterator();
        int count = 0;
        while (keys.hasNext()) {
            int key = (int) keys.next();
            int value = (int) values.get(key);
            if(value > 0) {
                count ++;
                if(count == length) {
                    return true;
                }
            } else {
                count = 0;
            }
        }

        return false;
    }

    // Find the value of a "chance" combination of cards.
    private static int chance(Map values) {
        Iterator keys = values.keySet().iterator();
        int count = 0;

        while (keys.hasNext()) {
            int key = (int) keys.next();
            count += key * (int) values.get(key);
        }

        return count;
    }
}
