package yahtzee.gui;

import javafx.fxml.FXML;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import yahtzee.model.Game;
import yahtzee.model.GameState;

import java.net.URL;
import java.util.*;

/**
 * Created by Austin
 */
public class PaintedBoardController extends GameController {

    @FXML
    protected Canvas canvas;
    private GraphicsContext gc;

    private Map<Integer, Boolean> selectedSquares;
    private int listSize = 5;

    /**
     * Initializes the view.
     *
     * @param location  The location of the controller.
     * @param resources The resources required to initialize the controller.
     */
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        game = Game.getInstance();
        game.addObserver(this);

        selectedSquares = new HashMap<>();
        populateMap();

        canvas.setWidth(450);
        canvas.setHeight(115);
        gc = canvas.getGraphicsContext2D();
        gc.setGlobalAlpha(.5);
        gc.setFill(Color.AQUA);
        gc.setStroke(Color.GRAY);
        gc.setLineWidth(4);
        drawDefaultCanvas();

        canvas.setOnMouseClicked(e -> { //if roll dice
            if (e.getY() > 90 && e.getY() < 115) {
                gc.clearRect(0, 0, 450, 115);
                drawDefaultCanvas();
                rollDice();
            } else if (e.getY() < 90 && e.getY() > 0 && e.getX() > 0 && e.getX() < 90 && listSize > 0) { //if die0
                if (!selectedSquares.get(0)) {
                    gc.fillRect(0, 0, 90, 90);
                    selectedSquares.put(0, true);
                } else {
                    gc.clearRect(0, 0, 90, 90);
                    drawDefaultCanvas();
                    selectedSquares.put(0, false);
                    drawApproptriate(game.getDice().getUnconfirmed().get(0), 0);
                }
            } else if (e.getY() < 90 && e.getY() > 0 && e.getX() > 90 && e.getX() < 180 && listSize > 1) { //if die1
                if (!selectedSquares.get(1)) {
                    gc.fillRect(90, 0, 90, 90);
                    selectedSquares.put(1, true);
                } else {
                    gc.clearRect(90, 0, 90, 90);
                    drawDefaultCanvas();
                    selectedSquares.put(1, false);
                    drawApproptriate(game.getDice().getUnconfirmed().get(1), 1);
                }
            } else if (e.getY() < 90 && e.getY() > 0 && e.getX() > 180 && e.getX() < 270 && listSize > 2) { //if die2
                if (!selectedSquares.get(2)) {
                    gc.fillRect(180, 0, 90, 90);
                    selectedSquares.put(2, true);
                } else {
                    gc.clearRect(180, 0, 90, 90);
                    drawDefaultCanvas();
                    selectedSquares.put(2,false);
                    drawApproptriate(game.getDice().getUnconfirmed().get(2), 2);
                }
            } else if (e.getY() < 90 && e.getY() > 0 && e.getX() > 270 && e.getX() < 360 && listSize > 3) { //if die3
                if (!selectedSquares.get(3)) {
                    gc.fillRect(270, 0, 90, 90);
                    selectedSquares.put(3,true);
                } else {
                    gc.clearRect(270, 0, 90, 90);
                    drawDefaultCanvas();
                    selectedSquares.put(3,false);
                    drawApproptriate(game.getDice().getUnconfirmed().get(3), 3);
                }
            } else if (e.getY() < 90 && e.getY() > 0 && e.getX() > 360 && e.getX() < 450 && listSize > 4) { //if die4
                if (!selectedSquares.get(4)) {
                    gc.fillRect(360, 0, 90, 90);
                    selectedSquares.put(4,true);
                } else {
                    gc.clearRect(360, 0, 90, 90);
                    drawDefaultCanvas();
                    selectedSquares.put(4, false);
                    drawApproptriate(game.getDice().getUnconfirmed().get(4), 4);
                }
            }
        });

    }

    @Override
    public void update(Observable o, Object arg) {
        if(arg == GameState.NOTSTARTED){
            eraseCanvas();
        }
        List diceNums = game.getDice().getUnconfirmed();
        listSize = diceNums.size();
        for (int i = 0; i < diceNums.size(); i++) {
            switch ((int) diceNums.get(i)) {
                case 1:
                    drawOne(i);
                    break;
                case 2:
                    drawTwo(i);
                    break;
                case 3:
                    drawThree(i);
                    break;
                case 4:
                    drawFour(i);
                    break;
                case 5:
                    drawFive(i);
                    break;
                case 6:
                    drawSix(i);
                    break;
                default:
                    break;
            }
        }
    }

    private void rollDice() {

        List diceNums = game.getDice().getUnconfirmed();
        //check for confirmed dice
        List<Integer> indexsToConfirm = new ArrayList<>();
        for(Integer b : selectedSquares.keySet()){
            boolean added = false;
            for(int j = 0; j < diceNums.size(); j++) {
                if (selectedSquares.get(b) && !added) {
                    diceNums.remove(j);
                    indexsToConfirm.add(j);
                    added = true;
                }
            }
        }
        int[] confirmed = new int[indexsToConfirm.size()];
        for(int k = 0; k < indexsToConfirm.size(); k++){
            confirmed[k] = indexsToConfirm.get(k);

        }

        //remove confirmed dice from map
        for(Iterator<Map.Entry<Integer, Boolean>> it = selectedSquares.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry<Integer, Boolean> entry = it.next();
            if(entry.getValue()) {
                it.remove();
            }
        }

        //roll dice
        try{
            game.confirm(confirmed);
            resetCanvas();
            game.rollDice(); //roll for logical aspects

        }
        catch (IllegalStateException e){
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle(e.getMessage());
            alert.setHeaderText("Please select a scoring category and confirm dice to end your turn");
            alert.showAndWait();
        }

        diceNums = game.getDice().getUnconfirmed();
        for(int i = 0; i <diceNums.size(); i++){
            selectedSquares.put(i, false);
        }
    }

    private void drawDice(int diceNum) {
        gc.strokeLine((90 * diceNum), 0, 90 + (90 * diceNum), 0);
        gc.strokeLine(90 * diceNum, 0, 90 * diceNum, 90);
        gc.strokeLine(90 + (90 * diceNum), 0, 90 + (90 * diceNum), 90);
        gc.strokeLine((90 * diceNum), 90, 90 + (90 * diceNum), 90);
    }

    private void drawOne(int index) {
        gc.strokeOval(40 + (90 * index), 40, 10, 10);
    }

    private void drawTwo(int index) {
        gc.strokeOval(10 + (90 * index), 70, 10, 10);
        gc.strokeOval(70 + (90 * index), 10, 10, 10);
    }

    private void drawThree(int index) {
        gc.strokeOval(10 + (90 * index), 70, 10, 10);
        gc.strokeOval(40 + (90 * index), 40, 10, 10);
        gc.strokeOval(70 + (90 * index), 10, 10, 10);
    }

    private void drawFour(int index) {
        gc.strokeOval(10 + (90 * index), 70, 10, 10);
        gc.strokeOval(70 + (90 * index), 10, 10, 10);
        gc.strokeOval(70 + (90 * index), 70, 10, 10);
        gc.strokeOval(10 + (90 * index), 10, 10, 10);
    }

    private void drawFive(int index) {
        gc.strokeOval(10 + (90 * index), 70, 10, 10);
        gc.strokeOval(70 + (90 * index), 10, 10, 10);
        gc.strokeOval(70 + (90 * index), 70, 10, 10);
        gc.strokeOval(10 + (90 * index), 10, 10, 10);
        gc.strokeOval(40 + (90 * index), 40, 10, 10);
    }

    private void drawSix(int index) {
        gc.strokeOval(10 + (90 * index), 70, 10, 10);
        gc.strokeOval(70 + (90 * index), 10, 10, 10);
        gc.strokeOval(70 + (90 * index), 70, 10, 10);
        gc.strokeOval(10 + (90 * index), 10, 10, 10);
        gc.strokeOval(10 + (90 * index), 40, 10, 10);
        gc.strokeOval(70 + (90 * index), 40, 10, 10);
    }

    private void drawFilledDie(int index){
        gc.fillRect(90*index, 0, 90, 90);
    }

    private void drawDefaultCanvas() {
        drawDice(0);
        drawDice(1);
        drawDice(2);
        drawDice(3);
        drawDice(4);
        gc.strokeRect(0, 90, 450, 25);
        gc.strokeText("Roll Dice", 201, 105);
    }

    private void resetCanvas() {
        gc.clearRect(0, 0, 450, 125);
        drawDefaultCanvas();

        List<Integer> confirmed = game.getDice().getConfirmed();
        List<Integer> unconfirmed = game.getDice().getUnconfirmed();

        for(int i = 0; i < confirmed.size(); i++){
            int index = i + unconfirmed.size();
            drawApproptriate(confirmed.get(i),index);
            drawFilledDie(index);
        }
    }

    private void eraseCanvas(){
        gc.clearRect(0, 0, 450, 125);
        drawDefaultCanvas();
    }

    private void drawApproptriate(int x, int index) {
        switch (x) {
            case 1:
                drawOne(index);
                break;
            case 2:
                drawTwo(index);
                break;
            case 3:
                drawThree(index);
                break;
            case 4:
                drawFour(index);
                break;
            case 5:
                drawFive(index);
                break;
            case 6:
                drawSix(index);
                break;
        }
    }
    
    private void populateMap(){
        selectedSquares.put(0, false);
        selectedSquares.put(1, false);
        selectedSquares.put(2, false);
        selectedSquares.put(3, false);
        selectedSquares.put(4, false);
    }
}
