package yahtzee.gui;

import javafx.fxml.FXML;
import javafx.scene.control.TableView;
import yahtzee.model.Game;
import yahtzee.model.GameState;

import java.net.URL;
import java.util.Observable;
import java.util.ResourceBundle;

/**
 * Created by Austin
 */
public class ScoreTable extends GameController {

    @FXML
    protected TableView scoreTable;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        game = Game.getInstance();
        game.addObserver(this);
    }

    @Override
    public void update(Observable o, Object arg) {
        if (arg == GameState.PLAYERONETURNONE || arg == GameState.PLAYERTWOTURNONE) {

        }
    }


}



