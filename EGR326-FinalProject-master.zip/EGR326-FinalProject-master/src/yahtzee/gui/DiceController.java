package yahtzee.gui;

import javafx.fxml.FXML;
import javafx.scene.image.*;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import yahtzee.model.Game;
import yahtzee.model.GameState;
import yahtzee.model.Player;
import yahtzee.strategy.PlayerStrategy;

import java.net.URL;
import java.util.*;
import java.util.List;

/**
 * Created by Austin
 */
public class DiceController extends GameController{

    @FXML protected Button die0;
    @FXML protected Image img0;

    @FXML protected Button die1;
    @FXML protected Image img1;

    @FXML protected Button die2;
    @FXML protected Image img2;

    @FXML protected Button die3;
    @FXML protected Image img3;

    @FXML protected Button die4;
    @FXML protected Image img4;

    @FXML protected Button roll;

    private Map<Button, Boolean> diceMap = new HashMap<>();
    private Map<Button, Integer> diceValues = new HashMap<>();

    private final String UNSELECTED_STYLE =  "-fx-font-size: 20; -fx-border-color:black; -fx-border-width: 1; " +
            "-fx-border-style: solid; -fx-padding: 0";
    private final String SELECTED_STYLE = "-fx-background-color: aqua; -fx-font-size: 20; -fx-border-color:black; " +
            "-fx-border-width: 1; -fx-border-style: solid; -fx-padding: 0";

    /**
     * +
     * Initializes the view.
     * @param location The location of the controller.
     * @param resources The resources required to initialize the controller.
     */
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        game = Game.getInstance();
        game.addObserver(this);
        addDiceToMaps();
        //set onAction events
        for(Button dice : diceMap.keySet()){
            dice.setDisable(true);
            dice.setOnAction(e-> diceOnClick(dice));
        }
        roll.setOnAction(e -> rollDice());
        roll.setDisable(true);
    }

    /**
     * Updates the view.
     * @param o The Observable component
     * @param arg The object the Observable component has provided.
     */
    @Override
    public void update(Observable o, Object arg) {
        if(arg != null && arg.getClass() == GameState.class) { //if the gameState has changed
            if(arg == GameState.NOTSTARTED){ //if GameState is changed to NOTSTARTED
                resetButtons();
                roll.setDisable(true);
            }
            else if(arg == GameState.PLAYERONETURNONE){ //if GameState is changed to PLAYERONETURN
                resetButtons();
                roll.setDisable(false);
                initialRoll();
            }
            if(arg == GameState.PLAYERTWOTURNONE && !PlayerStrategy.isAI((GameState) arg)){ //if GameState is changed to PLAYERTWOTURN
                resetButtons();
                roll.setDisable(false);
                initialRoll();
            } else if ((arg == GameState.PLAYERTWOTURNONE || arg == GameState.PLAYERTWOTURNTWO || arg == GameState.PLAYERTWOTURNTHREE) && PlayerStrategy.isAI((GameState) arg)) PlayerStrategy.turn(arg);
            else if (arg == (GameState) GameState.PLAYERTWOWIN || arg == (GameState) GameState.PLAYERONEWIN ){
                roll.setDisable(true);
            }
        }
    }

    private void diceOnClick(Button b){
        try {
            diceMap.put(b, !diceMap.get(b));
            for(Button button : diceMap.keySet()){
                if(b == button){
                    if(!button.getStyle().equals(SELECTED_STYLE)) {
                        button.setStyle(SELECTED_STYLE);
                        ImageView imageView = new ImageView(new Image("/yahtzee/resources/cDie" +
                                diceValues.get(button).toString() + ".jpg"));
                        imageView.setFitHeight(85);
                        imageView.setPreserveRatio(true);
                        button.setGraphic(imageView);
                    }
                    else{
                        button.setStyle(UNSELECTED_STYLE);
                        ImageView imageView = new ImageView(new Image("/yahtzee/resources/uDie" +
                                diceValues.get(button).toString() + ".jpg"));
                        imageView.setFitHeight(85);
                        imageView.setPreserveRatio(true);
                        button.setGraphic(imageView);
                    }
                }
            }
        } catch(NullPointerException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("You have already confirmed this die.");
            alert.showAndWait();
        }
    }

    //handles rolling the dice
    private void rollDice(){
        List diceNums = game.getDice().getUnconfirmed();
        //check for confirmed dice
        List<Integer> indexsToConfirm = new ArrayList<>();
        for(Button b : diceMap.keySet()){
            boolean added = false;
            for(int j = 0; j < diceNums.size(); j++) {
                if (diceMap.get(b) && (diceNums.get(j).equals(diceValues.get(b)) && !added)) {
                    diceNums.remove(j);
                    indexsToConfirm.add(j);
                    added = true;
                }
            }
        }
        int[] confirmed = new int[indexsToConfirm.size()];
        for(int k = 0; k < indexsToConfirm.size(); k++){
            confirmed[k] = indexsToConfirm.get(k);
        }

        //remove confirmed dice from map
        for(Iterator<Map.Entry<Button, Boolean>> it = diceMap.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry<Button, Boolean> entry = it.next();
            if(entry.getValue()) {
                it.remove();
            }
        }

        //roll dice
        try{
            game.confirm(confirmed);
            game.rollDice(); //roll for logical aspects
        }
        catch (IllegalStateException e){
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle(e.getMessage());
            alert.setHeaderText("Please select a scoring category and confirm dice to end your turn");
            alert.showAndWait();
        }

        updateDice();
    }

    //adds all the buttons to the map
    private void addDiceToMaps(){
        diceMap.put(die0, false);
        diceMap.put(die1, false);
        diceMap.put(die2, false);
        diceMap.put(die3, false);
        diceMap.put(die4, false);

        diceValues.put(die0, 1);
        diceValues.put(die1, 1);
        diceValues.put(die2, 1);
        diceValues.put(die3, 1);
        diceValues.put(die4, 1);


    }

    private void resetButtons(){
        addDiceToMaps();
        for(Button button : diceMap.keySet()){ //Reset all buttons to default
            button.setStyle(UNSELECTED_STYLE);
            diceMap.put(button, false);
            diceValues.put(button, 1);
            button.setText("");
            button.setDisable(true);
        }
    }

    private void initialRoll(){
        try{
            game.rollDice();
        } catch (IllegalStateException e){e.printStackTrace();}
        updateDice();
    }

    private void updateDice(){
        int i = 0; //set Dice to their new value
        List diceNums = game.getDice().getUnconfirmed();
        for(Button dice : diceMap.keySet()){
            dice.setDisable(false);
            if(!diceMap.get(dice)){
                ImageView imageView = new ImageView(new Image("/yahtzee/resources/uDie" +
                        diceNums.get(i).toString() + ".jpg"));
                imageView.setFitHeight(85);
                imageView.setPreserveRatio(true);
                dice.setGraphic(imageView);
                diceValues.put(dice, (int) diceNums.get(i));
                i++;
            }
        }
    }
}