package yahtzee.gui;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import yahtzee.model.Player;
import yahtzee.model.PlayerType;
import yahtzee.model.ScoringCategory;

public class ScoreRow {
    private final SimpleStringProperty category = new SimpleStringProperty("");
    private final SimpleIntegerProperty p1Score = new SimpleIntegerProperty(0);
    private final SimpleIntegerProperty p2Score = new SimpleIntegerProperty(0);

    public ScoreRow() {
    }

    public ScoreRow(String category) {
        setCategory(category);
        setP1Score(Player.getInstance(PlayerType.ONE).getPoints().get(string2Category(category)));
        setP2Score(Player.getInstance(PlayerType.TWO).getPoints().get(string2Category(category)));
    }

    public String getCategory() {
        return category.get();
    }

    public ScoringCategory getCategoryENUM() {
        return string2Category(category.get());
    }

    public SimpleStringProperty categoryProperty() {
        return category;
    }

    public void setCategory(String category) {
        this.category.set(category);
    }

    public int getP1Score() {
        return p1Score.get();
    }

    public SimpleIntegerProperty p1ScoreProperty() {
        return p1Score;
    }

    public void setP1Score(int p1Score) {
        this.p1Score.set(p1Score);
    }

    public int getP2Score() {
        return p2Score.get();
    }

    public SimpleIntegerProperty p2ScoreProperty() {
        return p2Score;
    }

    public void setP2Score(int p2Score) {
        this.p2Score.set(p2Score);
    }

    private ScoringCategory string2Category(String s) {
        switch (s) {
            case "ACES":
                return ScoringCategory.ACES;
            case "TWOS":
                return ScoringCategory.TWOS;
            case "THREES":
                return ScoringCategory.THREES;
            case "FOURS":
                return ScoringCategory.FOURS;
            case "FIVES":
                return ScoringCategory.FIVES;
            case "SIXES":
                return ScoringCategory.SIXES;
            case "THREEOFAKIND":
                return ScoringCategory.THREEOFAKIND;
            case "FOUROFAKIND":
                return ScoringCategory.FOUROFAKIND;
            case "FULLHOUSE":
                return ScoringCategory.FULLHOUSE;
            case "SMALLSTRAIGHT":
                return ScoringCategory.SMALLSTRAIGHT;
            case "LARGESTRAIGHT":
                return ScoringCategory.LARGESTRAIGHT;
            case "YAHTZEE":
                return ScoringCategory.YAHTZEE;
            case "CHANCE":
                return ScoringCategory.CHANCE;
            default:
                return null;
        }
    }
}
