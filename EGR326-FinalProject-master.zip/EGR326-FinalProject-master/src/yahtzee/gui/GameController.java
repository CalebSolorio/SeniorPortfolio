package yahtzee.gui;

import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import yahtzee.model.Game;
import yahtzee.model.GameState;
import yahtzee.model.Player;
import yahtzee.model.PlayerType;
import yahtzee.strategy.*;
import yahtzee.util.ScoreCalculator;

import java.io.IOException;
import java.net.URL;
import java.util.Observable;
import java.util.Observer;
import java.util.ResourceBundle;
import java.util.concurrent.TimeUnit;

/**
 * Created by Austin
 */
public class GameController implements Initializable, Observer {

    protected Game game;

    @FXML private VBox container;
    @FXML private HBox upperDiv;
    @FXML private VBox gameControls;
    @FXML private Button resetGame;
    @FXML private Button startGame;
    @FXML private Button confirm;
    @FXML private Button exitGame;
    @FXML private ComboBox player2Type;
    @FXML private ToggleGroup toggleView;
    @FXML private RadioButton radioButton;
    @FXML private RadioButton radioPainted;
    @FXML private Label player1Wins;
    @FXML private Label player2Wins;
    private TableView<ScoreRow> table;
    private StrategyIntelligence AIType;
    public Strategy strat;
    private static boolean preventResetLoop = false;

    /***
     * @param location The location of the controller.
     * @param resources The resources required to initialize the controller.
     */
    @Override
    public  void initialize(URL location, ResourceBundle resources){
        game = Game.getInstance();
        game.addObserver(this);
        try {
            //add score Table
            FXMLLoader scoreTable = new FXMLLoader(getClass().getResource("ScoreTableView.fxml"));
            table = scoreTable.load();
            table.setStyle("-fx-pref-width: 270");
            table.getSelectionModel().select(0);

            setBoard("BUTTONS");

            //set layouts
            upperDiv.getChildren().add(0,table);
        }
        catch (IOException e){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Unable to get board");
            alert.showAndWait();
        }
        resetGame.setOnAction(e -> reset());
        startGame.setOnAction(e -> startGame());
        confirm.setOnAction(e -> endTurn());
        exitGame.setOnAction(e -> exitGame());
        toggleView.selectedToggleProperty().addListener((observable, oldValue, newValue) ->
                setBoard(newValue.getUserData().toString()));


        ObservableList<String> items = player2Type.getItems();
        for(StrategyIntelligence SI : StrategyIntelligence.values()){
            items.add(SI.toString());
        }

        player2Type.getSelectionModel().selectFirst();
    }

    /**
     * Updates the controller.
     * @param o The Observable component
     * @param arg The object the Observable component has provided.
     */
    @Override
    public  void update(Observable o, Object arg){
        if(arg == GameState.PLAYERTWOTURNONE){
            updateScoreboard(PlayerType.ONE);
            confirm.setText("End Player Two's Turn");
        }
        else if (arg == GameState.PLAYERONETURNONE){
            updateScoreboard(PlayerType.TWO);
            confirm.setText("End Player One's Turn");
            preventResetLoop = false;
        }
        else if(arg == GameState.PLAYERONEWIN || arg == GameState.PLAYERTWOWIN){
            Player p1 = Player.getInstance(PlayerType.ONE);
            player1Wins.setText("Player 1: " + p1.getWins() + " Wins, " + p1.getLosses() + " Losses");

            Player p2 = Player.getInstance(PlayerType.TWO);
            player2Wins.setText("Player 2: " + p2.getWins() + " Wins, " + p2.getLosses() + " Losses");

            if(arg == GameState.PLAYERONEWIN){
                notifyWinner(PlayerType.ONE);
            }
            else{
                notifyWinner(PlayerType.TWO);
            }
            reactivate();
        }
        else if (arg == GameState.NOTSTARTED && !preventResetLoop){
            preventResetLoop = true;
            reset();
        }

    }

    private void endTurn(){
        try{
            game.addScore(table.getSelectionModel().getSelectedItem().getCategoryENUM());
        }
        catch (IllegalStateException e){
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle(e.getMessage());
            alert.setHeaderText("Please use all your rolls and select a scoring category to end your turn");
            alert.showAndWait();
        } catch (IllegalArgumentException e){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle(e.getMessage());
            alert.setHeaderText("Score already submitted for this category.");
            alert.showAndWait();
        } catch (NullPointerException e){
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle(e.getMessage());
            alert.setHeaderText("Please choose category to add a score two before ending your turn");
            alert.showAndWait();
        }
    }

    private void reset(){
        game.reset();
        for(int i = 0; i <= 13; i++){
            table.getSelectionModel().select(i);
            table.getSelectionModel().getSelectedItem().setP1Score(0);
            table.getSelectionModel().getSelectedItem().setP2Score(0);
        }
        game.reset();
        startGame.setDisable(false);
        radioButton.setDisable(false);
        radioPainted.setDisable(false);
        player2Type.setDisable(false);
    }

    private void startGame(){
        if(player2Type.getSelectionModel().getSelectedItem() != null) {
            AIType = stringToEnum(player2Type.getSelectionModel().getSelectedItem().toString());
            PlayerStrategy.setStrategy(PlayerType.TWO, AIType);
            strat = StrategyFactory.createStrategy(AIType);
        }
        reset();
        game.startGame();
        startGame.setDisable(true);
        radioButton.setDisable(true);
        radioPainted.setDisable(true);
        player2Type.setDisable(true);
    }

    private StrategyIntelligence stringToEnum(String s){
        switch (s) {
            case "RANDOM":
                return StrategyIntelligence.RANDOM;
            case "OFAKINDER":
                return StrategyIntelligence.OFAKINDER;
            case "UPPERSECTIONER":
                return StrategyIntelligence.UPPERSECTIONER;
            case "FOURANDUP":
                return StrategyIntelligence.FOURANDUP;
            case "SMART":
                return StrategyIntelligence.SMART;
            default:
                return StrategyIntelligence.HUMAN;
        }
    }
    // Sets the board to be used.
    private void setBoard(String type) {
        try {
            container.getChildren().set(2, new BoardViewFactory().createBoardView(type));
        } catch (IllegalArgumentException e) {
            e.printStackTrace(); // Shouldn't happen under normal use.
        } catch (IOException e) {
            e.printStackTrace(); // Will probably never happen.
        }
    }

    private void exitGame(){
        Platform.exit();
    }

    private void reactivate(){
        startGame.setDisable(false);
        radioButton.setDisable(false);
        radioPainted.setDisable(false);
        player2Type.setDisable(false);
    }

    private void updateScoreboard(PlayerType player){
        if(player.equals(PlayerType.ONE)){
            for(int i = 0; i < 13; i++){
                table.getSelectionModel().select(i);
                if(Player.getInstance(PlayerType.ONE).getPoints().get(table.getSelectionModel().getSelectedItem().getCategoryENUM()) != null) {
                    table.getSelectionModel().getSelectedItem().setP1Score(game.getPlayer(PlayerType.ONE).getPoints().get(table.getSelectionModel().getSelectedItem().getCategoryENUM()));
                }
            }
            table.getSelectionModel().select(13);
            table.getSelectionModel().getSelectedItem().setP1Score(game.getTotalScore(PlayerType.ONE));
        }
        else if (player.equals(PlayerType.TWO)){
            for(int i = 0; i < 13; i++){
                table.getSelectionModel().select(i);
                if(Player.getInstance(PlayerType.TWO).getPoints().get(table.getSelectionModel().getSelectedItem().getCategoryENUM()) != null) {
                    table.getSelectionModel().getSelectedItem().setP2Score(game.getPlayer(PlayerType.TWO).getPoints().get(table.getSelectionModel().getSelectedItem().getCategoryENUM()));
                }
            }
            table.getSelectionModel().select(13);
            table.getSelectionModel().getSelectedItem().setP2Score(game.getTotalScore(PlayerType.TWO));
        }
    }

    private void notifyWinner(PlayerType p){
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("CONGRATULATIONS");
        alert.setHeaderText("Congratulations PLAYER " + p.toString() + " You've Won!");
        alert.showAndWait();
    }
}
