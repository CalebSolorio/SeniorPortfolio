package yahtzee.gui;

import javafx.fxml.FXMLLoader;
import javafx.scene.Node;

import java.io.IOException;

/**
 * Created by Austin on 4/24/2017.
 */
public class BoardViewFactory {
    /**
     * Creates the specified board view
     *
     * @param type The type of board view desired.
     * @return The relevant board view.
     * @throws IllegalArgumentException if type is invalid.
     * @throws IOException              If the fxml files cannot be found.
     */
    public Node createBoardView(String type) throws IllegalArgumentException, IOException {
        try {
            BoardType boardType = BoardType.valueOf(type);
            String name = boardType == BoardType.BUTTONS ? "DiceView.fxml" : "paintedView.fxml";
            FXMLLoader loader = new FXMLLoader(getClass().getResource(name));
            Node node = loader.load();

            return node;
        } catch (IllegalArgumentException e) {
            e.printStackTrace(); // Shouldn't happen under normal use.
        } catch (IOException e) {
            e.printStackTrace(); // Will probably never happen.
        }

        return null;
    }
}
