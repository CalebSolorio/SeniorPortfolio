package yahtzee.gui;

/**
 * Created by Austin on 4/24/2017.
 */
public enum BoardType {
    BUTTONS, PAINTED
}