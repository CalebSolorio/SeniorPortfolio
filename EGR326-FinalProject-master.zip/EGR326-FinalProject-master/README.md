# EGR326-FinalProject
This is the best final project that EGR326 has ever seen in it's life. This project is going to make EGR326 great again.

Nahtzee
