/**
 * Created by Caleb Solorio on 9/12/2016.
 */
public class VehicleTest {
    public static void main(String[] args) {

        Vehicle[] vehicles = new Vehicle[3];

        vehicles[0] = new Truck("Ford", "F-150", 2016, true, 35000, 17, false, 2);
        vehicles[1] = new Car("Tesla", "Model 3", 2017, false, 35000, 0, false);
        vehicles[2] = new Car("Corvette", "Stingray", 2017, false, 55450, 17, false);

        Inventory inv = new Inventory();

        for(int i = 0; i < vehicles.length; i++) {
            vehicles[i].printVehicle();
            inv.add(vehicles[i]);
        }

        System.out.println("Inventory Details:");

        inv.findCheapestVehicle().printVehicle();
        inv.findMostExpensiveVehicle().printVehicle();
        inv.printAveragePriceOfAllVehicles();
        inv.remove(inv.findMostExpensiveVehicle());
        inv.findMostExpensiveVehicle().printVehicle();
        inv.remove(vehicles[2]);
    }
}
