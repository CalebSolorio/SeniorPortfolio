/**
 * Created by Caleb Solorio on 9/12/2016.
 */
public class Truck extends Vehicle {

    private boolean sideStep;
    private float towCap;

    public Truck(String newMake, String newModel, int newYear, boolean newWheelDrive, float newPrice,
               float newMpg, boolean newSideStep, float newTowCap) {
        setMake(newMake);
        setModel(newModel);
        setYear(newYear);
        setWheelDrive(newWheelDrive);
        setPrice(newPrice);
        setMpg(newMpg);
        setSideStep(newSideStep);
        setTowCap(newTowCap);
    }

    public void setSideStep(boolean in) {
        sideStep = in;
    }

    public void setTowCap(float in) {
        towCap = in;
    }

    public boolean getSideStep() {
        return  sideStep;
    }

    public float getTowCap() {
        return towCap;
    }

    public void printVehicle() {
        super.printVehicle();

        if(getSideStep())
            System.out.println("Side Step");
        else
            System.out.println("No Side Step");

        System.out.println("Tow up to " + getTowCap() + " tons");
    }
}
