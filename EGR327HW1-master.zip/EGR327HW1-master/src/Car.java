/**
 * Created by Caleb Solorio on 9/12/2016.
 */
public class Car extends Vehicle {

    private boolean convertible;

    public Car(String newMake, String newModel, int newYear, boolean newWheelDrive, float newPrice,
               float newMpg, boolean newConvertible) {
        setMake(newMake);
        setModel(newModel);
        setYear(newYear);
        setWheelDrive(newWheelDrive);
        setPrice(newPrice);
        setMpg(newMpg);
        setConvertible(newConvertible);
    }

    public void setConvertible(boolean in) {
        convertible = in;
    }

    public boolean getConvertible() {
        return convertible;
    }

    public void printVehicle() {
        super.printVehicle();
        if(getConvertible())
            System.out.println("Convertible");
        else
            System.out.println("No Convertible");
    }
}
