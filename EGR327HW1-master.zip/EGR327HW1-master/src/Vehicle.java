/**
 * Created by Caleb Solorio on 9/12/2016.
 */
public class Vehicle {

    private String make;
    private String model;
    private int year;
    private boolean wheelDrive;
    private float price;
    private float mpg;

    public Vehicle() {}

    // Setters
    public void setMake(String in) {
        make = in;
    }

    public void setModel(String in) {
        model = in;
    }

    public void setYear(int in) {
        year = in;
    }

    public void setWheelDrive(boolean in) {
        wheelDrive = in;
    }

    public void setPrice(float in) {
        price = in;
    }

    public void setMpg(float in) {
        mpg = in;
    }

    // Getters
    public String getMake() {
        return make;
    }

    public String getModel() {
        return  model;
    }

    public int getYear() {
        return year;
    }

    public boolean getWheelDrive(){
        return wheelDrive;
    }

    public float getPrice() {
        return price;
    }

    public float getMpg() {
        return  mpg;
    }


    public void printVehicle() {
        System.out.println(getYear() + " " + getMake() + " " + getModel());
        if(getWheelDrive())
            System.out.println("4WD");
        else
            System.out.println("No 4WD");
        System.out.println("$" + getPrice());
        System.out.println(getMpg() + " MPG");
    }
}
