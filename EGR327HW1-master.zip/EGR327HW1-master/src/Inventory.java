import java.util.ArrayList;
import java.util.List;

/**
 * Created by Caleb Solorio on 9/19/2016.
 */
public class Inventory {

    private List<Vehicle> list = new ArrayList<>();

    public Inventory(){}

    public void add(Vehicle item) {
        list.add(item);
    }

    public void remove(Vehicle item) {
        list.remove(item);
    }

    public Vehicle findCheapestVehicle() {
        Vehicle cheapest = null;
        for(Vehicle item : list) {
            if(cheapest == null || item.getPrice() < cheapest.getPrice()) {
                cheapest = item;
            }
        }
        if(cheapest != null){
            return cheapest;
        }
        return null;
    }

    public Vehicle findMostExpensiveVehicle() {
        Vehicle mostExpensive = null;
        for(Vehicle item : list) {
            if(mostExpensive == null || item.getPrice() > mostExpensive.getPrice()) {
                mostExpensive = item;
            }
        }
        if(mostExpensive != null) {
            return mostExpensive;
        }
        return null;
    }

    public void printAveragePriceOfAllVehicles() {
        double sum = 0;
        int count = 0;

        for(Vehicle item : list) {
            sum += item.getPrice();
            count++;
        }
        System.out.println("The average price of the vehicles in our inventory is " + sum / count);
    }
}
