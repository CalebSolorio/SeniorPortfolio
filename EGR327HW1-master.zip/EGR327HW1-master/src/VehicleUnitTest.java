import org.junit.Assert;
import org.junit.Test;

/**
 * Created by Caleb Solorio on 9/20/2016.
 */
public class VehicleUnitTest {
    @Test
    public void vehicleCarTest(){
        Car car = new Car("Corvette", "Stingray", 2017, false, 55450, 17, false);

        Assert.assertEquals("Make incorrect", "Corvette", car.getMake());
        Assert.assertEquals("Model incorrect", "Stingray", car.getModel());
        Assert.assertEquals("Year incorrect", 2017, car.getYear());
        Assert.assertEquals("Wheel Drive incorrect", false, car.getWheelDrive());
        Assert.assertEquals("Price incorrect", 55450f, car.getPrice(), 0.0f);
        Assert.assertEquals("Mpg incorrect", 17f, car.getMpg(), 0.0f);
    }

    @Test
    public void vehicleTruckTest() {
        Truck truck = new Truck("Ford", "F-150", 2016, true, 35000, 17, false, 2);

        Assert.assertEquals("Make incorrect", "Ford", truck.getMake());
        Assert.assertEquals("Model incorrect", "F-150", truck.getModel());
        Assert.assertEquals("Year incorrect", 2016, truck.getYear());
        Assert.assertEquals("Wheel Drive incorrect", true, truck.getWheelDrive());
        Assert.assertEquals("Price incorrect", 35000f, truck.getPrice(), 0.0f);
        Assert.assertEquals("Mpg incorrect", 17f, truck.getMpg(), 0.0f);
    }

    @Test
    public void convertibleTest(){
        Car car = new Car("Corvette", "Stingray", 2017, false, 55450, 17, false);

        Assert.assertFalse(car.getConvertible());

        car.setConvertible(true);

        Assert.assertTrue(car.getConvertible());
    }

    @Test
    public void sideStepTest() {
        Truck truck = new Truck("Ford", "F-150", 2016, true, 35000, 17, false, 2);

        Assert.assertFalse(truck.getSideStep());

        truck.setSideStep(true);

        Assert.assertTrue(truck.getSideStep());
    }

    @Test
    public void towCapTest() {
        Truck truck = new Truck("Ford", "F-150", 2016, true, 35000, 17, false, 2);

        Assert.assertEquals("Wrong first tow cap amount!", 2f, truck.getTowCap(), 0.0f);

        truck.setTowCap(5.2f);

        Assert.assertEquals("Wrong second tow cap amount!", 5.2f, truck.getTowCap(), 0.0f);
    }

    @Test
    public void makeTest() {
        Truck truck = new Truck("Ford", "F-150", 2016, true, 35000, 17, false, 2);

        Assert.assertEquals("Wrong first make", "Ford", truck.getMake());

        truck.setMake("Lego");

        Assert.assertEquals("Wrong second make", "Lego", truck.getMake());
    }

    @Test
    public void modelTest() {
        Vehicle truck = new Truck("Ford", "F-150", 2016, true, 35000, 17, false, 2);

        Assert.assertEquals("Wrong first model", "F-150", truck.getModel());

        truck.setModel("F-350");

        Assert.assertEquals("Wrong second model", "F-350", truck.getModel());
    }

    @Test
    public void yearTest() {
        Vehicle truck = new Truck("Ford", "F-150", 2016, true, 35000, 17, false, 2);

        Assert.assertEquals("Wrong first year", 2016, truck.getYear());

        truck.setYear(1865);

        Assert.assertEquals("Wrong second year", 1865, truck.getYear());
    }

    @Test
   public void wheelDrive() {
        Truck truck = new Truck("Ford", "F-150", 2016, true, 35000, 17, false, 2);

        Assert.assertTrue(truck.getWheelDrive());

        truck.setWheelDrive(false);

        Assert.assertFalse(truck.getWheelDrive());
    }

    @Test
    public void priceTest() {
        Truck truck = new Truck("Ford", "F-150", 2016, true, 35000, 17, false, 2);

        Assert.assertEquals("First price incorrect", 35000f, truck.getPrice(), 0.0f);

        truck.setPrice(35000.01f);

        Assert.assertEquals("Second price incorrect", 35000.01f, truck.getPrice(), 0.0f);
    }

    @Test
    public void mpgTest() {
        Truck truck = new Truck("Ford", "F-150", 2016, true, 35000, 17, false, 2);

        Assert.assertEquals("First mpg incorrect", 17f, truck.getMpg(), 0.0f);

        truck.setMpg(17.76f);

        Assert.assertEquals("Second mpg incorrect", 17.76f, truck.getMpg(), 0.0f);
    }

    @Test
    public void addTest() {
        Inventory inv = new Inventory();
        Car car = new Car("Tesla", "Model 3", 2017, false, 35000, 0, false);

        inv.add(car);

        Assert.assertEquals("Not equal", car, inv.findCheapestVehicle());
    }

    @Test
    public void removeTest() {
        Inventory inv = new Inventory();
        Car car1 = new Car("Tesla", "Model 3", 2017, false, 35000, 0, false);
        Car car2 = new Car("Tesla", "Model D", 2017, false, 70000, 0, false);

        inv.add(car1);
        inv.add(car2);

        Assert.assertEquals("Not the cheapest vehicle", car1, inv.findCheapestVehicle());

        inv.remove(car1);

        Assert.assertEquals("Vehicle wasn't removed", car2, inv.findCheapestVehicle());
    }

    @Test
    public void cheapestVehicleTest() {
        Inventory inv = new Inventory();
        Car car1 = new Car("Tesla", "Model 3", 2017, false, 35000, 0, false);
        Car car2 = new Car("Tesla", "Model D", 2017, false, 70000, 0, false);
        Car car3 = new Car("Tesla", "Model X", 2017, false, 100000, 0, false);

        inv.add(car1);
        inv.add(car2);
        inv.add(car3);

        Assert.assertEquals("Not the cheapest vehicle", car1, inv.findCheapestVehicle());

        inv.remove(car1);

        Assert.assertEquals("Vehicle wasn't removed", car2, inv.findCheapestVehicle());
    }

    @Test
    public void mostExpensiveTest() {
        Inventory inv = new Inventory();
        Car car1 = new Car("Tesla", "Model 3", 2017, false, 35000, 0, false);
        Car car2 = new Car("Tesla", "Model D", 2017, false, 70000, 0, false);
        Car car3 = new Car("Tesla", "Model X", 2017, false, 100000, 0, false);

        inv.add(car1);
        inv.add(car2);
        inv.add(car3);

        Assert.assertEquals("Not the most expensive vehicle", car3, inv.findMostExpensiveVehicle());

        inv.remove(car3);

        Assert.assertEquals("Vehicle wasn't removed", car2, inv.findMostExpensiveVehicle());
    }
}
