package HW7;

import edu.princeton.cs.algs4.*;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Iterator;

/**
 * Created by Caleb Solorio on 3/27/2017.
 */
public class MST {
    public static void main(String[] args) {
        EdgeWeightedGraph graph = readGraphData("graphdata.txt");

        System.out.println(primMSTStats(graph));
        System.out.println(kruskalMSTStats(graph));
    }

    public static EdgeWeightedGraph readGraphData(String filePath) {
        EdgeWeightedGraph graph = new EdgeWeightedGraph(101);

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] edgeData = line.split("\\s+");
                graph.addEdge(new Edge(Integer.parseInt(edgeData[0]),
                        Integer.parseInt(edgeData[1]), Double.parseDouble(edgeData[2])));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return graph;
    }

    public static String primMSTStats(EdgeWeightedGraph graph) {
        Stopwatch stopwatch = new Stopwatch();
        PrimMST prim = new PrimMST(graph);
        double time = stopwatch.elapsedTime();

        Iterator<Edge> iterator = prim.edges().iterator();
        int edgeCount = 0;
        while(iterator.hasNext()) {
            iterator.next();
            edgeCount++;
        }

        return "Prim’s algorithm found an MST of " + edgeCount + " edges, with a total weight of\n" +
                prim.weight() + ", in " + time + " seconds";
    }

    public static String kruskalMSTStats(EdgeWeightedGraph graph) {
        Stopwatch stopwatch = new Stopwatch();
        KruskalMST kruskal = new KruskalMST(graph);
        double time = stopwatch.elapsedTime();

        Iterator<Edge> iterator = kruskal.edges().iterator();
        int edgeCount = 0;
        while(iterator.hasNext()) {
            iterator.next();
            edgeCount++;
        }

        return "Kruskal’s algorithm found an MST of " + edgeCount + " edges, with a total weight of\n" +
                kruskal.weight() + ", in " + time + " seconds";
    }
}
