console.log('Loading ClearTokens function...');

/*
    This removes old tokens from DynamoDB.

    Use AWS to communicate with DynamoDB,
*/

var AWS = require('aws-sdk');

// Establish a connection to DynamoDB
AWS.config.update({
    region: "us-east-1"
});

// Establish a connection with DynamoDB
var docClient = new AWS.DynamoDB.DocumentClient();

exports.handler = function(event, context, callback) {
    // Initialize variables needed later
    var table = "aiche_tokens";

    // Get the time from 30 days ago
    var time = Math.round(new Date().getTime() / 1000) - (24 * 60 * 60) * 30;

    // Prepare the query
    var params = {
        TableName: table,
        FilterExpression: "created_at < :t",
        ExpressionAttributeValues: {
            ":t": time,
        },
        Limit: 1
    };

    // Execute the query
    docClient.scan(params, function(err, data) {
        if (err) {
            console.error("Unable to perform query. Error JSON:",
                JSON.stringify(err, null, 2));
            context.fail(err);
        } else {
            if(data.Items.length > 0) {
                var count = 0;
                data.Items.forEach(function(item, index) {
                    // Set to delete tokens more than 30 days old
                    params = {
                        TableName: table,
                        Key: {
                            token_hash: item.token_hash
                        },
                        Limit: 1,
                    };

                    // Delete tokens
                    docClient.delete(params, function(err, delData) {
                        if (err) {
                            console.error("Unable to delete token. Error JSON:",
                                JSON.stringify(err, null, 2));
                            context.fail(err);
                        } else {
                            console.log("Deleted token:",
                                JSON.stringify(delData, null, 2));

                            count++;
                            if(count == data.Items.lenth) {
                                callback(null, { status: 200,
                                        tokensDeleted: data });
                            }
                        }
                    });
                });
            } else {
                callback(null, 404);
            }
        }
    });
};
