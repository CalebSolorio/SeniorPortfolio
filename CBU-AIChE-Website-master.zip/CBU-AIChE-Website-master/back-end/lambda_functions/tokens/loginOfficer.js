console.log('Loading loginOfficer function...');

/*
    This will verify the email/password combo,
    then create a new token.

    Use AWS to communicate with DynamoDB,
    underscore to parse payload data,
    bcrypt for data encryption,
    cryptojs for comparing tokens,
    and jsonwebtokens for JSON Web Token creation
    (who would've thunk it).
*/

var AWS = require('aws-sdk');
var _ = require('underscore');
var bcrypt = require('bcryptjs');
var cryptojs = require('crypto-js');
var jwt = require('jsonwebtoken');

// Establish a connection to DynamoDB
AWS.config.update({
    region: "us-east-1",
});

// Establish a connection with DynamoDB
var docClient = new AWS.DynamoDB.DocumentClient();

exports.handler = function(req, context, callback) {
    // Pick out the email and password from the request body.
    var body = _.pick(req, 'email', 'password');

    // First authenticate the user. Then, create a token.
    // Insert the token into the DB and send it back to the client.
    authenticate(body).then(function(officer) {
        var table = "aiche_tokens";
        var token = generateToken(officer, 'authentication');
        var hash = cryptojs.MD5(token).toString();
        var time = Math.round(new Date().getTime() / 1000);

        // Prepare to insert a new token
        var params = {
            TableName: table,
            Item: {
                "token_hash": hash,
                "created_at": time,
            }
        };

        // Insert a new token.
        docClient.put(params, function(err, tokenData) {
            if (err) {
                console.error("Unable to insert token. Error JSON:",
                    JSON.stringify(err, null, 2));
                context.fail(err);
            } else {
                console.log("Inserted token:", JSON.stringify(tokenData, null, 2));
                callback(null, {
                    status: 200,
                    authorizationToken: token
                });
            }
        });
    }).catch(function() {
        callback(401);
    });

    // Compare request data to the email and encrypted password in the DB.
    function authenticate(body) {
        console.log("body:", body);
        return new Promise(function(resolve, reject) {
            if (typeof body.email !== 'string' ||
                typeof body.password !== 'string') {
                return reject();
            }

            var table = "aiche_credentials";
            var email = body.email;

            // Prepare the query
            var params = {
                TableName: table,
                KeyConditionExpression: "email = :e",
                ExpressionAttributeValues: {
                    ":e": email,
                },
                Limit: 1
            };

            console.log("params", params);

            // Execute the query
            docClient.query(params, function(err, data) {
                console.log("hi data:", data);
                if (err) {
                    console.error("Unable to perform query. Error JSON:",
                        JSON.stringify(err, null, 2));
                    context.fail(err);
                } else {
                    console.log("Queried successfully. JSON: ",
                        JSON.stringify(data, null, 2));

                    // See if the queried user's password hash matches.
                    if (data.Items.length > 0) {
                        var passwordHash = data.Items[0].password_hash;
                        var match = bcrypt.compareSync(body.password, passwordHash);

                        if (match) {
                            return resolve(data.Items);
                        } else {
                            return reject();
                        }
                    } else {
                        return reject();
                    }
                }
            });
        });
    }

    // Create a token using the clients encrypted and signed info.
    function generateToken(officer, type) {
        if (!_.isString(type)) {
            return undefined;
        }

        try {
            var stringData = JSON.stringify({
                id: officer.id,
                type: type
            });
            var encryptedData = cryptojs.AES.encrypt(stringData,
                'eR8A3wSW4mM7u%2@').toString();
            var token = jwt.sign({
                token: encryptedData
            }, 'XvCQtU^ZSfr5Tr#y');

            return token;
        } catch (e) {
            console.error(e);
            return undefined;
        }
    }
};
