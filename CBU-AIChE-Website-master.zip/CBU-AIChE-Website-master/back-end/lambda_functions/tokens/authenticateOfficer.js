console.log('Loading authenticateOfficer function...');

/*
    This is an authenticator that will run before
    any manipulation of DynamoDB or S3 takes place.

    Use AWS to communicate with DynamoDB,
    cryptojs for comparing tokens.
*/

var AWS = require("aws-sdk");
var cryptojs = require('crypto-js');

// Establish a connection to DynamoDB
AWS.config.update({
    region: "us-east-1",
});

exports.handler = function(event, context, callback) {
    // Pick out the authentication token from the request body.
    var token = event.authorizationToken;

    // Find a hashed token that matches the clients.
    if (token !== undefined) {
        var docClient = new AWS.DynamoDB.DocumentClient();
        var table = "aiche_tokens";
        var hashedToken = cryptojs.MD5(token).toString();

        // Prepare the query
        var params = {
            TableName: table,
            Key: {
                token_hash: hashedToken
            },
            Limit: 1
        };

        // Execute the query
        docClient.get(params, function(err, data) {
            if (err) {
                console.error("Unable to read item. Error JSON:",
                    JSON.stringify(err, null, 2));
                context.fail(err);
            } else {
                console.log("Queried successfully:",
                    JSON.stringify(data, null, 2));
                if (data.Item !== undefined) {
                    var principalId = "officer";
                    var effect = "Allow";
                    var resource = "arn:aws:execute-api:us-east-1:372695149422:7um0hkzst5/*";

                    context.succeed(generatePolicy(principalId,
                        effect, resource));
                } else {
                    context.fail("Not valid token. Access Denied.");
                }
            }
        });
    } else {
        console.log("Token undefined");
        context.fail("No token given.");
    }

    // This function generates a policy for the end user.
    var generatePolicy = function(principalId, effect, resource) {
        console.log("Generating policy");
        var authResponse = {};
        authResponse.principalId = principalId;
        if (effect && resource) {
            var policyDocument = {};
            policyDocument.Version = '2012-10-17'; // default version
            policyDocument.Statement = [];
            var statementOne = {};
            statementOne.Action = 'execute-api:Invoke'; // default action
            statementOne.Effect = effect;
            statementOne.Resource = resource;
            policyDocument.Statement[0] = statementOne;
            authResponse.policyDocument = policyDocument;
        }
        return authResponse;
    };
};
