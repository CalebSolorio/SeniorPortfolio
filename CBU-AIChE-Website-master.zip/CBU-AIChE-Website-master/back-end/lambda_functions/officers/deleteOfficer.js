console.log('Loading deleteOfficer function...');

/*
    This removes a specified officer's info and images
    from DynamoDB and S3, respectively.

    Use AWS to communicate with DynamoDB.
*/

var AWS = require('aws-sdk');

// Establish a connection to AWS
AWS.config.update({
    region: "us-east-1",
});

exports.handler = function(event, context, callback) {
    var count = 0;

    var table = "aiche_officers";
    var id = event.id;

    // Delete officer info from DynamoDB
    deleteOfficerFromTable(table, id, function(err) {
        if (err) {
            callback(err);
        } else {
            count++;
            if (count == 2) {
                callback(200);
            }
        }
    });

    var bucket = "cbu-aiche";
    var folder = "website/officers/" + id + "/images/";

    console.log("time to delete from s3");

    deleteOfficerFromS3(bucket, folder, function(err) {
        if (err) {
            callback(err);
        } else {
            count++;
            if (count == 2) {
                callback(null, {
                    status: 200
                });
            }
        }
    });
};

function deleteOfficerFromTable(table, id, callback) {
    // Establish a connection with DynamoDB
    var docClient = new AWS.DynamoDB.DocumentClient();

    // Prepare the statement.
    var params = {
        TableName: table,
        Key: {
            "id": id,
        },
        ConditionExpression: "attribute_not_exists(admin)",
    };

    // Execute the statement
    docClient.delete(params, function(err, data) {
        if (err) {
            console.error("Unable to delete officer from DynamoDB. Error JSON:",
                JSON.stringify(err, null, 2));
            callback(err);
        } else {
            if (data.Attributes) {
                console.log("Successfully deleted officer from DynamoDB! JSON: ",
                    JSON.stringify(data, null, 2));
                callback(null);
            } else {
                console.log("Officer is either admin or nonexistent! JSON: ",
                    JSON.stringify(data, null, 2));
                callback(404);
            }
        }
    });

}

function deleteOfficerFromS3(bucket, folder, callback) {
    // Establish connection to S3
    var s3 = new AWS.S3();

    // Establish the parameters to list all objects in the directory.
    var params = {
        Bucket: bucket,
        Delimiter: '/',
        Prefix: folder,
    };

    console.log("listing objects", params);

    // List all objects in the directory.
    s3.listObjects(params, function(err, data) {
        if(err) {
            callback(err);
        } else {
            console.log("data", data);

            s3Objects = [];

            // Add all objects to the list.
            data.Contents.forEach(function(element, index, arr) {
                console.log(index + ': ' + element.Key);
                var thisKey = {
                    Key: element.Key
                };
                s3Objects.push(thisKey);
            });

            // Establish the parameters to delete all objects in the directory.
            params = {
              Bucket: bucket,
              Delete: {
                Objects: s3Objects
              }
            };

            // Delete all objects in the directory.
            s3.deleteObjects(params, function(err, data) {
                callback(err ? err : null);
            });
        }
    });

}
