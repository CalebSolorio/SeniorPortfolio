console.log('Loading postOfficer function...');

/*
    Creates a new officer in DynamoDB,
    then (possibly) uploads their photo to S3.

    Use AWS to communicate with DynamoDB,
    underscore to parse payload data,
    asyc for asynchronus tasks
    bcryptjs for password hashing,
    uuid for generating unique identifiers,
    and GraphicsMagik for image manipulation.
*/

var aws = require("aws-sdk");
var _ = require('underscore');
var async = require("async");
var bcrypt = require('bcryptjs');
var uuid = require('node-uuid');
var gm = require('gm')
    .subClass({
        imageMagick: true
    });

// Establish a connection to DynamoDB
aws.config.update({
    region: "us-east-1",
});

exports.handler = function(event, context, callback) {
    // Parse the details that we care about
    var data = _.pick(event, "email", "password", "name",
        "position", "link", "image", "order");

    async.waterfall([
        function hash(next) {
            if (data.password) {
                hashPassword(data, function(err, hash) {
                    if(err) {
                        next(err);
                    } else {
                        data.password_hash = hash;
                        next(null);
                    }
                });
            } else {
                next(null);
            }
        }, function prepare(next) {

            // Create a unique identifier
            data.id = uuid.v1();

            prepareOfficer(data, function(err, item) {
                if(err) {
                    callback(err);
                } else {
                    next(null, item);
                }
            });
        }, function create(item, next) {
            // Counter will increment until all 5 opperations have exectuted
            var uploadCount = 0;

            // Create officer
            createOfficer(item, function(err) {
                if (err) {
                    console.error("Unable to upload create officer. " +
                        "Error JSON:", err);
                    next(err);
                } else {
                    // Increment until all 5 operations have executed.
                    uploadCount++;
                    if (uploadCount == 5) {
                        next(null);
                    }
                }
            });

            var regex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

            if(data.email && regex.test(data.email) &&
                    data.password_hash && typeof data.password == 'string') {
                createCredentials(data.email, data.password_hash, data.id, function(err) {
                    if(err) {
                        console.log("Error creating credentials. Error:", err);
                        next(err);
                    } else {
                        // Increment until all 5 operations have executed.
                        uploadCount++;
                        if (uploadCount == 5) {
                            next(null);
                        }
                    }
                });
            } else {
                // Increment until all 5 operations have executed.
                uploadCount++;
                if (uploadCount == 5) {
                    next(null);
                }
            }

            if (data.image) {
                // Check to make sure the passed in string is actually an image
                var b64String = data.image;
                var matches = b64String.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
                if (!matches || matches.length !== 3) {
                    next("Image data is invalid");
                } else {
                    var id = data.id;

                    // Assign the base64 string of the picture to a buffer
                    var imgBuffer = new Buffer(b64String.
                        replace(/^data:image\/\w+;base64,/, ""), 'base64');

                    var bucket = "cbu-aiche";
                    var key = "website/officers/" + id +
                        "/images/" + encodeURI(data.name.replace(" ", "-")) +
                        "-uncompressed.jpg";
                    var contentType = "image/jpeg";
                    var acl = "public-read";

                    // Upload the uncompressed picture to S3
                    uploadImg(bucket, key, contentType,
                            imgBuffer, acl, function(err) {
                        if (err) {
                            console.error("Unable to upload uncompressed image. " +
                                "Error JSON:", err);
                            next(err);
                        } else {

                            // Increment until all 4 operation have executed.
                            uploadCount++;
                            if (uploadCount == 5) {
                                next(null);
                            }
                        }
                    });

                    // Upload picture compressed to 400px and 100px
                    for (var compressedSize = 400; compressedSize > 0; compressedSize -= 300)
                            (function(compressedSize) {
                        key = "website/officers/" + id + "/images/" +
                            encodeURI(data.name.replace(" ", "-")) + "-" +
                            compressedSize + "px.jpg";

                        // Compress and upload the image
                        compressAndUploadImg(imgBuffer, compressedSize,
                                contentType, bucket, key, acl, function(err) {
                            if (err) {
                                console.log("Image " + compressedSize +
                                    "px compression/upload unsucessful. " +
                                    "Error JSON:", err);
                            } else {
                                console.log("Image " + compressedSize +
                                    "px compression/upload successful!");
                            }

                            // Increment until all 4 operations have executed.
                            uploadCount++;
                            if (uploadCount == 5) {
                                next(err ? err : null);
                            }
                        });
                    })(compressedSize);
                }
            } else {
                uploadCount += 4;
                if (uploadCount == 5) {
                    next(null);
                }
            }
        }
    ], function(err) {
        if (err) {
            console.error("Error: ", err);
            callback(err);
        } else {
            // Return all data but the image base64 string
            data = _.pick(data, "id", "name", "email", "position", "link", "order");
            callback(null, data);
        }
    });
};

// Hash the password and return the result
function hashPassword(data, callback) {
    console.log("hashing password");
    bcrypt.genSalt(10, function(err, salt) {
        bcrypt.hash(data.password, salt, function(err, hash) {
            if (err) {
                console.log("Error in password hashing. Error JSON: " +
                    JSON.stringify(err, null, 2));
                callback(err);
            } else {
                console.log("hashed password", hash);
                callback(null, hash);
            }
        });
    });
}

// Create an officer object in DynamoDB
function prepareOfficer(data, callback) {
    // Create an item to fill with data
    var item = {};

    // Fill the item with relevant data
    item.id = data.id;
    if (data.name) {
        item.name = data.name;
    }
    if (data.position) {
        item.position = data.position;
    }
    if (data.order) {
        item.order = data.order;
    }

    // Assign time to the nearest second
    item.created_at = Math.round(new Date().getTime() / 1000);
    item.updated_at = Math.round(new Date().getTime() / 1000);

    var pattern = new RegExp(/[-a-zA-Z0-9@:%_\+.~#?&//=]{2,256}\.[a-z]{2,4}\b(\/[-a-zA-Z0-9@:%_\+.~#?&//=]*)?/gi); // fragment locater

    if (data.link) {
        if (pattern.test(data.link)) {
            item.link = data.link;
            callback(null, item);
        } else {
            callback("Invalid URL provided");
        }
    }
}

function createCredentials(email, password_hash, id, callback) {
    // Specify what we want to add to DynamoDB
    var item = {
        email: email,
        password_hash: password_hash,
        id: id,
        created_at: Math.round(new Date().getTime() / 1000),
        updated_at: Math.round(new Date().getTime() / 1000)
    };

    // Set the parameters we need to pass to the statement.
    var params = {
        TableName: 'aiche_credentials',
        Item: item,
    };

    // Establish connection with DynamoDB
    var docClient = new aws.DynamoDB.DocumentClient();

    // Execute the statement
    docClient.put(params, function(err) {
        if (err) {
            callback(err);
        } else {
            callback(null);
        }
    });
}

function createOfficer(item, callback) {
    // Set the parameters we need to pass to the statement.
    var params = {
        TableName: 'aiche_officers',
        Item: item
    };

    // Establish connection with DynamoDB
    var docClient = new aws.DynamoDB.DocumentClient();

    // Execute the statement
    docClient.put(params, function(err) {
        if (err) {
            callback(err);
        } else {
            callback(null);
        }
    });
}

// Compress and image and upload it to S3.
function compressAndUploadImg(imgBuffer, compressedSize,
    contentType, bucket, key, acl, callback) {
    async.waterfall([
        function compress(next) {
            compressImg(imgBuffer, compressedSize, contentType,
                    function(err, newBuffer) {
                if(err) {
                    console.log("compression err", err);
                    next(err);
                } else {
                    next(null, newBuffer);
                }
            });
        },
        function upload(newBuffer, next) {
            uploadImg(bucket, key, contentType, imgBuffer, acl, function(err) {
                if(err) {
                    console.log("Error uploading compressed image:", err);
                    next(err);
                } else {
                    next(null);
                }
            });
        }
    ], function(err) {
        if (err) {
            callback(err);
        } else {
            callback(null);
        }
    });

}

// Compress an image from a base64 buffer and return the new buffer.
function compressImg(imgBuffer, compressedSize, contentType, callback) {
    // Get image size.
    gm(imgBuffer).size(function(err, size) {
        if (err) {
            callback(err);
        } else {
            // Infer the scaling factor to avoid stretching the image unnaturally.
            var scalingFactor = Math.min(
                compressedSize / size.width,
                compressedSize / size.height
            );

            var width = scalingFactor * size.width;
            var height = scalingFactor * size.height;

            // Transform the image buffer in memory.
            gm(imgBuffer).resize(width, height)
                .toBuffer(function(err, buffer) {
                    if (err) {
                        console.log("resize.toBuffer error:", err);
                        callback(err);
                    } else {
                        callback(null, buffer);
                    }
                });
        }
    });
}

// Take an image buffer and upload it to S3
function uploadImg(bucket, key, contentType, imgBuffer, acl, callback) {
    var s3 = new aws.S3({
        params: {
            Bucket: bucket
        }
    });

    // Prepare the parameters for upload
    var params = {
        Key: key,
        ContentEncoding: 'base64',
        ContentType: contentType,
        Body: imgBuffer,
        ACL: acl
    };

    // Upload the image to S3
    s3.upload(params, function(err, data) {
        if (err) {
            callback(err);
        } else {
            callback(null);
        }
    });
}
