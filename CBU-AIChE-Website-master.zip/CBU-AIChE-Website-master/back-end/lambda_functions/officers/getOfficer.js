console.log('Loading getOfficer function...');

/*
    This returns the id, name, position, and link of a single officer,
    given an id.

    Use AWS to communicate with DynamoDB.
*/

var AWS = require('aws-sdk');

// Establish a connection to DynamoDB
AWS.config.update({
    region: "us-east-1",
});

// Establish a connection with DynamoDB
var docClient = new AWS.DynamoDB.DocumentClient();


exports.handler = function(event, context, callback) {
    // Choose the table we want to scan and the attributes we want from it.
    var params = {
        TableName: "aiche_officers",
        AttributesToGet: [
            "id",
            "name",
            "position",
            "link",
        ],
        Key: {
            "id": event.id
        },
    };

    // Scan the officers
    docClient.get(params, function(err, returnData) {
        if (err) {
            console.error("Unable to scan the table. Error JSON:",
                JSON.stringify(err, null, 2));
            callback(err);
        } else {
            // Log the officer scanned
            console.log("Scan succeeded. JSON: ",
                JSON.stringify(returnData, null, 2));

            if(returnData.Item) {
                callback(null, returnData);
            } else {
                callback(404);
            }
        }
    });
};
