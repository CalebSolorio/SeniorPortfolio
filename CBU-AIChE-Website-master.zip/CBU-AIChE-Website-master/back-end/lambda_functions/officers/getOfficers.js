console.log('Loading getOfficers function...');

/*
    This returns  the id, name, position,
    and link of all the officers in the table.

    Use AWS to communicate with DynamoDB.
*/

var AWS = require('aws-sdk');

// Establish a connection to DynamoDB
AWS.config.update({
  region: "us-east-1",
});

// Establish a connection with DynamoDB
var docClient = new AWS.DynamoDB.DocumentClient();

// Choose the table we want to scan and the values we want from it.
// Keep variable outside handler scope for the onScan() method.
var params = {
    TableName: "aiche_officers",
    ProjectionExpression: "#id, #name, #pos, #link",
    ExpressionAttributeNames: {
        "#id": "id",
        "#name": "name",
        "#pos": "position",
        "#link": "link",
    },
};

exports.handler = function(event, context, callback) {
    // Scan the officers
    docClient.scan(params, function(err, data) {
      if(err) {
        callback(err);
      } else {
        onScan(null, data, function(err, returnData) {
          if(err) {
            callback(err);
          } else {
            if(returnData.Items.length > 0) {
              callback(null, returnData);
            } else {
              callback(404);
            }
          }
        });
      }
    });
};

function onScan(err, data, callback) {
    if (err) {
        console.error("Unable to scan the table. Error JSON:",
            JSON.stringify(err, null, 2));
    } else {
        // Log all officers scanned
        console.log("Scan succeeded. JSON: ",
            JSON.stringify(data, null, 2));

        // scan() can retrieve up to 1MB of data,
        // scan recursively if unscanned officers remain
        if (typeof data.LastEvaluatedKey != "undefined") {
            console.log("Scanning for more officers...");
            params.ExclusiveStartKey = data.LastEvaluatedKey;
            docClient.scan(params, onScan, function(err, newData) {
              if(err) {
                callback(err);
              } else {
                data.push(newData);
                callback(null, data);
              }
            });
        } else {
          callback(null, data);
        }
    }
}
