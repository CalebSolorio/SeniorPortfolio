console.log('Loading postSection function...');

/*
    Creates a section of a specified in DynamoDB 
    and uploads its respective photos to S3.
    
    Use AWS to communicate with DynamoDB,
    underscore for data parsing,
    uuid for generating unique identifiers,
    and fileType for exactly what you'd think.
*/ 

var AWS = require("aws-sdk");
var _ = require('underscore');
var uuid = require('node-uuid');
var fileType = require('file-type');
            
// Establish a connection AWS
AWS.config.update({
  region: "us-east-1",
//   endpoint: "http://localhost:8000"
});

exports.handler = function(event, context, callback) {
    var data = _.pick(event, "id", "body");
    
    if(!data.id) {
        callback(404, "No blog id provided");
        return;
    }
    
    async.waterfall([
        function prepare(next) {
            // Process all parts of the blog post's body.
            if(data.body) {
                var section = _.pick(data.body, "nextPoint", "type", "properties");
                prepareSection(section, 
                        function(err, returnData, errMsg) {
                    if(err) {
                        console.log("Error uploading image. Error JSON: ", 
                            JSON.stringify(err, null, 2));
                        next(err);
                    } else if(!returnData) {
                        console.log("Invalid, JSON:", 
                            JSON.stringify(errMsg, null, 2));
                        next(errMsg);
                    } else {
                        data.body = returnData;
                        
                        next(null, data);
                    }
                });
            } else {
                // Send an error message
                next("No section info provided");
            }
        }, function create(data, next) {
            // Generate a unique id for the section
            data.body.section_id = uuid.v1();
            
            var count = 0;  // Will increment until all updates have completed
            
            // Update DynamoDB. Callback method if all updates have executed.
            updateDynamoDB(data, function(err, returnData) {
                if(err) {
                    console.log("Failed to update DynamoDB. Error JSON: ",
                        JSON.stringify(err, null, 2));
                    next(err);
                } else {
                    // Save the newly created data to send back.
                    data = returnData;
                    
                    count++;
                    if(count == 2) {
                        next(null);
                    }
                }
            });
            
            // Update S3. Callback method if all updates have executed.
            updateS3(data, function(err) {
                if(err) {
                    console.log("Failed to update DynamoDB. Error JSON: ",
                        JSON.stringify(err, null, 2));
                    next(err);
                } else {
                    count++;
                    if(count == 2) {
                        next(null);
                    }
                }
            });
        }    
    ], function(err) {
        if(err) {
            callback(err);
        } else {
            callback(null, data);
        }
    });
    
};

// Prepares a section for insertion into DynamoDB and S3
function prepareSection(data, callback) {
    switch (data.type){
        case "bannerImageUpload":
        case "imageUpload":
            imgUpld(data, function(err, returnData, errMsg) {
                callback(err, returnData, errMsg);
            });
            break;
        case "bannerImageLink":
        case "imageLink":
            imgLnk(data, function(err, returnData, errMsg) {
                callback(err, returnData, errMsg);    
            });
            break;
        case "bannerVideoLink":
        case "videoLink":
            vidLnk(data, function(err, returnData, errMsg) {
                callback(err, returnData, errMsg);    
            });
            break;
        case "titleAuthor":
            titleAuthor(data, function(err, returnData, errMsg) {
                callback(err, returnData, errMsg);    
            });
            break;
        case "blockTitleAuthor": 
            titleAuthorColor(data, function(err, returnData, errMsg) {
                callback(err, returnData, errMsg);    
            });
            break;
        case "author":
            author(data, function(err, returnData, errMsg) {
                callback(err, returnData, errMsg);    
            });
            break;
        case "text":
            text(data, function(err, returnData, errMsg) {
                callback(err, returnData, errMsg);    
            });
            break;
        case "bannerTextImageUpload":
        case "textLeftImageUploadRight":
        case "imageUploadLeftTextRight":
            txtImgUpld(data, function(err, returnData, errMsg) {
                callback(err, returnData, errMsg);    
            });
        case "bannerTextImageLink":
        case "textLeftImageLinkRight":
        case "imageLinkLeftTextRight":
            txtImgLnk(data, function(err, returnData, errMsg) {
                callback(err, returnData, errMsg);    
            });
            break;
        case "gallery":
            images(data, function(err, returnData, errMsg) {
                callback(err, returnData, errMsg);    
            });
            break;
        default:
            callback(null, false, null, null);
    }
}

// Updates DynamoDB with a new section's information
function updateDynamoDB(data, callback) {
    var dataPoint = data.body;
    var returnData;
    
    // Establish variables used in both async methods
    var table = "aiche_blog_sections";
    var returnValues = "UPDATED_NEW";  
    
    // Establish connection with DynamoDB
    var docClient = new AWS.DynamoDB.DocumentClient();
    
    async.waterfall([
        function insertSection(next) {
            // Define the format/values of the section
            var section = {
                blog_id: data.id,
                section_id: dataPoint.sectionId,
                type: dataPoint.type,
                next_point: dataPoint.nextPoint,
                body: [],
                created_at: Math.round(new Date().getTime()/1000),
                updated_at: Math.round(new Date().getTime()/1000)
                
            };
            
            for(var i = 0; i < dataPoint.properties.length; i++) {
                // Remove the image b64 data, updateS3() will handle that
                delete dataPoint.properties[i].image;
                
                // Update the section to be added.
                section.body[i] = dataPoint.properties[i];
            }
                
            // Prepare the statement to add a new section
            var params = {
                TableName: table,
                Item: section,
                ReturnValues: returnValues
            };
                    
            // Execute the statement
            docClient.put(params, function(err, newData) {
                if (err) {
                    console.error("Unable to add new section. Error JSON:", 
                        JSON.stringify(err, null, 2));
                    next(err);
                } else {
                    console.log("Added section:", JSON.stringify(newData, null, 2));
                    returnData = newData;
                    next(null);
                }
            });
        }, function updatePointers(next) {
            // Set 
            var key = { 
                "blog_id": data.id,
                "next_point": dataPoint.nextPoint 
            };
            var updateExpression = "SET next_point = :s_id";
            var conditionExpression = "section_id <> :s_id"; // True if id is not equal to our new section's id
            var expressionAttributeValues = {
                ":s_id": dataPoint.sectionId
            };
            
            // Prepare the statement to change the pushed section's pointer
            // to point at our new section.
            var params = {
                TableName: table,
                Key: key,
                UpdateExpression: updateExpression,
                ConditionExpression: conditionExpression,
                ExpressionAttributeValues: expressionAttributeValues
            };
            
            // Execute the statement
            docClient.update(params, function(err) {
                if (err) {
                    console.error("Unable to adjust pointers. Error JSON:", 
                        JSON.stringify(err, null, 2));
                    next(err);
                } else {
                    console.log("Pointers adjusted");
                    next(null);
                }
            });
        }
    ], function(err) {
        if(err) {
            callback(err, null);
        } else {
            callback(null, returnData);
        }
    });
}

// Updates S3 with the apporpriate media files
function updateS3(data, callback) {
    // Create variables to be used later
    var dataPoint = data.body;
    var image;
    var contentType;
    
    // Create the variables necessary to upload
    var bucket = "cbu-aiche";
    var keyStart = "/website/images/blog-posts/" 
        + data.id + "/" + dataPoint.section_id + "/";
    var key;
    var acl = "public-read";
    
    // For ensuring we execute all uploads
    var count = 0;
    
    for(var i = 0; i < dataPoint.properties.length; i++) {
        // Prepare the variables needed for the upload
        key = keyStart + dataPoint.properties[i].image_id;
        image = dataPoint.properties[i].image;
        contentType = dataPoint.properties[i].content_type;
        
        // Execute the upload
        uploadImgS3(bucket, key, contentType, 
                image, acl, function(err) {
            if(err) {
                callback(err);
            } else {
                count++;
                if(count == dataPoint.properties.length) {
                    callback(null);   
                }
            }
        });
    }
}

// Take an image buffer and upload it to S3
function uploadImgS3(bucket, key, contentType, imgBuffer, acl, callback) {
    var S3 = new AWS.S3({
        params: {
            Bucket: bucket
        }
    });
    
    // Prepare the parameters for upload
    var params = {
        Key: key,
        ContentType: contentType,
        Body: imgBuffer,
        ACL: acl
    };
    
    // Upload the image to S3
    S3.upload(params, function(err, data) {
        if (err) {
            callback(err);
        } else {
            callback(null);
        }
    });
}

// Validate base64 string integrity
function validateImageUpload(imgString, callback) {
    // Check to make sure the passed in string is actually an image
	var matches = imgString.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
	if(matches.length !== 3) {
	    callback(null, false);
	    return;
	}
	
	var imgBuffer = Buffer.from(imgString, 'base64');
	
	// Check the file type and return the approriate content metadata.
    var imgType = fileType(imgBuffer);
    if(imgType.ext == 'avi' || imgType.ext == 'gif'|| imgType.ext == 'jpg' 
            || imgType.ext == 'mkv' || imgType.ext == 'mp4' 
            || imgType.ext == 'ogg' || imgType.ext == 'png'  
            ||imgType.ext == 'vob' || imgType == 'webm'
            || imgType.ext == 'wmv') {
                
        callback(null, imgType);
        
    } else {
        callback(null, false);
    }
}

// Validate image upload but keep track of index.
function validateGalleryImageUpload(imgString, index, callback) {
    validateImageUpload(imgString, function(err, contentType) {
        callback(err, contentType, index);
    });
}

// Validate image upload but keep track of index.
function validateGalleryImageLink(imgString, index, callback) {
    validateImageLink(imgString, function(err, contentType) {
        callback(err, contentType, index);
    });
}

// Check if address is valid.
// Not going to verify website domains, too many possibilities.
function validateImageLink(link) {
    // Oh God, I'm so sorry...
    var pattern = "/^(https?|ftp):\/\/([a-zA-Z0-9.-]+(:[a-zA-Z0-9.&%$-]+)*@)*"
        + "((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]?)(\.(25[0-5]|2[0-4][0-9]"
        + "|1[0-9]{2}|[1-9]?[0-9])){3}|([a-zA-Z0-9-]+\.)*[a-zA-Z0-9-]+\."
        + "(com|edu|gov|int|mil|net|org|biz|arpa|info|name|pro|aero|coop|museum|"
        + "[a-zA-Z]{2}))(:[0-9]+)*(\/($|[a-zA-Z0-9.,?'\\+&%$#=~_-]+))*$/"; 
    
    var urlRegex = new RegExp(pattern);
    return urlRegex.test(link);
}

// Check if address is from Youtube or Vimeo
function validateVideoLink(link, callback) {
    var domains = ["youtube", "vimeo"];
    
    for(var i = 0; i < domains.length; i++) {
        var pattern = "/^(?:https?:\/\/)?(?:www\.)?" + domains[i] 
            + "\.com\/watch\?(?=.*v=((\w|-){11}))(?:\S+)?$/";
        var urlRegex = new RegExp(pattern);
        
        if (urlRegex.match(link)) { 
            return true; 
        }
    }
    
    return false;

}

// Validates and formats data for sections with image uploads
function imgUpld(data, callback) {
    var type = data.type;
    var nextPoint = data.nextPoint;
    var image = data.properties.image;
    
    // Check that order exists and that it is a number, 
    // then validate the image data
    if(nextPoint && image) {
        validateImageUpload(image, function(err, contentType, errMsg) {
            if(err) {
                callback(err); 
            } else {
                if(contentType) {
                    // Create a unique id for the image
                    var imageId = uuid.v1();
                    
                    var returnData = {
                        type: type,
                        nextPoint: nextPoint,
                        properties: {
                            image: image,
                            image_id: imageId,
                            content_type: contentType
                        }
                    };
                    
                    // Caption is optional
                    if(data.properties.caption) {
                        returnData.properties.caption =
                            data.properties.caption;
                    }
                    
                    callback(null, returnData, null);
                } else {
                    callback(null, false, "Not a valid image.");
                }    
            }
        });
    } else {
        callback(null, false, "Must provide both order and image.");
    }
}

// Validates and formats data for sections with image links
function imgLnk(data, callback) {
    var type = data.type;
    var nextPoint = data.nextPoint;
    var image = data.properties.image;
    
    if(nextPoint && image) {
        var valid = validateImageLink(image);
        
        if(valid) {
            var returnData = {
                type: type,
                nextPoint: nextPoint,
                properties: {
                    image: image
                }
            };
            
            // Caption is optional
            if(data.properties.caption) {
                returnData.properties.caption =
                    data.properties.caption;
            }
            
            callback(null, returnData, null);
        } else {
            callback(null, false, "Not a valid image URL.");
        }
    } else {
        callback(null, false, "Must provide both order and image.");
    }
}

// Validates and formats data for sections with video links
function vidLnk(data, callback) {
    var type = data.type;
    var nextPoint = data.nextPoint;
    var video = data.properties.video;
    
    if(nextPoint && video) {
        var valid = validateVideoLink(video);
        
        if(valid) {
            var returnData = {
                type: type,
                nextPoint: nextPoint,
                properties: {
                    video: video
                }
            };
            
            callback(null, returnData, null);
        } else {
            callback(null, false, "Not a valid video URL.");
        }
    } else {
        callback(null, false, "Must provide order and URL.");
    }
}

// Validates and formats data for sections with text and image upload
function txtImgUpld(data, callback) {
    var type = data.type;
    var nextPoint = data.nextPoint;
    var text = data.properties.text;
    var image = data.properties.image;
    
    if(nextPoint && text && image) {
        validateImageUpload(image, function(err, contentType, errMsg) {
            if(err) {
                callback(err); 
            } else {
                if(contentType) {
                    var imageId = uuid.v1();
                    
                    var returnData = {
                        type: type,
                        nextPoint: nextPoint,
                        properties: {
                            image: image,
                            image_id: imageId,
                            content_type: contentType
                        }
                    };
                    
                    // Caption is optional
                    if(data.properties.caption) {
                        returnData.properties.caption =
                            data.properties.caption;
                    }
                    
                    callback(null, returnData, null);
                } else {
                    callback(null, false, "Not a valid image.");
                }    
            }
        });
    } else {
        callback(null, false, "Must provide order, image and text.");
    }
}

// Validates and formats data for sections with text and image link
function txtImgLnk(data, callback) {
    var type = data.type;
    var nextPoint = data.nextPoint;
    var text = data.properties.text;
    var image = data.properties.image;
    
    if(nextPoint && text && image) {
        var valid = validateImageLink(image);
        
        if(valid) {
            var returnData = {
                type: type,
                nextPoint: nextPoint,
                properties: {
                    text: text,
                    image: image
                }
            };
            
            // Caption is optional
            if(data.properties.caption) {
                returnData.properties.caption =
                    data.properties.caption;
            }
            
            callback(null, returnData, null);
        } else {
            callback(null, false, "Not a valid image URL.");
        }
    } else {
        callback(null, false, "Need to provide order, text, and image.");
    }
}

/* NO ORDER FROM HERE ON OUT */

// Validates and formats data for sections with author
function author(data, callback) {
    var authorId = data.properties.authorId;
    
    if(authorId) {
        text(data, function(err, returnData, errMsg) {
            if(err) {
                callback(err);
            } else if (!returnData) {
                callback(null, returnData, errMsg);    
            } else {
                returnData.properties.author_id = authorId;
                delete returnData.properties.text;
                
                callback(null, returnData, errMsg);
            }    
        });
    } else {
        callback(null, false, "Author id must be provided.");
    }
}

// Validates and formats data for sections with title and author
function titleAuthor(data, callback) {
    var type = data.type;
    var nextPoint = data.nextPoint;
    var title = data.properties.title;
    var authorId = data.properties.authorId;
    
    if(title && authorId) {
        var returnData = {
            type: type,
            nextPoint: nextPoint,
            properties: {
                title: title,
                author_id: authorId
            }
        };   
        
        callback(null, returnData, null);
    } else {
        callback(null, false, "Title and author id must be provided.");
    }
}

// Validates and formats data for sections with title, author, and color
function titleAuthorColor(data, callback) {
    var color = data.properties.color;
    
    if(color) {
        titleAuthor(data, function(err, returnData, errMsg) {
            if(err) {
                callback(err);
            } else if (!returnData) {
                callback(err, returnData, errMsg);    
            } else {
                var hexRegex = new RegExp("^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$");
                if(hexRegex.match(color)) {
                    returnData.properties.color = color;
                } else {
                    callback(null, false, "Invalid hexidecimal color.");
                }
            }
        });
    } else {
        callback(null, false, "Hexidecimal color not provided.");
    }
}

// Validates and formats data for sections with text
function text(data, callback) {
    var type = data.type;
    var nextPoint = data.nextPoint;
    var order = data.order;
    var text = data.properties.text;
    
    if(order && text) {
        var returnData = {
            type: type,
            nextPoint: nextPoint,
            order: order,
            properties: {
                text: text
            }
        };  
        
        callback(null, returnData, null);
    } else {
        callback(null, false, "Text and order must be provided.");
    }
}

//THIS AIN'T GONNA WORK
// Validates and formats data for sections with multiple images
function images(data, callback) {
    // Transfer relevant values from data to returnData
    var returnData = _.pick(data, "type", "nextPoint", "properties");
    var images = returnData.properties.images;
    
    if(images) {
        // imgCount increments until all instructions have exectuted
        var imgCount = 0;
        for(var i = 0; i < images.length; i++) {
            // Pick out the values we cre about
            images[i] = _.pick(images[i], "id", "src", "type", "nextPoint");
            
            var imgString = images[i].src.string;
            var imgType = images[i].type;
            
            // Check that the required variables exist
            if(imgString && imgType && images[i].order) {
                // Check for valid imgType
                if(imgType == "upload") {
                    // Validate upload.
                    validateGalleryImageUpload(imgString, i, 
                            function(err, contentType, index) {
                        if(err) {
                            callback(err);
                        } else if(!contentType) {
                            callback(null, false, "Image not in valid format");
                        } else {
                            // If no id exists for an image, generate one
                            if(!images[index].id) {
                                images[index].id = uuid.v1();
                            }
                            
                            // Assign proper content meta data.
                            images[index].src.type = contentType;
                            
                            // Trim the fat on imgSrc (caption is optional)
                            images[index].src = _.pick(images[index].src,
                                "imgId", "imgString", "contentType", "caption");
                                
                            imgCount++;
                            if(imgCount == images.length) {
                                // Assign images to data and return that.
                                returnData.properties.images = images;
                                callback(null, returnData, null);
                            }
                        }
                    });
                } else if (imgType == "link") {
                    // Validate upload.
                    validateGalleryImageLink(imgString, i, 
                            function(err, contentType, index) {
                        if(err) {
                            callback(err);
                        } else if(!contentType) {
                            callback(null, false, "Image not in valid format");
                        } else {
                            // Assign proper content meta data.
                            images[index].imgSrc.contentType = contentType;
                            
                            // Trim the fat on imgSrc
                            images[index].imgSrc = _.pick(images[index].imgSrc,
                                "imgId", "imgString", "contentType");
                                
                            imgCount++;
                            if(imgCount == images.length) {
                                // Assign images to data and return that.
                                returnData.properties.images = images;
                                callback(null, returnData, null);
                            }
                        }
                    });
                } else {
                    callback(null, false, "Image type not valid.");
                }    
            } else {
                callback(null, false, "Must provide image, type, and order.");
            }
        }
        
        callback(null, returnData, null);
    } else {
        callback(null, false, "Images must be provided.");
    }
}