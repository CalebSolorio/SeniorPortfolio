console.log('Loading deleteSection function...');

/*
    This removes a specified blog section's data 
    and images from DynamoDB.
    
    Use AWS to communicate with DynamoDB.
*/

var AWS = require('aws-sdk');

// Establish a connection to AWS
AWS.config.update({
  region: "us-east-1",
//   endpoint: "http://localhost:8000"
});
        
exports.handler = function(event, context, callback) {
    // Establish counter to ensure all execution takes place before callback
    var count = 0;
    
    // Establish variables to be referenced later
    var table = "blog_sections";
    var blogId = event.blogId;
    var sectionId = event.sectionId;
    
    // Delete section info from DynamoDB
    deleteSectionFromTable(table, sectionId, function(err) {
        if(err) {
            callback(err);
        } else {
            count++;
            if(count == 2) {
                callback(null, { status: 200 });    
            }
        }
    });
    
    var bucket = "cbu-aiche";
    var key = "/website/images/blog-posts/" + blogId + "/" + sectionId;
    
    deleteSectionFromS3(bucket, key, function(err) {
        if(err) {
            callback(err);
        } else {
            count++;
            if(count == 2) {
                callback(null, { status: 200 });    
            }
        }
    });
};

function deleteSectionFromTable(table, id, callback) {
    // Establish a connection with DynamoDB
    var docClient = new AWS.DynamoDB.DocumentClient();
    
    // Prepare the statement.
	var params = {
        TableName: table,
        Key:{
            "section_id": id,
        }
    };
    
    // Execute the statement
    docClient.delete(params, function(err, data, callback) {
        if (err) {
            console.error("Unable to delete blog from DynamoDB. Error JSON:", 
                JSON.stringify(err, null, 2));
            callback(err);
        } else {
            console.log("Duccessfully deleted blog from DynamoDB! JSON: ", 
                JSON.stringify(data, null, 2));
            callback(null);
        }
    });
    
}

function deleteSectionFromS3(bucket, key, callback) {
    // Establish connection to S3
    var S3 = new AWS.S3({
        params: {
            Bucket: bucket
        }
    });
    
    // Prepare the delete statement
    var params = {
        Delete: {
            Objects: [
                 { Key: key },
            ]
        }
    };
    
    // Delete the officer's object from S3
    S3.deleteObject(params, function(err, data, callback) {
        if (err) {
            console.error("Unable to delete section data from S3. Error JSON:", 
                JSON.stringify(err, null, 2));
            callback(err);
        } else {
            console.log("Section data successfully deleted from S3! JSON: ",
                JSON.stringify(data, null, 2));
            callback(null);
        }
    });
    
}
