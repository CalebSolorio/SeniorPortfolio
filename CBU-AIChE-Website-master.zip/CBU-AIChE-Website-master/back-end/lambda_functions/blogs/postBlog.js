console.log('Loading postOfficer function...');

/*
    Creates a new blog post in DynamoDb.
    
    Use AWS to communicate with DynamoDB,
    jwt for json web token verification, 
    cryptojs for decrypting, and
    uuid for generating unique identifiers.
*/ 

var AWS = require("aws-sdk");
var jwt = require("jsonwebtoken");
var cryptojs = require('crypto-js');
var uuid = require('node-uuid');
            
// Establish a connection to AWS
AWS.config.update({
  region: "us-east-1",
//   endpoint: "http://localhost:8000"
});

exports.handler = function(event, context, callback) {
    async.waterfall([
        function getAuthorId(next) {
            if(event.token) {
                var jwtKey = "XvCQtU^ZSfr5Tr#y";
                var cryptojsKey = "eR8A3wSW4mM7u%2@";
                
                jwt.verify(event.token, jwtKey, function(err, decoded) {
                    if(err) {
                        console.log("Error occured while verifying token :(");
                        next(err, null);
                    } else {
                        var decryptedData = 
                            cryptojs.AES.decrypt(decoded, cryptojsKey);
                        next(null, decryptedData.id);
                    }    
                });
            } else {
                console.log("No id provided by client");
                next(null, null);
            }
        }, function create(author_id, next) {
            var table = "blog_posts";
            var item = {};
            
            // Generate a uuid
            item.blog_id = uuid.v1();
            
            // Set defaults
            item.title = "New Blog Post";
            item.draft = true;
            
            // Set author id
            if(author_id) {
                item.author_id = author_id;
            }
            
            // Assign time to the nearest second
            item.created_at = Math.round(new Date().getTime()/1000);
            item.updated_at = Math.round(new Date().getTime()/1000);
            
            // Set the parameters we need to pass to the statement.
            var params = {
                TableName: table,
                Item: item
            };
            
            // Establish connection to DynamoDB
            var docClient = new AWS.DynamoDB.DocumentClient();
            
            // Execute the statement
            docClient.put(params, function(err, newData, next){
                if (err) {
                    console.error("Unable to add officer. Error JSON:", 
                        JSON.stringify(err, null, 2));
                    
                    next(err);
                } else {
                    console.log("Added officer:", JSON.stringify(newData, null, 2));
                    next(null);
                }
            });
        }    
    ], function(err) {
        if (err) {
            callback(err);
        } else {
            callback(null, { status: 200 });
        }
    });
};