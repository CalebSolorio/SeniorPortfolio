console.log('Loading postOfficer function...');

/*
    Updates a blog post in DynamoDB and its photos in S3.
    
    Use AWS to communicate with DynamoDB,
    underscore for data parsing,
    uuid for generating unique identifiers,
    fileType for exactly what you'd think,
    and GraphicsMagick image manupilation.
*/ 

var AWS = require("aws-sdk");
var _ = require('underscore');
var uuid = require('node-uuid');
var fileType = require('file-type');
var gm = require('gm')
            .subClass({ imageMagick: true });
            
// Establish a connection AWS
AWS.config.update({
  region: "us-east-1",
//   endpoint: "http://localhost:8000"
});

exports.handler = function(event, context, callback) {
    var data = _.pick(event, "id", "title", "author_id", "draft", "body");
    
    if(!data.id) {
        callback(404, "No id provided");
        return;
    }
    
    async.waterfall([
        function prepare(next) {
            // Start with the basics of our update statement
            var table = "blog_posts";
            var key = { "id": data.id };
            var updateExpression = "";
            var expressionAttributeValues = {};
            var returnValues = "UPDATED_NEW";
            
            // Gather the new values and prepare the statement.
            if(data.title) {
                updateExpression += "set title = :t";
                expressionAttributeValues[":t"] = data.title;
            }
            
            if(data.author_id) { 
                if(updateExpression.length > 0) {
                    updateExpression += ", author_id = :a_i";
                } else {
                    updateExpression += "set author_id = :a_i";
                }
                expressionAttributeValues[":a_i"] = data.author_id;
            }
            
            if(data.draft && typeof data.draft == "boolean") { 
                if(updateExpression.length > 0) {
                    updateExpression += ", draft = :d";
                } else {
                    updateExpression += "set draft = :d";
                }
                expressionAttributeValues[":d"] = data.draft;
            }
            
            if(updateExpression.length > 0) {
                updateExpression += ", updated_at = :u";
            } else {
                updateExpression += "set updated_at = :u";
            }
            expressionAttributeValues[":u"] = 
                Math.round(new Date().getTime()/1000);
            
            // Process all parts of the blog post's body.
            if(data.body.length > 0) {
                var count = 0;
                for(var i = 0; i < data.body.length; i++) {
                    var section = _.pick(data.body[i], "type", "properties");
                    prepareSection(section, i,
                            function(err, returnData, index, errMsg) {
                        if(err) {
                            console.log("Error uploading image. Error JSON: ", 
                                JSON.stringify(err, null, 2));
                            next(err);
                        } else if(!returnData) {
                            console.log("Invalid, JSON:", 
                                JSON.stringify(errMsg, null, 2));
                            next(errMsg);
                        } else {
                            
                            // If updating existing section, add section id.
                            if(data.body[index].section_id) {
                                returnData.section_id = data.section_id;
                            } else {
                                returnData.section_id = uuid.v1();
                            }

                            data.body[index] = returnData;
                        }
                        
                        // Once preparation is complete, assemble params
                        count++;
                        if(count == data.body.length) {
                            // Add body to our update expression
                            if(updateExpression.length > 0) {
                                updateExpression += ", body = :b";
                            } else {
                                updateExpression += "set body = :b";
                            }
                            expressionAttributeValues[":b"] = data.body;
                            
                            // Prepare the update statement
                            var params = {
                                TableName: table,
                                Key: key,
                                UpdateExpression: updateExpression,
                                ReturnValues: returnValues
                            };
                            
                            next(null, params);
                        }
                    });
                }
            } else {
                // Prepare the update statement
                var params = {
                    TableName: table,
                    Key: key,
                    UpdateExpression: updateExpression,
                    ReturnValues: returnValues
                };
                
                next(null, params);
            }
        }, function create(params, next) {
            var returnData;    // This will store the data we return to the client
            var count = 0;  // Will increment until all updates have completed
            
            // Update DynamoDB. Callback method if all updates have executed.
            updateDynamoDB(params, function(err, newData) {
                if(err) {
                    console.log("Failed to update DynamoDB. Error JSON: ",
                        JSON.stringify(err, null, 2));
                    next(err);
                } else {
                    returnData = newData;
                    count++;
                    if(count == 2) {
                        next(null, returnData);
                    }
                }
            });
            
            // Update S3. Callback method if all updates have executed.
            updateS3(params, function(err) {
                if(err) {
                    console.log("Failed to update DynamoDB. Error JSON: ",
                        JSON.stringify(err, null, 2));
                    next(err);
                } else {
                    count++;
                    if(count == 2) {
                        next(null, returnData);
                    }
                }
            });
        }    
    ], function(err, returnData) {
        if(err) {
            callback(err);
        } else {
            callback(null, returnData);
        }
    });
    
};

function prepareSection(data, index, callback) {
    switch (data.type){
        case "bannerImageUpload":
        case "imageUpload":
            imgUpld(data, function(err, returnData, errMsg) {
                callback(err, returnData, index, errMsg);
            });
            break;
        case "bannerImageLink":
        case "imageLink":
            imgLnk(data, function(err, returnData, errMsg) {
                callback(err, returnData, index, errMsg);    
            });
            break;
        case "bannerVideoLink":
        case "videoLink":
            vidLnk(data, function(err, returnData, errMsg) {
                callback(err, returnData, index, errMsg);    
            });
            break;
        case "titleAuthor":
            titleAuthor(data, function(err, returnData, errMsg) {
                callback(err, returnData, index, errMsg);    
            });
            break;
        case "blockTitleAuthor": 
            titleAuthorColor(data, function(err, returnData, errMsg) {
                callback(err, returnData, index, errMsg);    
            });
            break;
        case "author":
            author(data, function(err, returnData, errMsg) {
                callback(err, returnData, index, errMsg);    
            });
            break;
        case "text":
            text(data, function(err, returnData, errMsg) {
                callback(err, returnData, index, errMsg);    
            });
            break;
        case "bannerTextImageUpload":
        case "textLeftImageUploadRight":
        case "imageUploadLeftTextRight":
            txtImgUpld(data, function(err, returnData, errMsg) {
                callback(err, returnData, index, errMsg);    
            });
        case "bannerTextImageLink":
        case "textLeftImageLinkRight":
        case "imageLinkLeftTextRight":
            txtImgLnk(data, function(err, returnData, errMsg) {
                callback(err, returnData, index, errMsg);    
            });
            break;
        case "gallery":
            images(data, function(err, returnData, errMsg) {
                callback(err, returnData, index, errMsg);    
            });
            break;
        default:
            callback(null, false, null, null);
    }
}

// Validate base64 string integrity
function validateImageUpload(imgString, callback) {
    // Check to make sure the passed in string is actually an image
	var matches = imgString.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
	if(matches.length !== 3) {
	    callback(null, false);
	    return;
	}
	
	var imgBuffer = Buffer.from(imgString, 'base64');
	
	// Check the file type and return the approriate content metadata.
    var imgType = fileType(imgBuffer);
    if(imgType.ext == 'avi' || imgType.ext == 'gif'|| imgType.ext == 'jpg' 
            || imgType.ext == 'mkv' || imgType.ext == 'mp4' 
            || imgType.ext == 'ogg' || imgType.ext == 'png'  
            ||imgType.ext == 'vob' || imgType == 'webm'
            || imgType.ext == 'wmv') {
                
        callback(null, imgType);
        
    } else {
        callback(null, false);
    }
}

// Validate image upload but keep track of index.
function validateGalleryImageUpload(imgString, index, callback) {
    validateImageUpload(imgString, function(err, contentType) {
        callback(err, contentType, index);
    });
}

// Validate image upload but keep track of index.
function validateGalleryImageLink(imgString, index, callback) {
    validateImageLink(imgString, function(err, contentType) {
        callback(err, contentType, index);
    });
}

// Check if address is valid.
// Not going to verify website domains, too many possibilities.
function validateImageLink(link) {
    // Oh God, I'm so sorry...
    var pattern = "/^(https?|ftp):\/\/([a-zA-Z0-9.-]+(:[a-zA-Z0-9.&%$-]+)*@)*"
        + "((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]?)(\.(25[0-5]|2[0-4][0-9]"
        + "|1[0-9]{2}|[1-9]?[0-9])){3}|([a-zA-Z0-9-]+\.)*[a-zA-Z0-9-]+\."
        + "(com|edu|gov|int|mil|net|org|biz|arpa|info|name|pro|aero|coop|museum|"
        + "[a-zA-Z]{2}))(:[0-9]+)*(\/($|[a-zA-Z0-9.,?'\\+&%$#=~_-]+))*$/"; 
    
    var urlRegex = new RegExp(pattern);
    return urlRegex.test(link);
}

// Check if address is from Youtube or Vimeo
function validateVideoLink(link, callback) {
    var domains = ["youtube", "vimeo"];
    
    for(var i = 0; i < domains.length; i++) {
        var pattern = "/^(?:https?:\/\/)?(?:www\.)?" + domains[i] 
            + "\.com\/watch\?(?=.*v=((\w|-){11}))(?:\S+)?$/";
        var urlRegex = new RegExp(pattern);
        
        if (urlRegex.match(link)) { 
            return true; 
        }
    }
    
    return false;

}

// Validates and formats data for sections with image uploads
function imgUpld(data, callback) {
    var type = data.type;
    var order = data.order;
    var image = data.properties.image;
    
    if(order && image) {
        validateImageUpload(image, function(err, contentType, errMsg) {
            if(err) {
                callback(err); 
            } else {
                if(contentType) {
                    var imageId = uuid.v1();
                    
                    if(!imageId) {
                        
                    }
                    
                    var returnData = {
                        type: type,
                        order: order,
                        properties: {
                            image: image,
                            image_id: imageId,
                            content_type: contentType
                        }
                    };
                    
                    // Caption is optional
                    if(data.properties.caption) {
                        returnData.properties.caption =
                            data.properties.caption;
                    }
                    
                    callback(null, returnData, null);
                } else {
                    callback(null, false, "Not a valid image.");
                }    
            }
        });
    } else {
        callback(null, false, "Must provide both order and image.");
    }
}

// Validates and formats data for sections with image links
function imgLnk(data, callback) {
    var type = data.type;
    var order = data.order;
    var image = data.properties.image;
    
    if(order && image) {
        var valid = validateImageLink(image);
        
        if(valid) {
            var returnData = {
                type: type,
                order: order,
                properties: {
                    image: image
                }
            };
            
            // Caption is optional
            if(data.properties.caption) {
                returnData.properties.caption =
                    data.properties.caption;
            }
            
            callback(null, returnData, null);
        } else {
            callback(null, false, "Not a valid image URL.");
        }
    } else {
        callback(null, false, "Must provide both order and image.");
    }
}

// Validates and formats data for sections with video links
function vidLnk(data, callback) {
    var type = data.type;
    var order = data.order;
    var video = data.properties.video;
    
    if(order && video) {
        var valid = validateVideoLink(video);
        
        if(valid) {
            var returnData = {
                type: type,
                order: order,
                properties: {
                    video: video
                }
            };
            
            callback(null, returnData, null);
        } else {
            callback(null, false, "Not a valid video URL.");
        }
    } else {
        callback(null, false, "Must provide order and URL.");
    }
}

// Validates and formats data for sections with text and image upload
function txtImgUpld(data, callback) {
    var type = data.type;
    var order = data.order;
    var text = data.properties.text;
    var image = data.properties.image;
    
    if(order && text && image) {
        validateImageUpload(image, function(err, contentType, errMsg) {
            if(err) {
                callback(err); 
            } else {
                if(contentType) {
                    var imageId = uuid.v1();
                    
                    var returnData = {
                        type: type,
                        order: order,
                        properties: {
                            image: image,
                            image_id: imageId,
                            content_type: contentType
                        }
                    };
                    
                    // Caption is optional
                    if(data.properties.caption) {
                        returnData.properties.caption =
                            data.properties.caption;
                    }
                    
                    callback(null, returnData, null);
                } else {
                    callback(null, false, "Not a valid image.");
                }    
            }
        });
    } else {
        callback(null, false, "Must provide order, image and text.");
    }
}

// Validates and formats data for sections with text and image link
function txtImgLnk(data, callback) {
    var type = data.type;
    var order = data.order;
    var text = data.properties.text;
    var image = data.properties.image;
    
    if(order && text && image) {
        var valid = validateImageLink(image);
        
        if(valid) {
            var returnData = {
                type: type,
                order: order,
                properties: {
                    text: text,
                    image: image
                }
            };
            
            // Caption is optional
            if(data.properties.caption) {
                returnData.properties.caption =
                    data.properties.caption;
            }
            
            callback(null, returnData, null);
        } else {
            callback(null, false, "Not a valid image URL.");
        }
    } else {
        callback(null, false, "Need to provide order, text, and image.");
    }
}

// Validates and formats data for sections with author
function author(data, callback) {
    var authorId = data.properties.authorId;
    
    if(authorId) {
        text(data, function(err, returnData, errMsg) {
            if(err) {
                callback(err);
            } else if (!returnData) {
                callback(null, returnData, errMsg);    
            } else {
                returnData.properties.author_id = authorId;
                delete returnData.properties.text;
                
                callback(null, returnData, errMsg);
            }    
        });
    } else {
        callback(null, false, "Author id must be provided.");
    }
}

// Validates and formats data for sections with title and author
function titleAuthor(data, callback) {
    var type = data.type;
    var title = data.properties.title;
    var authorId = data.properties.authorId;
    
    if(title && authorId) {
        var returnData = {
            type: type,
            properties: {
                title: title,
                author_id: authorId
            }
        };   
        
        callback(null, returnData, null);
    } else {
        callback(null, false, "Title and author id must be provided.");
    }
}

// Validates and formats data for sections with title, author, and color
function titleAuthorColor(data, callback) {
    var color = data.properties.color;
    
    if(color) {
        titleAuthor(data, function(err, returnData, errMsg) {
            if(err) {
                callback(err);
            } else if (!returnData) {
                callback(err, returnData, errMsg);    
            } else {
                var hexRegex = new RegExp("^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$");
                if(hexRegex.match(color)) {
                    returnData.properties.color = color;
                } else {
                    callback(null, false, "Invalid hexidecimal color.");
                }
            }
        });
    } else {
        callback(null, false, "Hexidecimal color not provided.");
    }
}

// Validates and formats data for sections with text
function text(data, callback) {
    var type = data.type;
    var order = data.order;
    var text = data.properties.text;
    
    if(order && text) {
        var returnData = {
            type: type,
            order: order,
            properties: {
                text: text
            }
        };  
        
        callback(null, returnData, null);
    } else {
        callback(null, false, "Text and order must be provided.");
    }
}

// Validates and formats data for sections with multiple images
function images(data, callback) {
    // Transfer relevant values from data to returnData
    var returnData = _.pick(data, "type", "order", "properties");
    var images = returnData.properties.images;
    
    if(images) {
        // imgCount increments until all instructions have exectuted
        var imgCount = 0;
        for(var i = 0; i < images.length; i++) {
            // Pick out the values we cre about
            images[i] = _.pick(images[i], "id", "src", "type", "order");
            
            var imgString = images[i].src.string;
            var imgType = images[i].type;
            
            // Check that the required variables exist
            if(imgString && imgType && images[i].order) {
                // Check for valid imgType
                if(imgType == "upload") {
                    // Validate upload.
                    validateGalleryImageUpload(imgString, i, 
                            function(err, contentType, index) {
                        if(err) {
                            callback(err);
                        } else if(!contentType) {
                            callback(null, false, "Image not in valid format");
                        } else {
                            // If no id exists for an image, generate one
                            if(!images[index].id) {
                                images[index].id = uuid.v1();
                            }
                            
                            // Assign proper content meta data.
                            images[index].src.type = contentType;
                            
                            // Trim the fat on imgSrc (caption is optional)
                            images[index].src = _.pick(images[index].src,
                                "imgId", "imgString", "contentType", "caption");
                                
                            imgCount++;
                            if(imgCount == images.length) {
                                // Assign images to data and return that.
                                returnData.properties.images = images;
                                callback(null, returnData, null);
                            }
                        }
                    });
                } else if (imgType == "link") {
                    // Validate upload.
                    validateGalleryImageLink(imgString, i, 
                            function(err, contentType, index) {
                        if(err) {
                            callback(err);
                        } else if(!contentType) {
                            callback(null, false, "Image not in valid format");
                        } else {
                            // Assign proper content meta data.
                            images[index].imgSrc.contentType = contentType;
                            
                            // Trim the fat on imgSrc
                            images[index].imgSrc = _.pick(images[index].imgSrc,
                                "imgId", "imgString", "contentType");
                                
                            imgCount++;
                            if(imgCount == images.length) {
                                // Assign images to data and return that.
                                returnData.properties.images = images;
                                callback(null, returnData, null);
                            }
                        }
                    });
                } else {
                    callback(null, false, "Image type not valid.");
                }    
            } else {
                callback(null, false, "Must provide image, type, and order.");
            }
        }
        
        callback(null, returnData, null);
    } else {
        callback(null, false, "Images must be provided.");
    }
}

function updateDynamoDB(params, callback) {
    // Establish connection with DynamoDB
    var docClient = new AWS.DynamoDB.DocumentClient();
    
    // Execute the statement
    docClient.update(params, function(err, newData) {
        if (err) {
            console.error("Unable to update officer. Error JSON:", 
                JSON.stringify(err, null, 2));
            callback(err);
        } else {
            console.log("Updated officer:", JSON.stringify(newData, null, 2));
            callback(null, newData);
        }
    });
}

function updateS3(params, callback) {
    
}

// Take an image buffer and upload it to S3
function uploadImgS3(bucket, key, contentType, imgBuffer, acl, callback) {
    var S3 = new AWS.S3({
        params: {
            Bucket: bucket
        }
    });
    
    // Prepare the parameters for upload
    var params = {
        Key: key,
        ContentType: contentType,
        Body: imgBuffer,
        ACL: acl
    };
    
    // Upload the image to S3
    S3.upload(params, function(err, data) {
        if (err) {
            callback(err);
        } else {
            callback(null);
        }
    });
}