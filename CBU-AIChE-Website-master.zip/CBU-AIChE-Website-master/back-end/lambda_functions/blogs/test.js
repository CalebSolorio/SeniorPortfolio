var uuid = require('node-uuid');

console.log(typeof uuid.v1());