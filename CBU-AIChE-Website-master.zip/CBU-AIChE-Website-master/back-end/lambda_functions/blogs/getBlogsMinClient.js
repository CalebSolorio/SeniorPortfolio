console.log('Loading getBlogsMinClient function...');

/*
    This returns the id, name, author, image, and favorite status 
    of public blog posts in the table.
    
    Use AWS to communicate with DynamoDB.
*/

var AWS = require('aws-sdk');

// Establish a connection to DynamoDB
AWS.config.update({
  region: "us-east-1",
//   endpoint: "http://localhost:8000"
});

// Establish a connection with DynamoDB
var docClient = new AWS.DynamoDB.DocumentClient();

// Choose the table we want to scan and the values we want from it.
// Keep variable outside handler scope for the onScan() method.
var params = {
    TableName: "blog_posts",
    ProjectionExpression: "id, title, author_id, draft, favorite",
    KeyConditionExpression: "#d = :d",
    ExpressionAttributeNames:{
        "#d": "draft"
    },
    ExpressionAttributeValues: {
        ":d":false
    }
};
        
exports.handler = function(event, context, callback) {
    if(event.startKey) {
        params.ExclusiveStartKey = event.startKey;
    }
    
    // Scan the officers
    docClient.scan(params, onScan, function(err, returnData) {
        if(err) {
            callback(err);
        } else {
            callback(null, returnData);
        }
    });
};

function onScan(err, data, callback) {
    if (err) {
        console.error("Unable to scan the table. Error JSON:", 
            JSON.stringify(err, null, 2));
    } else {
        // Log all officers scanned
        console.log("Scan succeeded. JSON: ",
            JSON.stringify(data, null, 2));

        // scan() can retrieve up to 1MB of data,
        // scan recursively if unscanned officers remain
        callback(data);
        // if (typeof data.LastEvaluatedKey != "undefined") {
        //     console.log("Scanning for more officers...");
        //     params.ExclusiveStartKey = data.LastEvaluatedKey;
        //     docClient.scan(params, onScan);
        // } else {
        //     callback(data);
        // }
    }
}