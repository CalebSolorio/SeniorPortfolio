console.log('Loading deleteOfficer function...');

/*
    This removes a specified blog post's data 
    and images from DynamoDB and S3, respectively.
    
    Use AWS to communicate with DynamoDB.
*/

var AWS = require('aws-sdk');

// Establish a connection to AWS
AWS.config.update({
  region: "us-east-1",
//   endpoint: "http://localhost:8000"
});
        
exports.handler = function(event, context, callback) {
    var bucket = "cbu-aiche";
    var blogTable = "blog_posts";
    var sectionTable = "blog_sections";
    var id = event.id;
    
    var errors = {};        // Keep track of errors
    var executionCount = 0; // Used to verify every execution
    
    // Delete officer info from DynamoDB
    deleteBlogFromTable(blogTable, sectionTable, id, function(err) {
        executionCount++;
        if(err) {
            errors["DynamoDB"] = err;
        }
    });
    
    // Delete officer info from S3
    var key = "website/images/blog-posts" + id;
    
    deleteBlogFromS3(bucket, key, function(err) {
        executionCount++;
        if(err) {
            errors["S3"] = err;
        }
    });
    
    // Once both deletes have executed, evaluate success
    if(executionCount == 2) {
        if(errors.length > 0) {
            callback(errors);
        } else {
            callback(null, { status: 200 });
        }
    }
};

function deleteBlogFromTable(blogTable, sectionTable, id) {
    // Establish a connection with DynamoDB
    var docClient = new AWS.DynamoDB.DocumentClient();
    
    // Establish a counter to ensure all executions occur before proceeding
    var count = 0;
    
    // Prepare the statement.
	var blogTableParams = {
        TableName: blogTable,
        Key:{
            "id": id,
        }
    };
    
    // Execute the statement on the blog table
    docClient.delete(blogTableParams, function(err, data, callback) {
        if (err) {
            console.error("Unable to delete blog from DynamoDB. Error JSON:", 
                JSON.stringify(err, null, 2));
            callback(err);
        } else {
            console.log("Successfully deleted blog from DynamoDB! JSON: ", 
                JSON.stringify(data, null, 2));
            
            count++;
            if(count == 2) {
                callback(null);    
            }
        }
    });
    
    var sectionTableParams = {
        TableName: sectionTable,
        Key:{
            "blog_id": id,
        }
    };
    
    // Execute the statement on the section table
    docClient.delete(sectionTableParams, function(err, data, callback) {
        if (err) {
            console.error("Unable to delete sections from DynamoDB. Error JSON:", 
                JSON.stringify(err, null, 2));
            callback(err);
        } else {
            console.log("Successfully deleted sections from DynamoDB! JSON: ", 
                JSON.stringify(data, null, 2));
            
            count++;
            if(count == 2) {
                callback(null);    
            }
        }
    });
    
}

function deleteBlogFromS3(bucket, key) {
    // Establish connection to S3
    var S3 = new AWS.S3({
        params: {
            Bucket: bucket
        }
    });
    
    // Prepare the delete statement
    var params = {
        Delete: {
            Objects: [
                 { Key: key },
            ]
        }
    };
    
    // Delete the officer's object from S3
    S3.deleteObject(params, function(err, data, callback) {
        if (err) {
            console.error("Unable to delete blog data from S3. Error JSON:", 
                JSON.stringify(err, null, 2));
            callback(err);
        } else {
            console.log("Blog data successfully deleted from S3! JSON: ",
                JSON.stringify(data, null, 2));
            callback(null);
        }
    });
    
}
