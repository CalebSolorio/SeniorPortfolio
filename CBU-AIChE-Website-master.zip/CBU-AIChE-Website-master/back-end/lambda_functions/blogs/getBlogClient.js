console.log('Loading getBlog function...');

/*
    This returns all info on a blog post that's availible to the public,
    given an id.
    
    Use AWS to communicate with DynamoDB.
*/

var AWS = require('aws-sdk');

// Establish a connection to DynamoDB
AWS.config.update({
  region: "us-east-1",
//   endpoint: "http://localhost:8000"
});

// Blog query parameters
var blogParams = {
    TableName: "blog_posts",
    ProjectionExpression: "id, title, draft, author_id, updated_at",
    Limit: 1
};

// Section query parameters
var sectionParams = {
    TableName: "blog_posts",
    ProjectionExpression: "id, title, draft, author_id, updated_at",
    Limit: 1
};

// Establish a connection with DynamoDB
var docClient = new AWS.DynamoDB.DocumentClient();
        
exports.handler = function(event, context, callback) {
    // Create a response body to fill in later
    var returnData = {};
    
    // Establish a counter to ensure all executions occur before callback
    var count = 0;
    
    getBlogInfo(event.id, function(err, blogData) {
        if(err) {
            console.error("Unable to get blog data from DynamoDB. Error JSON:", 
                JSON.stringify(err, null, 2));
            callback(err);
        } else {
            if(blogData.length > 0) {
                // Set post details based on blog data
                returnData.id = blogData.id;
                returnData.title = blogData.title;
                returnData.draft = blogData.draft;
                returnData.draft = blogData.author_id;
                returnData.updated_at = blogData.updated_at;
                
                count++;
                if(count == 2) {
                    callback(null, returnData);
                }
            } else { // This blog post is either non-public or nonexistent
                var errMsg = "ERROR 404: This blog post does not exist :(";
                console.log(errMsg);
                callback(404, { errMsg: errMsg });
            }
        }
    });
    
    getSections(event.id, function(err, sectionData) {
        if(err) {
            console.log("Unable to get section data from DynamoDB. Error JSON:", 
                JSON.stringify(err, null, 2));
            callback(err);
        } else {
            // Set section data
            returnData.sections = sectionData;
            
            count++;
            if(count == 2) {
                callback(null, returnData);
            }
        }
    });
};

function getBlogInfo(id, callback) {
    blogParams.KeyConditionExpression = "id = :id, draft = :d";
    blogParams.ExpressionAttributeValues = {
        ":id": id,
        ":d": false
    };
    
    // Scan the blog posts
    docClient.scan(blogParams, function(err, returnData) {
        if (err) {
            console.error("Unable to scan the table. Error JSON:", 
                JSON.stringify(err, null, 2));
        } else {
            // Log the officer scanned
            console.log("Scan succeeded. JSON: ",
                JSON.stringify(returnData, null, 2));
            callback(null, returnData);
        }
    });
} 

function getSections(id, callback) {
    sectionParams.KeyConditionExpression = "blog_id = :b_id";
    sectionParams.ExpressionAttributeValues = {
        ":b_id": id
    };
    
    // Scan the blog posts
    docClient.scan(sectionParams, onScan, function(err, returnData) {
        if (err) {
            console.error("Unable to scan the table. Error JSON:", 
                JSON.stringify(err, null, 2));
        } else {
            // Log the officer scanned
            console.log("Scan succeeded. JSON: ",
                JSON.stringify(returnData, null, 2));
            callback(null, returnData);
        }
    });
}

function onScan(err, data, callback) {
    if (err) {
        console.error("Unable to scan the table. Error JSON:", 
            JSON.stringify(err, null, 2));
    } else {
        // Log all officers scanned
        console.log("Scan succeeded. JSON: ",
            JSON.stringify(data, null, 2));

        // scan() can retrieve up to 1MB of data,
        // scan recursively if unscanned officers remain
        if (typeof data.LastEvaluatedKey != "undefined") {
            console.log("Scanning for more officers...");
            sectionParams.ExclusiveStartKey = data.LastEvaluatedKey;
            docClient.scan(sectionParams, onScan);
        } else {
            callback(data);
        }
    }
}