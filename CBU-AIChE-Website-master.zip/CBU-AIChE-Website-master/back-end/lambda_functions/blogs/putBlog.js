console.log('Loading postOfficer function...');

/*
    Updates a blog post in DynamoDB and its photos in S3.
    
    Use AWS to communicate with DynamoDB,
    underscore for data parsing,
    uuid for generating unique identifiers,
    fileType for exactly what you'd think,
    and GraphicsMagick image manupilation.
*/ 

var AWS = require("aws-sdk");
var _ = require('underscore');
var uuid = require('node-uuid');
var fileType = require('file-type');
var gm = require('gm')
            .subClass({ imageMagick: true });
            
// Establish a connection AWS
AWS.config.update({
  region: "us-east-1",
//   endpoint: "http://localhost:8000"
});

exports.handler = function(event, context, callback) {
    var data = _.pick(event, "id", "title", "author_id", "draft");
    
    if(!data.id) {
        callback(404, "No id provided");
        return;
    }
    
    async.waterfall([
        function prepare(next) {
            // Start with the basics of our update statement
            var table = "blog_posts";
            var key = { "id": data.id };
            var updateExpression = "";
            var expressionAttributeValues = {};
            var returnValues = "UPDATED_NEW";
            
            // Prepare to update the title
            if(data.title) {
                updateExpression += "set title = :t";
                expressionAttributeValues[":t"] = data.title;
            }
            
            // Prepare to update the author
            if(data.author_id) { 
                if(updateExpression.length > 0) {
                    updateExpression += ", author_id = :a_i";
                } else {
                    updateExpression += "set author_id = :a_i";
                }
                expressionAttributeValues[":a_i"] = data.author_id;
            }
            
            // Prepare to update the draft status
            if(data.draft && typeof data.draft == "boolean") { 
                if(updateExpression.length > 0) {
                    updateExpression += ", draft = :d";
                } else {
                    updateExpression += "set draft = :d";
                }
                expressionAttributeValues[":d"] = data.draft;
            }
            
            // Prepare to update the favorite status
            if(data.favorite && typeof data.favorite == "boolean") { 
                if(updateExpression.length > 0) {
                    updateExpression += ", favorite = :f";
                } else {
                    updateExpression += "set favorite = :f";
                }
                expressionAttributeValues[":f"] = data.favorite;
            }
            
            next(null, table, key, updateExpression,
                returnValues, expressionAttributeValues);
            
        }, function upload(table, key, updateExpression, 
                returnValues, expressionAttributeValues, next) {
            // Update the image
            if(data.image) {
                imgUpld(data.image, key, function(err, returnId, errMsg) {
                    if(err) {
                        console.log("Error uploading image. Error JSON: ", 
                            JSON.stringify(err, null, 2));
                        next(err);
                    } else if(!returnId) {
                        console.log("Invalid, JSON:", 
                            JSON.stringify(errMsg, null, 2));
                        next(errMsg);
                    } else {
                        // Add an image id to our update expression
                        if(updateExpression.length > 0) {
                            updateExpression += ", image_id = :i";
                        } else {
                            updateExpression += "set image_id = :i";
                        }
                        expressionAttributeValues[":i"] = key;
                        
                        // Move to next step
                        next(null, table, key, updateExpression,
                            returnValues, expressionAttributeValues);
                    }
                });
            } else {
                // Move to next step
                next(null, table, key, updateExpression,
                    returnValues, expressionAttributeValues);
            }
            
        }, function update(table, key, updateExpression, 
                returnValues, expressionAttributeValues, next) {
            // Prepare to update the time of the last update
            if(updateExpression.length > 0) {
                updateExpression += ", updated_at = :u";
            } else {
                updateExpression += "set updated_at = :u";
            }
            expressionAttributeValues[":u"] = 
                Math.round(new Date().getTime()/1000);
                
            // Prepare the update statement
            var params = {
                TableName: table,
                Key: key,
                UpdateExpression: updateExpression,
                ReturnValues: returnValues,
                ExpressionAttributeValues: expressionAttributeValues
            }; 
            
            // Update DynamoDB. Callback method if all updates have executed.
            updateDynamoDb(params, function(err, returnData) {
                if(err) {
                    console.log("Failed to update DynamoDB. Error JSON: ",
                        JSON.stringify(err, null, 2));
                    next(err);
                } else {
                    next(null, returnData);
                }
            });
        }    
    ], function(err, returnData) {
        if(err) {
            callback(err);
        } else {
            callback(null, returnData);
        }
    });
    
};

// Validates and formats data for sections with image uploads
function imgUpld(image, id, callback) {
    if(image) {
        validateImageUpload(image, function(err, contentType, errMsg) {
            if(err) {
                callback(err); 
            } else {
                if(contentType) {
                    // Create the variables necessary to upload
                    var bucket = "cbu-aiche";
                    var key = "/website/images/blog-posts/" 
                        + id + "/" + id;
                    var acl = "public-read";
                    
                    uploadImgS3(bucket, key, contentType, 
                            image, acl, function(err) {
                        if(err) {
                            callback(err, null, null);
                        } else {
                            callback(null, id, null);
                        }
                    });
                } else {
                    callback(null, false, "Not a valid image.");
                }    
            }
        });
    } else {
        callback(null, false, "Must provide both order and image.");
    }
}

// Validate base64 string integrity
function validateImageUpload(imgString, callback) {
    // Check to make sure the passed-in string is actually an base64 image
	var matches = imgString.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
	if(matches.length !== 3) {
	    callback(null, false);
	    return;
	}
	
	var imgBuffer = Buffer.from(imgString, 'base64');
	
	// Check the file type and return the approriate content metadata.
    var contentType = fileType(imgBuffer);
    if(contentType.ext == 'avi' || contentType.ext == 'gif'
            || contentType.ext == 'jpg' || contentType.ext == 'mkv' 
            || contentType.ext == 'mp4' || contentType.ext == 'ogg' 
            || contentType.ext == 'png' ||contentType.ext == 'vob' 
            || contentType.ext == 'webm'|| contentType.ext == 'wmv') {
                
        callback(null, contentType);
        
    } else {
        callback(null, false);
    }
}

// Take an image buffer and upload it to S3
function uploadImgS3(bucket, key, contentType, imgBuffer, acl, callback) {
    var S3 = new AWS.S3({
        params: {
            Bucket: bucket
        }
    });
    
    // Prepare the parameters for upload
    var params = {
        Key: key,
        ContentType: contentType,
        Body: imgBuffer,
        ACL: acl
    };
    
    // Upload the image to S3
    S3.upload(params, function(err, data) {
        if (err) {
            callback(err);
        } else {
            callback(null);
        }
    });
}

// Update DynamoDB table(s) and return the execution status
function updateDynamoDb(params, callback) {
    // Establish connection with DynamoDB
    var docClient = new AWS.DynamoDB.DocumentClient();
    
    // Execute the statement
    docClient.update(params, function(err, newData) {
        if (err) {
            console.error("Unable to update officer. Error JSON:", 
                JSON.stringify(err, null, 2));
            callback(err);
        } else {
            console.log("Updated officer:", JSON.stringify(newData, null, 2));
            callback(null, newData);
        }
    });
}