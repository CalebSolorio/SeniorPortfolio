import React from "react";

import BannerPhoto from "../components/pages/BannerPhoto";
import ContainerCard from "../components/pages/ContainerCard";
import VerticalMedia from "../components/pages/VerticalMedia";
import Gallery from "../components/pages/Gallery";
import OfficerCard from "../components/pages/OfficerCard";

class About extends React.Component {
  render() {
    const styles = {
      background: {
        background: '#37474F'
      },
      row: {
        margin: 0,
      },
      card: {
        background: '#ECEFF1',
        position: 'relative',
        transform: 'translate(0%, -50px)',
      },
      marginTop: {
        marginTop: 20
      },
    };

    return (
      <div>
        <BannerPhoto img="http://wp.production.patheos.com/blogs/newwineskins/files/2016/11/California-Baptist-University.jpg"
          text="Us chemical engineers love burritos."
          filter={true}
          textColor="white" />
        <div class="row" style={styles.background}>
          <ContainerCard className="col m12 l10 push-l1" noPadding={true} style={styles.card}>
              <div class="row" style={styles.row}>
                  <div class="col s12">
                    <VerticalMedia title="Who We Are"
                      text="Established in 2007, the Gordon and Jill Bourns College of
                      Engineering has received ABET accreditation for CE, ECE,
                      and ME, and offers ten programs to more than 500 students.
                      The ASCE student chapter at CBU is an organization
                      dedicated to excellence in both academic, and professional
                      achievement pertaining to civil engineering. We
                      strive to provide students with a diverse array of experiences
                      that will better equip them in their future careers as professional
                      engineers. The goal of the ASCE Student Chapter
                      is ultimately to increase the students’ ability to engage
                      their chosen profession through various activities, and to
                      heighten their potential as they enter the workforce."
                      img="http://web.stanford.edu/group/sattelygroup/cgi-bin/wordpress/wp-content/uploads/2015/10/Sattely-group_2015-e1445409170395.jpeg"
                      caption="Look at these students. They didn't found the club
                      or anything but it kinda looks like they did."
                      style={styles.marginTop} />

                    <VerticalMedia title="What We're Doing"
                      text="Community Service – CBU’s ASCE chapter has logged
                      more than 200 hours of service to the community, and
                      continues to work with local community partners. One key
                      partner is Keep Riverside Clean and Beautiful (KRCB)."/>

                    <VerticalMedia
                      text="ASCE Events – YMF Soccer and Golf Tournament, Los Angeles
                      and Riverside/San Bernardino branch luncheons and section
                      dinners, technical presentations and job fairs that help members
                      grow and network with professional engineers."/>

                    <VerticalMedia
                      text="Pacific South West Conference (PSWC) – Over the years we
                      have placed in the top three in numerous events. Non-tech
                      events include volleyball and ultimate Frisbee, whereas the Concrete
                      Canon, Steel Bridge, and Geo-Wall Competitions are
                      some technical events."/>

                    <VerticalMedia
                      text="This year our chapter will be attending PSWC 2017 at Cal
                      State Irvine. Based on our success over the last few years,
                      our chapter will be competitive in every event. We are currently
                      preparing intensively for PSWC 2017 and expect to
                      win many more honors." />
                  </div>
                </div>

              <div class="row" style={styles.row}>
                <VerticalMedia title="Current Members" />
                <div class="col s12 row">
                  <OfficerCard link="http://imgur.com/gallery/KjtbV" className="col s6 m4 l3" img="http://i.imgur.com/tyNwowg.jpg" name="Harold" position="God Amongst Men" />
                  <OfficerCard link="https://www.linkedin.com/in/calebsolorio/" className="col s6 m4 l3" img="https://i.kinja-img.com/gawker-media/image/upload/s--lwBAixc8--/c_scale,fl_progressive,q_80,w_800/b4dcelfpwz1ackhjekfw.jpg" name="Joe Biden" position="Chief Pointer" />
                  <OfficerCard className="col s6 m4 l3" img="https://media1.popsugar-assets.com/files/thumbor/yXlp640Tn-VxbxP-vaiI2NKZjxA/fit-in/1024x1024/filters:format_auto-!!-:strip_icc-!!-/2017/01/09/880/n/1922507/17b90c6d5873edb1231823.18767920_edit_img_image_18019874_1483991626/i/What-Salt-Bae-Meme.jpg" name="Salt Bae" position="Cullinary Fashionista" />
                  <OfficerCard className="col s6 m4 l3" img="https://i.ytimg.com/vi/QxU6jF7_YTU/maxresdefault.jpg" name="Cash Me Ousside" position="How bow dah?" />
                  <OfficerCard className="col s6 m4 l3" img="http://i2.kym-cdn.com/entries/icons/original/000/022/138/reece.JPG" name="Roll Safe" position="Obvious-Fact Stater" />
                  <OfficerCard className="col s6 m4 l3" img="http://i0.kym-cdn.com/photos/images/facebook/000/862/065/0e9.jpg" name="Pepe" position="Hate Symbol" />
                </div>
              </div>
          </ContainerCard>
        </div>
      </div>
    );
  }
}

export default About;
