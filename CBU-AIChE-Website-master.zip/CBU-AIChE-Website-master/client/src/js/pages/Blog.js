import React from "react";

import BannerPhoto from "../components/pages/BannerPhoto";
import ContainerCard from "../components/pages/ContainerCard";
import TextLeftImageRight from "../components/pages/TextLeftImageRight";
import TextRightImageLeft from "../components/pages/TextRightImageLeft";
import VerticalMedia from "../components/pages/VerticalMedia";
import Gallery from "../components/pages/Gallery";
import OfficerCard from "../components/pages/OfficerCard";

import Paper from "material-ui/Paper"

class Blog extends React.Component {
  render() {
    const styles = {
      background: {
        background: '#37474F'
      },
      row: {
        margin: 0,
      },
      card: {
        background: '#ECEFF1',
        position: 'relative',
        transform: 'translate(0%, -50px)',
      },
      paperCircle:{
        overflow:'hidden',
        padding: 0,
        maxWidth: 400,
        maxHeight: 400,
        margin: 'auto',
      },
      img: {
        width:'100%',
        height:'auto',
      },
      text: {
        fontFamily: 'Open Sans, sans-serif',
        fontSize: 25,
        textAlign:'center',
        padding: 0
      },
      marginTop: {
        marginTop: 40,
      }
    };

    return (
      <div>
        <BannerPhoto img="http://uvmbored.com/wp-content/uploads/2015/05/blog.jpg"
          text="...and telling you about our feelings."
          filter={true}
          textColor="white" />
        <div class="row" style={styles.background}>
          <ContainerCard className="col m12 l10 push-l1" noPadding={true} style={styles.card}>
              <div class="row" style={styles.row}>

              </div>
              <div class="row" style={styles.marginTop}>
                <div class="col s12">
                  <Paper style={styles.paperCircle} zDepth={2} circle={true} >
                      <img src="https://i.imgflip.com/17u01.jpg" style={styles.img} />
                  </Paper>
                </div>
                <p class="col s10 m8 l6 push-s1 push-m2 push-l3" style={styles.text} >
                  Whoops, it looks like we ran out of posts. But stay paw-sitive and don't overreact! Chemistry Cat is working on a solution ;)
                </p>
              </div>
          </ContainerCard>
        </div>
      </div>
    );
  }
}

export default Blog;
