import React from "react";

import BannerPhoto from "../components/pages/BannerPhoto";
import ContainerCard from "../components/pages/ContainerCard";
import TextLeftImageRight from "../components/pages/TextLeftImageRight";
import TextRightImageLeft from "../components/pages/TextRightImageLeft";
import VerticalMedia from "../components/pages/VerticalMedia";
import Gallery from "../components/pages/Gallery";
import OfficerCard from "../components/pages/OfficerCard";

class Partners extends React.Component {
  render() {
    const styles = {
      background: {
        background: '#37474F'
      },
      row: {
        margin: 0,
      },
      card: {
        background: '#ECEFF1',
        position: 'relative',
        transform: 'translate(0%, -50px)',
      },
      text: {
        fontFamily: 'Open Sans, sans-serif',
        fontSize: 20,
        margin: '0 10'
      },
      marginTop: {
        marginTop: 20
      },
    };

    return (
      <div>
        <BannerPhoto img="https://www.thecompleteuniversityguide.co.uk/media/3335698/istock_000078278841_double.jpg"
          text="We also love partnering with people who will give us money..."
          filter={true}
          textColor="white" />
        <div class="row" style={styles.background}>
          <ContainerCard className="col m12 l10 push-l1" noPadding={true} style={styles.card}>
            <div style={styles.marginTop}>
              <Gallery title="Our Sponsers"
                items={[
                  {
                    img: 'https://brobible.files.wordpress.com/2015/05/breaking-bad-los-pollos-hermanos.png',
                    caption: "Pollos Hermanos: We aren\'t meth-in\' around when it comes to chemistry."
                  },
                  {
                    img: 'http://theoscorpindustries.weebly.com/uploads/1/1/3/9/11390381/1719871_orig.jpg',
                    caption: "Oscorp: We love goblin\' up opprotunities to help young scientists. What, Parker? I hardly know her!"
                  },
                  {
                    img: 'http://wallpapercave.com/wp/IEuqZXD.png',
                    caption: "Aperature Science: We ran out of blue gel, halp."
                  },
                ]}
              />
            </div>
              <div class="row">
                <div class="col s12">
                  <VerticalMedia title="How can you help?"
                    text="Our chapter strives to engage and prepare our students
                    through outreach and events. As one of the smallest and
                    newest engineering schools funding remains an issue, and
                    these events would not be possible without our amazing
                    sponsors. All donations made to CBU are tax-deductible
                    to the fullest extent of the law."
                    style={styles.marginTop} />

                  <p style={styles.text}>
                    For more information, contact Melvin Tran (<a href= "mailto:Melvin.Tran@calbaptist.edu">Melvin.Tran@calbaptist.edu</a>)
                  </p>
                </div>
              </div>
          </ContainerCard>
        </div>
      </div>
    );
  }
}

export default Partners;
