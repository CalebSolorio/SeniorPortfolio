import React from "react";

import BannerPhoto from "../components/pages/BannerPhoto";
import ContainerCard from "../components/pages/ContainerCard";
import TextLeftImageRight from "../components/pages/TextLeftImageRight";
import TextRightImageLeft from "../components/pages/TextRightImageLeft";
import VerticalMedia from "../components/pages/VerticalMedia";
import Gallery from "../components/pages/Gallery";
import OfficerCard from "../components/pages/OfficerCard";

class Home extends React.Component {
  render() {

    const styles = {
      background: {
        background: '#37474F'
      },
      row: {
        margin: 0,
      },
      card: {
        background: '#ECEFF1',
        position: 'relative',
        transform: 'translate(0%, -50px)',
      },
      iframe: {
        border: 'none',
        margin: '10 0',
      },
      marginTop: {
        marginTop: 20
      },
    };

    return (
      <div>
        <BannerPhoto img="https://science.rpi.edu/sites/default/files/banner2_0.jpg"
          text="Chemical Engineering is neato burrito."
          filter={true}
          textColor="white" />
        <div class="row" style={styles.background}>
          <ContainerCard className="col m12 l10 push-l1" noPadding={true} style={styles.card}>
              <div class="row" style={styles.row}>
                <div class="col s12">
                  <VerticalMedia title="What is AIChE?"
                    text="AIChE is the world's leading organization for chemical
                    engineering professionals, with more than 50,000 members from
                    over 100 countries. AIChE has the breadth of resources and
                    expertise you need whether you are in core process industries
                    or emerging areas, such as translational medicine."
                    style={styles.marginTop} />
                </div>
              </div>
              <Gallery
                items={[
                  {
                    img: 'https://amploprod.s3.amazonaws.com/uploads/campaign_image/name/57198e8f6db18905ee000139/AIChEClubPhoto.JPG',
                    caption: "I have no idea who these people are."
                  },
                  {
                    img: 'https://pbs.twimg.com/media/C3ncp_BVcAAZ_uk.jpg',
                    caption: "Look man, like half the candy there is " +
                      "banana-flavored Laffy-Taffy. Are you trying to make enemies?"
                  },
                  {
                    img: 'http://www.uidaho.edu/~/media/UIdaho-Responsive/Images/Degree-Profiles/Engineering/MEngr-chem-engr.ashx?w=700&as=1',
                    caption: "Student dissapointed by the yield of his homemade vape juice (Colorized, Circa 1939)."
                  },
                ]}
              />

              <div class="row" style={styles.row}>
                <div class="col s12">
                  <VerticalMedia
                    text="We believe that chemical engineering will help shape
                    the future of our society. Thus, we have made it our mission
                    to foster greatness within the future chemical engineers
                    at California Baptist University. We hope that you will play
                    a part in helping us reach as many individuals as possible." />
                </div>
              </div>

              <div class="row" style={styles.row}>
                <iframe class="col s12 hide-on-med-and-up"
                  src="https://calendar.google.com/calendar/embed?src=aicheuci.com_inl9g6j6cbmdntk5o6smfv3vcc%40group.calendar.google.com&ctz=America/Los_Angeles"
                  style={styles.iframe} height="400" scrolling="no"></iframe>
                <iframe class="col s12 hide-on-small-only"
                  src="https://calendar.google.com/calendar/embed?src=aicheuci.com_inl9g6j6cbmdntk5o6smfv3vcc%40group.calendar.google.com&ctz=America/Los_Angeles"
                  style={styles.iframe} height="600" scrolling="no"></iframe>
              </div>
          </ContainerCard>
        </div>
      </div>
    );
  }
}

export default Home;
