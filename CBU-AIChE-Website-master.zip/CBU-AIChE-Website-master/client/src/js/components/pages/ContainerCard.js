import React from "react";
import Card from 'material-ui/Card';
import Paper from 'material-ui/Paper';

class ContainerCard extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    const styles = {
      main: {
        padding: this.props.noPadding ? '0' : null
      },
      card: {
        padding: '.5em',
      },
    };

    return (
        <div class={this.props.className} style={Object.assign({}, styles.main, this.props.style)}>
          <Card zDepth={2} rounded={this.props.rounded} style={styles.card}>
            {this.props.children}
          </Card>
        </div>
    );
  }
}

export default ContainerCard;
