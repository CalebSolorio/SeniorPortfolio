import React from "react";

import Paper from 'material-ui/Paper';

class BannerPhoto extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    const styles = {
      container: {
        position: 'relative',
        background: '#607d8b',
        width: '100%',
        height: 550,
        zIndex:0,
      },
      img: {
        position: 'relative',
        width: '100%',
        height: '100%',
        objectFit: 'cover',
        opacity: this.props.filter ? .6 : 1,
      },
      text: {
        position:'absolute',
        left: '50%',
        marginRight: '-50%',
        padding: '5%',
        transform: 'translate(-50%, -25%)',
        fontFamily: 'Poppins, sans-serif',
        color: this.props.textColor,
        textAlign: 'center',
      }
    };

    return (
        <Paper class="banner-photo valign-wrapper" style={styles.container}>
          <img class="hide-on-large-only" src={this.props.img} style={styles.img}/>
          <img class="hide-on-med-and-down" src={this.props.img} style={styles.img}/>
          <h2 class="valign" style={styles.text}>{this.props.text}</h2>
        </Paper>
    );
  }
}

export default BannerPhoto;
