import React from "react";
import {Card, CardMedia, CardTitle} from 'material-ui/Card';
import FloatingActionButton from 'material-ui/FloatingActionButton';
import Paper from 'material-ui/Paper';

import Link from 'material-ui/svg-icons/content/link';
import SvgIcon from 'material-ui/SvgIcon';



class OfficerCard extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    const styles = {
      officerCard: {
        position: 'relative',
        maxHeight: 300,
        maxWidth: 200,
        margin: '10px auto',
      },
      img: {
        height: 200,
        width: 200,
        objectFit: 'cover',
      },
      label: {
        height: 100,
      },
      title: {
        lineHeight: '25px',
      },
      button: {
        position: 'absolute',
        right: '5%',
        transform: 'translate(0%, -50%)',
      },
      width: {
        width: '100%',
      },
      height: {
        height: '100%',
      },
      font: {
        fontSize: '2em',
        color: 'white',
      },
    };

    let linkBtn;

    let linkedInIcon = <div class="valign-wrapper">
      <a class="valign" style={styles.width} href={this.props.link} target="_blank">
        <i class="fa fa-linkedin" style={styles.font}/>
      </a>
    </div>

    let linkIcon = <div class="valign-wrapper">
      <a class="valign" style={styles.width} href={this.props.link} target="_blank">
        <Link style={styles.font}/>
      </a>
    </div>

    if(/((http|https):\/\/)?(www\.)?(linkedin\.com)(\/)?([a-zA-Z0-9\-\.]+)\/?/.test(this.props.link)) {
      linkBtn = <div>
        <div class="hide-on-large-only">
          <FloatingActionButton style={styles.button} mini={true}>
            {linkedInIcon}
          </FloatingActionButton>
        </div>
        <div class="hide-on-med-and-down">
          <FloatingActionButton style={styles.button}>
            {linkedInIcon}
          </FloatingActionButton>
        </div>
      </div>
    } else if(this.props.link){
      linkBtn = <div class="valign-wrapper">
        <div class="hide-on-large-only">
          <FloatingActionButton style={styles.button} mini={true} backgroundColor='rgb(69, 90, 100)'>
            {linkIcon}
          </FloatingActionButton>
        </div>
        <div class="hide-on-med-and-down">
          <FloatingActionButton style={styles.button} backgroundColor='rgb(69, 90, 100)'>
            {linkIcon}
          </FloatingActionButton>
        </div>
      </div>
    } else{
      styles.button.visibility = 'hidden';
    }

    return (
        <div class={this.props.className}>
          <Card zDepth={2} style={styles.officerCard}>
            <CardMedia>
              <img src={this.props.img} style={styles.img} />
            </CardMedia>
            {linkBtn}
            <CardTitle title={this.props.name} subtitle={this.props.position} style={styles.label} titleStyle={styles.title} />
          </Card>
        </div>
    );
  }
}

export default OfficerCard;
