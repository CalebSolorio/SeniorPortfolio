import React from "react";
import Card from 'material-ui/Card';
import SwipeableViews from 'react-swipeable-views';
import { autoPlay } from 'react-swipeable-views-utils';
import Pagination from 'pagination';

import FloatingActionButton from 'material-ui/FloatingActionButton';
import NavigationChevronLeft from 'material-ui/svg-icons/navigation/chevron-left';
import NavigationChevronRight from 'material-ui/svg-icons/navigation/chevron-right';

const AutoPlaySwipeableViews = autoPlay(SwipeableViews);

class Gallery extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      index: 0,
      size: 3
    };

    this.handleChangeIndex = this.handleChangeIndex.bind(this);
  }

  handleChangeIndex = (value) => {
    let newState = {
      size: this.state.size
    };

    if(value >= newState.size) {
      newState.index = 0
    } else if (value < 0) {
      newState.index = newState.size - 1
    } else {
      newState.index = value;
    }

    this.setState(newState);
  };

  render() {
    const styles = {
      root: {
        padding: '0 7%',
      },
      slide: {
        padding: '15px',
        minHeight: 100,
        color: '#fff',
      },
      title: {
        fontFamily: 'Poppins, sans-serif',
      },
      margin: {
        margin: '0px'
      },
      textAlign: {
        textAlign: 'center',
      },
      card: {
        maxWidth: 500,
        maxHeight: 500,
        width: 'auto',
        height: 'auto',
        margin: 'auto',
      },
      img: {
        maxWidth: '100%',
        maxHeight: '100%',
        width: 'auto',
        height: 'auto',
      },
      caption: {
        color: 'black',
        fontStyle: 'italic',
      },
      left: {
        left:'10%',
        position: 'fixed',
        zIndex: 10,
      },
      right: {
        right:'10%',
        position: 'fixed',
        zIndex: 10,
      },
    };

    return(
      <div>
        <div class='row' style={styles.margin}>
          <h2 class="col s12"
            style={Object.assign({}, styles.title, styles.margin, styles.textAlign)}>
              {this.props.title}
          </h2>
        </div>
        <div class="valign-wrapper">
          <FloatingActionButton onClick={(value) => this.handleChangeIndex(this.state.index - 1)} className="hide-on-small-only valign" style={styles.left}>
            <NavigationChevronLeft />
          </FloatingActionButton>
          <FloatingActionButton onClick={(value) => this.handleChangeIndex(this.state.index + 1)} className="hide-on-small-only valign" style={styles.right}>
            <NavigationChevronRight />
          </FloatingActionButton>
          <SwipeableViews resistance animateHeight index={this.state.index} onChangeIndex={this.handleChangeIndex} style={styles.root}>
            {
                    this.props.items.map((item, index) => (
                      <div style={styles.slide} key={index}>
                        <div style={styles.card}>
                          <Card>
                            <img src={item.img} style={styles.img}/>
                          </Card>
                          <p style={Object.assign({}, styles.caption, styles.textAlign)}>{item.caption}</p>
                        </div>
                      </div>
                    ))
            }
          </SwipeableViews>
        </div>
      </div>
    );

  }
}

export default Gallery;
