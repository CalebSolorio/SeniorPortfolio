import React from "react";
import Card from 'material-ui/Card';

class VerticalMedia extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    const styles = {
      margin: {
        margin: 0,
      },
      title: {
        fontFamily: 'Poppins, sans-serif',
        fontSize: 40,
        margin: 0,
      },
      text: {
        fontFamily: 'Open Sans, sans-serif',
        fontSize: 20,
        margin: '10px 0px',
      },
      card: {
        maxWidth: 600,
        maxHeight: 600,
        margin: 'auto',
      },
      img: {
        width: '100%',
        objectFit: 'cover',
      },
      caption: {
        textAlign: 'center',
        fontStyle: 'italic',
      }
    };

    return (
        <div class="row" style={Object.assign({}, styles.margin, this.props.style)}>
          <h2 class="col s12" style={styles.title}>{this.props.title}</h2>
          <p class="col s12" style={styles.text}>{this.props.text}</p>
          <div class="col s12">
            <Card style={styles.card}>
              <img src={this.props.img} style={styles.img}/>
            </Card>
            <p style={styles.caption}>{this.props.caption}</p>
          </div>
        </div>
    );
  }
}

export default VerticalMedia;
