import React from "react";
import Card from 'material-ui/Card';

class TextLeftImageRight extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    const styles = {
      row: {
        margin: 0,
      },
      title: {
        fontFamily: 'Poppins, sans-serif',
        marginLeft: 10,
      },
      text: {
        fontFamily: 'Open Sans, sans-serif',
        fontSize: '2em',
        textAlign: 'center',
        margin: 0,
      },
      img: {
        width: '100%',
        objectFit: 'cover',
      },
      caption: {
        textAlign: 'center',
        fontStyle: 'italic',
      }
    };

    return (
        <div class="row" style={styles.row}>
          <h2 class="col s12" style={styles.title}>{this.props.title}</h2>
          <p class="col s12 m7" style={styles.text}>{this.props.text}</p>
          <div class="col s12 m5">
            <Card>
              <img src={this.props.img} style={styles.img}/>
            </Card>
            <p style={styles.caption}>{this.props.caption}</p>
          </div>
        </div>
    );
  }
}

export default TextLeftImageRight;
