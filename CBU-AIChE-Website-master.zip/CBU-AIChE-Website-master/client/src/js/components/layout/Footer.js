import React from "react";
import {lightBlue900, blueGrey700} from 'material-ui/styles/colors';


export default class Footer extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {

    const footerStyle = {
      backgroundColor: lightBlue900,
      marginTop:0
    };

    const copyrightStyle = {
      backgroundColor: blueGrey700,
    };

    const linkStyle = {
      cursor:'hand',
    };

    return (
      <footer class="page-footer" style={footerStyle} >
        <div class="container">
          <div class="row">
            <div class="col l6 s12">
              <h5 class="white-text">CBU Chemistry Club</h5>
              <p class="grey-text text-lighten-4">The California Baptist Univeristy Chemistry Club is a part of AIChE, the world's leading organization for chemical engineering professionals.</p>
            </div>
            <div class="col l4 offset-l2 s12">
              <h5 class="white-text">Links</h5>
              <ul>
                <li onClick={(value) => this.props.onClick(0)} style={linkStyle}><a class="grey-text text-lighten-3">Home</a></li>
                <li onClick={(value) => this.props.onClick(1)} style={linkStyle}><a class="grey-text text-lighten-3">About</a></li>
                <li onClick={(value) => this.props.onClick(2)} style={linkStyle}><a class="grey-text text-lighten-3">Partners</a></li>
                <li onClick={(value) => this.props.onClick(3)} style={linkStyle}><a class="grey-text text-lighten-3">Blog</a></li>
                <li><a class="grey-text text-lighten-3" href="#!">Connect with us</a></li>
                <li><a class="grey-text text-lighten-3" href="#!">Officer Login</a></li>
              </ul>
            </div>
          </div>
        </div>
        <div class="footer-copyright" style={copyrightStyle}>
          <div class="container">
          © 2017 California Baptist University
          <a class="grey-text text-lighten-4 right" href="https://www.linkedin.com/in/calebsolorio" target="_blank">Created by Caleb Solorio</a>
          </div>
        </div>
      </footer>
    );
  }
}
