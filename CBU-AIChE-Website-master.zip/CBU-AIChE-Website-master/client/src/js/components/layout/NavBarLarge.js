import React from 'react';
import {AppBar, RaisedButton} from 'material-ui';

import GroupAddIcon from 'material-ui/svg-icons/social/group-add';

import NavTabs from "../layout/NavTabs";


class NavBarLarge extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      scrollPos: 0,
      navPos: 0,
      yDifference: 0,
    };

    this.handleScroll = this.handleScroll.bind(this);
  }

  componentDidMount() {
    window.addEventListener('scroll', this.handleScroll);
  }

  componentWillUnmount() {
    window.removeEventListener('scroll', this.handleScroll);
  }

  handleScroll() {
    let state = this.state;
    const currentPos = $(document).scrollTop();
    const navPos = $("#lgNavBar").position().top;
    const yDifference = currentPos - state.scrollPos;

    state.yDifference = yDifference;
    state.navPosTop = navPos;
    state.scrollPos = currentPos;

    this.setState(state);
  }

  render() {
    var styles = {
      appBar: {
        flexWrap: 'wrap',
        top: 0 - this.state.scrollPos,
        position: 'fixed',
        transition: 'all 0s',
      },
      tabs: {
        width: '100%',
        height: '100%',
      },
      tab: {
        height: '100%',
      },
      links: {
        cursor:'hand',
        margin: '0px'
      }
    };

    if(this.state.scrollPos > 70) {
      styles.appBar.top = this.state.yDifference <= 0 ? 0 : -70;
      styles.appBar.transition = "all .3s";
    } else if (this.state.yDifference <= 0) {
      styles.appBar.top = 0;
    }

    return (
      <AppBar id="lgNavBar" onScroll={this.handleScroll} title={
        <div class="row">

          <p onClick={(value) => this.props.onChangeIndex(0)} class="col s2" style={styles.links}>{this.props.title}</p>

          <div class="col s6">
            <NavTabs mobile={false} slideIndex={this.props.slideIndex}
              onChangeIndex={this.props.onChangeIndex} />
          </div>

        </div>
      } style={styles.appBar} showMenuIconButton={false} iconElementRight={
        <a href="https://docs.google.com/forms/d/e/1FAIpQLScZoF5ORRalGQ52ALNDXikz3ogj5cU-FgAKX8Hk1jxWiZuUUQ/viewform?usp=sf_link" target="_blank">
          <RaisedButton
            label="Connect with us!"
            secondary={true}
            icon={<GroupAddIcon />}
          />
        </a>
      } />

    );
  }

}

export default NavBarLarge;
