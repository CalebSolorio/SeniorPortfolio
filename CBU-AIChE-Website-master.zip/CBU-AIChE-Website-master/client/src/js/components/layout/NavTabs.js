import React from 'react';
import {Link, IndexLink} from 'react-router';

import {Tab, Tabs} from 'material-ui';

import HomeIcon from 'material-ui/svg-icons/action/home';
import AboutIcon from 'material-ui/svg-icons/action/assignment-ind';
import PartnersIcon from 'material-ui/svg-icons/social/people';
import BlogIcon from 'material-ui/svg-icons/action/book';


class NavTabs extends React.Component {
  render() {
    var styles = {
      mobile: {
        tabs: {
          width: '100%',
          boxShadow: '0 1px 6px rgba(0,0,0,0.12), 0 1px 4px rgba(0,0,0,0.12)',
          zIndex: 1000,
        }
      },
      nonMobile: {
        tabs: {
          width: '100%',
          height: '100%',
        },
        tab: {
          height: '64px',
        },
      },

    };

    if(this.props.mobile) {
      const navData = this.props.navData;

      let mNavBar = {
        flexWrap: 'wrap',
        top: -75,
        position: 'fixed',
        transition: 'all .3s',
      };

      if(navData.yDifference <= 0 || navData.scrollPos <= 70) {
        mNavBar.top = 0;
        // if(navData.scrollPos - navData.navPos < 0) {
        //   mNavBar.transition = 'all 0s';
        // }
      }  //else if(navData.scrollPos < 130 ) {
      //   mNavBar.transition = 'all 0s';
      // }

      Object.assign(styles.mobile.tabs, mNavBar);

      return (
        <Tabs id="mNavBar"
          onChange={this.props.onChangeIndex}
          value={this.props.slideIndex}
          style={styles.mobile.tabs}
          onScroll={this.props.onScroll}
          onTouchStart={this.props.onScroll}
          onTouchEnd={this.props.onScroll}
        >
            <Tab value={0} icon={<HomeIcon color="white"/>} label="Home" containerElement={<IndexLink to="/"/>} />
            <Tab value={1} icon={<AboutIcon color="white"/>} label="About" containerElement={<Link to="about"/>} />
            <Tab value={2} icon={<PartnersIcon color="white"/>} label="Partners" containerElement={<Link to="partners"/>} />
            <Tab value={3} icon={<BlogIcon color="white"/>} label="Blog" containerElement={<Link to="blog"/>}/>
        </Tabs>

      );
    } else {
      return (
        <Tabs onChange={this.props.onChangeIndex}
            value={this.props.slideIndex}
            style={styles.nonMobile.tabs}
        >
          <Tab value={0} label="Home" style={styles.nonMobile.tab} containerElement={<IndexLink to="/"/>} />
          <Tab value={1} label="About" style={styles.nonMobile.tab} containerElement={<Link to="about"/>} />
          <Tab value={2} label="Partners" style={styles.nonMobile.tab} containerElement={<Link to="partners"/>} />
          <Tab value={3} label="Blog" style={styles.nonMobile.tab} containerElement={<Link to="blog"/>} />
        </Tabs>
      );
    }
  }

}

export default NavTabs;
