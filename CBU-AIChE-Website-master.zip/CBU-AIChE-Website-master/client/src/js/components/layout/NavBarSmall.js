import React from 'react';
import {AppBar, IconButton} from 'material-ui';
import GroupAddIcon from 'material-ui/svg-icons/social/group-add';
import FloatingActionButton from 'material-ui/FloatingActionButton';

import NavTabs from "../layout/NavTabs";


class NavBarSmall extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      scrollPos: 0,
      navPos: 0,
      yDifference: 0,
    };

    this.handleScroll = this.handleScroll.bind(this);
  }

  componentDidMount() {
    window.addEventListener('scroll', this.handleScroll);
  }

  componentWillUnmount() {
    window.removeEventListener('scroll', this.handleScroll);
  }


  handleScroll = () => {
    let state = this.state;
    const currentPos = $(document).scrollTop();
    const navPos = $("#mNavBar").position().top;
    const yDifference = currentPos - state.scrollPos;

    state.yDifference = yDifference;
    state.navPos = navPos;
    state.scrollPos = currentPos;

    this.setState(state);
  }

  render() {
    var styles = {
      appBar: {
        flexWrap: 'wrap',
        // top: 0 - this.state.scrollPos,
        top:0,
        // position: 'fixed',
        transition: "all 0s",
      },
      // tabs: {
      //   width: '100%',
      //   height: '100%',
      // },
      // tab: {
      //   height: '100%',
      // },
      button: {
        right: 15,
        bottom: 15,
        position: 'fixed',
        zIndex: 11
      }
    };

    // if(this.state.scrollPos > 64) {
    //   styles.appBar.transition = "all .3s";
    // }
    if(this.state.scrollPos > 64) {
      styles.appBar.transition = "all .3s";
    }

    return (
      <div>
        <NavTabs navData={this.state} mobile={true} slideIndex={this.props.slideIndex}
          onScroll={this.handleScroll} onChangeIndex={this.props.onChangeIndex} />
        <a href="https://docs.google.com/forms/d/e/1FAIpQLScZoF5ORRalGQ52ALNDXikz3ogj5cU-FgAKX8Hk1jxWiZuUUQ/viewform?usp=sf_link" target="_blank">
          <FloatingActionButton style={styles.button} secondary={true}>
            <GroupAddIcon  />
          </FloatingActionButton>
        </a>
      </div>
    );
  }

}

export default NavBarSmall;
