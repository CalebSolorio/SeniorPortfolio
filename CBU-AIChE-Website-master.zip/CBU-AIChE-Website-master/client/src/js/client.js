import React from 'react';
import ReactDOM from "react-dom";

import Router from "./routing/Router";

import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import getMuiTheme from 'material-ui/styles/getMuiTheme';
import {lightBlue900, amber500} from 'material-ui/styles/colors';

import injectTapEventPlugin from 'react-tap-event-plugin';
injectTapEventPlugin();

const app = document.getElementById('app');

const muiTheme = getMuiTheme({
  palette: {
    primary1Color: lightBlue900,
    accent1Color: amber500,
  },
});

ReactDOM.render(
  <MuiThemeProvider muiTheme={muiTheme}>
    <Router />
  </MuiThemeProvider>,
app);
