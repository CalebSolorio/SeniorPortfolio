import React from "react";
import { Router as ReactRouter, Route, IndexRoute, hashHistory, browserHistory, useRouterHistory } from "react-router";
// import { createBrowserHistory } from 'history';

import Layout from "../routing/Layout";
import Home from "../pages/Home";
import About from "../pages/About";
import Partners from "../pages/Partners";
import Blog from "../pages/Blog";

class Router extends React.Component {
    constructor(props) {
        super(props);
    }
    
    render() {
      // const history = useRouterHistory(createBrowserHistory)({ queryKey: false });
      
      return (
        <ReactRouter history={hashHistory} >
          <Route path="/" component={Layout}>
            <IndexRoute component={Home} />
            <Route path="About" name="about" component={About} />
            <Route path="Partners" name="partners" component={Partners} />
            <Route path="Blog" name="blog" component={Blog} />
          </Route>
        </ReactRouter>
      );
    }
}

export default Router;