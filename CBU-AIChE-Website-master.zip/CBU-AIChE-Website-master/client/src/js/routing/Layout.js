import React from "react";
import { browserHistory } from "react-router";
import SwipeableViews from 'react-swipeable-views';

import Footer from "../components/layout/Footer";
import NavBarSmall from "../components/layout/NavBarSmall";
import NavBarLarge from "../components/layout/NavBarLarge";

import Home from "../pages/Home";
import About from "../pages/About";
import Partners from "../pages/Partners";
import Blog from "../pages/Blog";

const DOMAIN = "https://s3.amazonaws.com";
const PATH_ORIGIN = "/cbu-aiche/index.html#";
const TITLE = "AIChE at CBU";

export default class Layout extends React.Component {
  constructor(props) {
    super(props);

    let initialSelectedIndex = 0;

    switch(this.props.location.pathname) {
      case "/about":
        initialSelectedIndex = 1;
        break;
      case "/partners":
        initialSelectedIndex = 2;
        break;
      case "/blog":
        initialSelectedIndex = 3;
        break;
    }

    this.state = {
      slideIndex: initialSelectedIndex,
    };

    this.handleChangeIndex = this.handleChangeIndex.bind(this);
  }

  handleChangeIndex = (value) => {
    let address = '/';

    switch(value) {
      case 1:
        address += 'about';
        break;
      case 2:
        address += 'partners';
        break;
      case 3:
        address += 'blog';
        break;
    }

    browserHistory.push(PATH_ORIGIN + address);

    this.setState({
      slideIndex: value,
    });
  };

  render() {
    const { location } = this.props;
    const styles = {
      background: {
        background: '#37474F',
      },
      swipeable: {
        // height: 'auto',
      },
      slide: {
        overflow: 'hidden',
      },
      container: {
        marginTop: "60px",
      }
    };

    return (
      <div style={styles.background}>

        <div class="hide-on-large-only">
          <NavBarSmall title={TITLE} location={location}
            slideIndex={this.state.slideIndex} onChangeIndex={this.handleChangeIndex} />
        </div>

        <div class="hide-on-med-and-down">
          <NavBarLarge title={TITLE} location={location}
            slideIndex={this.state.slideIndex} onChangeIndex={this.handleChangeIndex} />
        </div>

        <SwipeableViews
          index={this.state.slideIndex}
          onChangeIndex={this.handleChangeIndex}
          style={styles.swipeable}
          slideStyle={styles.slide}
          resistance animateHeight
        >
          <div style={styles.container}>
            <Home />
          </div>
          <div style={styles.container}>
            <About />
          </div>
          <div style={styles.container}>
            <Partners />
          </div>
          <div style={styles.container}>
            <Blog />
          </div>
        </SwipeableViews>

        <Footer onClick={this.handleChangeIndex} pathOrigin={DOMAIN + PATH_ORIGIN}/>
      </div>

    );
  }
}
