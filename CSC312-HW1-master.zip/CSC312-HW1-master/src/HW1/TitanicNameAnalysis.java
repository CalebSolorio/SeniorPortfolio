package HW1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Created by Caleb Solorio on 1/18/17.
 */

public class TitanicNameAnalysis {
    private static final String FILE_PATH = "src/TitanicNames.txt";

    public static void main(String[] args) {
        List<String> passengerList = readFile(new File(FILE_PATH));
        passengerAnalysis(passengerList);
    }

    private static List readFile(File file) {
        List<String> list = new ArrayList();
        try {
            Scanner scanner = new Scanner(file);
            while(scanner.hasNext()) {
                list.add(scanner.nextLine());
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        return list;
    }

    private static void passengerAnalysis(List<String> passengers) {
        int passengerCount = 0;
        String longestName = "";
        boolean jonesAppearance = true;

        for(String passenger: passengers) {
            String name = passenger.split(" ")[0];
            if(name.length() > longestName.length()) {
                longestName = name;
            }
            if(name == "Jones") {
                jonesAppearance = true;
            }
            passengerCount++;
        }

        System.out.println(passengerReport(passengerCount, longestName, jonesAppearance));
    }

    private static String passengerReport(int passengerCount, String longestName, boolean jonesAppearance) {
        if(passengerCount > 0) {
            String report = "We have approximately " + passengerCount + " passengers on file. " +
                    "The longest name on file is " + longestName + ". ";
            if(jonesAppearance) {
                return report + "Someone with the last name 'Jones' is among the passengers.";
            }
            return report + "None of these passengers have the last name 'Jones'.";
        }

        return "There are no passengers to report on :(";
    }

}
