package HW5.tests;

import HW5.resources.SequentialSearchST;
import HW5.resources.Stopwatch;

/**
 * Created by caleb on 2/27/17.
 */
public class SequentialSearchTest {
    public static void main(String[] args) {
        int n = 1000;
        double[] insertTimes = new double[n];
        double[] searchTimes = new double[n];

        for(int i = 0; i < n; i++) {
            SequentialSearchST search = generateSearchTree(generateArray(i));
            insertTimes[i] = timeInsert(search);
            searchTimes[i] = timeSearch(search);
        }

        printResults(insertTimes, searchTimes);
    }

    public static int[] generateArray(int n) {
        int [] arr = new int[n];

        for(int i = 0; i < n; i++) {
            arr[i] = (int)(Math.random() * 101);
        }

        return arr;
    }

    public static SequentialSearchST generateSearchTree(int[] arr) {
        SequentialSearchST searchTree = new SequentialSearchST();

        for(int i = 0; i < arr.length; i++) {
            searchTree.put(i, arr[i]);
        }

        return searchTree;
    }

    public static double timeInsert(SequentialSearchST searchTree) {
        Stopwatch stopwatch = new Stopwatch();

        for(int i = 0; i < 100; i++) {
            for(int j = 0; j < searchTree.size(); j++) {
                searchTree.put(j, (int)(Math.random() * 101));
            }
        }

        return stopwatch.elapsedTime();
    }

    public static double timeSearch(SequentialSearchST searchTree) {
        Stopwatch stopwatch = new Stopwatch();

        for(int i = 0; i < 100; i++) {
            for(int j = 0; j < searchTree.size(); j++) {
                searchTree.get(j);
            }
        }
        return stopwatch.elapsedTime();
    }

    public static void printResults(double[] insertTimes, double[] searchTimes) {
        System.out.println("Execution times from " + insertTimes.length + " rounds of insertion:");
        for(double time: insertTimes) {
            System.out.println(time);
        }

        System.out.println("Execution times from " +searchTimes.length + " rounds of searching:");
        for(double time: searchTimes) {
            System.out.println(time);
        }
    }
}
