package edu.calbaptist.android.projectmeetings.java_phoenix_channels;

/**
 * Created by Eoin on 24/04/2015.
 */
public enum SocketState {
    CONNECTING,
    OPEN,
    CLOSING,
    CLOSED
}
