package edu.calbaptist.android.projectmeetings.java_phoenix_channels;

public enum SocketEvent {
    OPEN,
    CLOSE,
    ERROR,
    MESSAGE
}