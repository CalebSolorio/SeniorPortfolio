package edu.calbaptist.android.projectmeetings.java_phoenix_channels;

public interface ISocketCloseCallback {
    void onClose();
}
