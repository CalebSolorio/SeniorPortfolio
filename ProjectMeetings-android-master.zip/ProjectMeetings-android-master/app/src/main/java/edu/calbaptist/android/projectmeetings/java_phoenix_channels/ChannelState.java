package edu.calbaptist.android.projectmeetings.java_phoenix_channels;

public enum ChannelState {
    CLOSED,
    ERRORED,
    JOINED,
    JOINING
}
