package main;// Restaurant Homework
// Instructor-provided code.
// You SHOULD heavily modify this file to make it interface with your own classes.

import models.Party;
import models.Restaurant;
import models.Servers;
import models.Table;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.*;

/**
 * This class represents the text user interface (UI) for the restaurant
 * program, allowing the user to view and manage the restaurant and its objects.
 * @author Caleb Solorio
 * @version 1.0 (Feb 9 2017)
 */
public class RestaurantTextUI {
	// file name from which to read the restaurant data
	private static final String DEFAULT_RESTAURANT_FILENAME = "src/resources/tables.txt";
	private Restaurant restaurant;
	
	/**
	 * Constructs a new text user interface and Restaurant instance.
	 */
	public RestaurantTextUI() {
		System.out.println("Restaurant Simulator");
		restaurant = new Restaurant();
	}
	
	/**
	 * Reads the information about the restaurant from the default restaurant
	 * file.
	 * @return true if the data was read successfully; false if there were any errors
	 */
	public boolean readRestaurantData() {
		System.out.println("Reading restaurant data from '" + DEFAULT_RESTAURANT_FILENAME + "'");
        try {
            restaurant.readData(DEFAULT_RESTAURANT_FILENAME);
            return true;
        } catch (IOException e) {
            System.out.println("Unable to read data into the program. " +
                    "Check the file path and try again");
            e.printStackTrace();
            return false;
        }
	}

	/**
	 * Displays the main menu of choices and prompts the user to enter a choice.
	 * Once a valid choice is made, initiates other code to handle that choice.
	 */
	public void mainMenu() {
		displayOptions();

		while (true) {
			String choice = ValidInputReader.getValidString(
					"Main menu, enter your choice:",
					"^[sSaAdDrRpPtTcCwWqQ!?]$").toUpperCase();
			if (choice.equals("S")) {
				serversOnDuty();
			} else if (choice.equals("A")) {
				addServer();
			} else if (choice.equals("D")) {
				dismissServer();
			} else if (choice.equals("R")) {
				cashRegister();
			} else if (choice.equals("P")) {
				partyToBeSeated();
			} else if (choice.equals("T")) {
				tableStatus();
			} else if (choice.equals("C")) {
				checkPlease();
			} else if (choice.equals("W")) {
				waitingList();
			} else if (choice.equals("Q")) {
				break;
			} else if (choice.equals("?")) {
				displayOptions();
			} else if (choice.equals("!")) {
				rickRoll();
			}
			System.out.println();
		}
	}
	
	// Displays the list of key commands the user can use.
	private void displayOptions() {
		System.out.println();
		System.out.println("Main System Menu");
		System.out.println("----------------");
		System.out.println("S)ervers on duty");
		System.out.println("A)dd server");
		System.out.println("D)ismiss server");
		System.out.println("R)egister");
		System.out.println("P)arty has arrived");
		System.out.println("T)ables status");
		System.out.println("C)heck, please");
		System.out.println("W)aiting list");
		System.out.println("?) display this menu of choices again");
		System.out.println("Q)uit");
	}
	
	// Called when S key is pressed from main menu.
	// Displays all servers who are currently working.
	private void serversOnDuty() {
		System.out.println("Servers currently on duty:");
		Servers servers = restaurant.getServers();
		System.out.println(servers.toString());
	}

	// Prints out the number of servers available
	private void serverNumString() {
		System.out.println("Servers now available: " + restaurant.getServers().getSize());
	}
	
	// Called when A key is pressed from main menu.
	// Adds one more server to the system.
	private void addServer() {
		System.out.println("Adding a new server to our workforce:");
		restaurant.addServer();
		serverNumString();
	}
	
	// Called when D key is pressed from main menu.
	// Sends one server home for the night (if possible).
	private void dismissServer() {
		try {
            Servers servers = restaurant.getServers();
            int id = servers.getNextServerId();
            double tip = servers.getTip(id);

			restaurant.dismissServer();
			System.out.println("Dismissing a server:");
			System.out.println("Server #" + id + " cashed out with $" + tip + " in total tips");
			serverNumString();
		} catch(IllegalStateException e) {
			// when only one server remains with tables remaining,
			System.out.println("Sorry, the server cannot cash out now;");
			System.out.println("there are still tables remaining and this is the only server left.");
		} catch(EmptyStackException e) {
			// when there are no servers,
			System.out.println("No servers to dismiss");
		}
	}
	
	// Called when R key is pressed from main menu.
	// Displays how much money is in the restaurant's cash register.
	private void cashRegister() {
		System.out.println("Cash register:");

		System.out.println("Total money earned = $" +
				new DecimalFormat("0.00").format(restaurant.getRegisterTotal()));
	}
	
	// Called when T key is pressed from main menu.
	// Displays the current status of all tables.
	private void tableStatus() {
		System.out.println("Tables status:");

		List<Table> tables = restaurant.getTables();
		Collections.sort(tables, Comparator.comparingInt(Table::getId));

		for(Table table: tables) {
			System.out.println(table.toString());
		}
	}
	
	// Called when C key is pressed from main menu.
	// Helps process a party's check to leave the restaurant.
	private void checkPlease() {
		try {
			System.out.println("Send the check to a party that has finished eating:");
			String partyName = ValidInputReader.getValidString("Party's name?", "^[a-zA-Z '-]+$");

			double subtotal = ValidInputReader.getValidDouble("Bill subtotal?", 0.0, 9999.99);
			restaurant.setPartySubtotal(partyName, subtotal);
			double tip = ValidInputReader.getValidDouble("Tip?", 0.0, 9999.99);
			restaurant.setPartyTip(partyName, tip);
			int serverId = restaurant.getPartyServer(partyName);

			restaurant.chargeParty(partyName);

			DecimalFormat decimal = new DecimalFormat("0.00");
			System.out.println("Gave total of $" + decimal.format(subtotal * 1.1) + " to cash register.");
			System.out.println("Gave tip of $" + decimal.format(tip) + " to Server #" + serverId + ".");

			Table table = restaurant.checkWaitingList();

			if(table != null) {
				System.out.println("Seating from waiting list:");
				System.out.println(table.toString());
			} else {
				System.out.println("The table is now empty.");
			}
		} catch (IllegalArgumentException e) {
			System.out.println(e.getMessage());
		}
	}
	
	// Called when W key is pressed from main menu.
	// Displays the current waiting list, if any.
	private void waitingList() {
		System.out.println("Waiting list:");

		List<Party> waitingList = restaurant.getWaitingList();
		if(waitingList.size() > 0) {
			for(Party party: waitingList) {
				System.out.println(party.toString());
			}
		} else {
			// when there is nobody on the waiting list,
			System.out.println("empty");
		}
	}
	
	// Called when P key is pressed from main menu.
	// Helps seat a newly arriving party at a table in the restaurant.
	private void partyToBeSeated() {
		String partyName = ValidInputReader.getValidString("Party's name?", "^[a-zA-Z '-]+$");
		int partySize = ValidInputReader.getValidInt("How many people in the party?", 1, 99999);

		try {
			restaurant.addParty(partyName, partySize);
			Table table = restaurant.checkWaitingList();

			if(table != null) {
				System.out.println("Seating new party at table " + table.getId());
			} else {
				// when all tables large enough to accommodate this party are taken,
				System.out.println("Sorry, there is no open table that can seat this party now.");
				boolean wait = ValidInputReader.getYesNo("This party has been placed on the waiting list. " +
						"Is this okay? (y/n)");
				if(!wait) {
				    try {
                        restaurant.cancelParty(partyName);
                        System.out.println("Removed party from waiting list.");
                    } catch (IllegalArgumentException e) {
                        System.out.println(e.getMessage());
                    }
				}
			}
		} catch(EmptyStackException e) {
			System.out.println("Sorry, there are no servers here yet to seat this party");
			System.out.println("and take their orders.  Add servers and try again.");
		} catch(IllegalArgumentException e) {
			System.out.println(e.getMessage());
		}
	}
	
	
	// You know what this method does.
	private void rickRoll() {
		// TODO: tell you how I'm feeling; make you understand
		System.out.println("We're no strangers to love");
		System.out.println("You know the rules and so do I");
		System.out.println("A full commitment's what I'm thinking of");
		System.out.println("You wouldn't get this from any other guy");
		System.out.println("I just wanna tell you how I'm feeling");
		System.out.println("Gotta make you understand");
		System.out.println();
		System.out.println("Never gonna give you up");
		System.out.println("Never gonna let you down");
		System.out.println("Never gonna run around and desert you");
		System.out.println("Never gonna make you cry");
		System.out.println("Never gonna say goodbye");
		System.out.println("Never gonna tell a lie and hurt you");
	}
}
