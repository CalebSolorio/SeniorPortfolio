package test;

import models.Servers;
import org.junit.Assert;
import org.junit.Test;

import java.util.NoSuchElementException;

/**
 * This class holds the test cases for the Servers class.
 * @author Caleb Solorio
 * @version 1.0 (Feb 20 2017)
 */

public class ServerTest
{
    /**
     * Tests the getSize(), addServer(), and dismissServer() methods of the Servers class.
     */
    @Test(expected = NoSuchElementException.class)
    public void getSizeTest() {
        Servers servers = new Servers();
        int size1 = servers.getSize();
        servers.addServer();
        servers.addServer();
        int size2 = servers.getSize();
        servers.dismissServer();
        servers.dismissServer();
        int size3 = servers.getSize();

        // Should throw appropriate exception
        servers.dismissServer();

        Assert.assertTrue("Size should be zero initially", size1 == 0);
        Assert.assertTrue("Size should be 2 after adding", size2 == 2);
        Assert.assertTrue("Size should be zero after dismissals", size3 == 0);
    }

    /**
     * Tests the getNextServerId() method of the Servers class.
     */
    @Test(expected = NoSuchElementException.class)
    public void getNestServerIdTest() {
        Servers servers = new Servers();

        // Should throw exception
        servers.getNextServerId();

        servers.addServer();
        int id1a = servers.getNextServerId();
        servers.addServer();
        servers.addServer();
        int id1b = servers.getNextServerId();
        servers.dismissServer();
        int id2 = servers.getNextServerId();
        servers.dismissServer();
        int id3 = servers.getNextServerId();

        Assert.assertEquals("Both ids should equal 1", id1a, id1b);
        Assert.assertEquals("Id should equal 2", id2,  2);
        Assert.assertEquals("Id should equal 3", id3, 3);
    }

    /**
     * Tests the cycle() method of the Servers class.
     */
    @Test
    public void cycleTest() {
        Servers servers = new Servers();

        servers.addServer();
        servers.addServer();
        servers.addServer();
        int id1a = servers.getNextServerId();
        servers.cycle();
        int id2 = servers.getNextServerId();
        servers.cycle();
        int id3 = servers.getNextServerId();
        servers.cycle();
        int id1b = servers.getNextServerId();

        Assert.assertEquals("Both ids should equal 1", id1a, id1b);
        Assert.assertEquals("Id should equal 2", id2, 2);
        Assert.assertEquals("Id should equal 3", id3, 3);
    }

    /**
     * Tests the setTip() and getTip() methods of the Servers class.
     */
    @Test
    public void tipTest() {
        Servers servers = new Servers();

        servers.addServer();
        servers.addServer();
        servers.addServer();

        try {
            servers.setTip(1, -1);
            Assert.fail();
        } catch (IllegalArgumentException e) { }

        servers.setTip(1, 0);
        servers.setTip(2, 4.5);
        servers.setTip(2, .51);
        servers.setTip(3, 12.99);

        double tip1 = servers.getTip(1);
        double tip2 = servers.getTip(2);
        double tip3 = servers.getTip(3);

        Assert.assertEquals("Tip 1 should equal 0", 0, tip1, 0.0);
        Assert.assertEquals("Tip 2 should equal 0", 5.01, tip2, 0.0);
        Assert.assertEquals("Tip 3 should equal 12.99", 12.99, tip3, 0.0);
    }

    /**
     * Tests the toString() method of the Servers class.
     */
    @Test
    public void toStringTest() {
        Servers servers = new Servers();

        String string1Expected = "There are no servers on duty yet.";
        String string1Actual = servers.toString();

        servers.addServer();
        servers.addServer();
        servers.addServer();

        servers.setTip(2, 12.99);

        String string2Expected = "Server #1 ($0.00 in total tips)\n" +
                "Server #2 ($12.99 in total tips)\n" +
                "Server #3 ($0.00 in total tips)\n";
        String string2Actual = servers.toString();

        Assert.assertEquals("Incorrect string associated with no servers", string1Expected, string1Actual);
        Assert.assertEquals("Incorrect string associated with multiple servers", string2Expected, string2Actual);
    }

    /**
     * Tests the clone() method of the Servers class.
     */
    @Test
    public void cloneTest() {
        Servers servers = new Servers();
        Servers serversSame = servers;
        Servers serversClone = servers.clone();

        Assert.assertEquals("These Servers objects should reference the same place in memory",
                servers, serversSame);
        Assert.assertNotEquals("These Servers objects should reference different places in memory",
                servers, serversClone);
    }
}
