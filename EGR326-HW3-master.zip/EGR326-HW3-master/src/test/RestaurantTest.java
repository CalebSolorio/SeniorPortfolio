package test;

import models.Restaurant;
import models.Table;
import org.junit.Assert;
import org.junit.Test;

import java.io.IOException;
import java.util.EmptyStackException;
import java.util.List;
import java.util.NoSuchElementException;

/**
 * This class holds the test cases for the Restaurant class.
 * @author Caleb Solorio
 * @version 1.0 (Feb 20 2017)
 */

public class RestaurantTest {
    /**
     * Tests the getServers() and addServer() methods of the Restaurant class.
     */
    @Test
    public void getAddServersTest() {
        Restaurant restaurant = new Restaurant();
        int size1 = restaurant.getServers().getSize();
        restaurant.addServer();
        restaurant.addServer();
        int size2 = restaurant.getServers().getSize();

        Assert.assertEquals("Size 1 should be zero", 0 , size1);
        Assert.assertEquals("Size 1 should be zero", 2 , size2);
    }

    /**
     * Tests the readData() and getTables() methods of the Restaurant class.
     */
    @Test
    public void tableTest() {
        Restaurant restaurant = new Restaurant();
        List<Table> tableList1 = restaurant.getTables();

        try {
            restaurant.readData("../src/resources/fake-tables.txt");
            Assert.fail();
        } catch (IOException e) { }

        try {
            restaurant.readData("../src/resources/tables.txt");
            List<Table> tableList2 = restaurant.getTables();
            List<Table> tableList3 = restaurant.getTables();
            restaurant.readData("../src/resources/tables.txt");
            List<Table> tableList4 = restaurant.getTables();

            boolean ordered = true;
            for(int i = 1; i < tableList4.size(); i++) {
                if(tableList4.get(i).getSize() < tableList4.get(i-1).getSize()) {
                    ordered = false;
                    break;
                }
            }

            boolean notEquals = tableList2 == tableList3;
            boolean sizeEquals1 = tableList2.size() == tableList3.size();
            boolean sizeEquals2 = tableList3.size() == tableList4.size();

            Assert.assertTrue("Tables should be ordered", ordered);
            Assert.assertEquals("Empty list should have size zero", 0, tableList1.size());
            Assert.assertFalse("Table lists should reference different places in memory", notEquals);
            Assert.assertTrue("Table 2 and 3 should have equal sizes", sizeEquals1);
            Assert.assertTrue("Table 3 and 4 should have equal sizes", sizeEquals2);
        } catch (IOException e) { }
    }

    /**
     * Tests the addParty(), partyIsSeated(), partyIsWaiting(), and isValidPartySize() methods of the Restaurant class.
     */
    @Test
    public void addPartyTest() {
        Restaurant restaurant = new Restaurant();
        try {
            restaurant.readData("../src/resources/tables.txt");
        } catch (IOException e) {
            e.printStackTrace();
        }

        addPartyHelper(restaurant, "Caleb", 13, new EmptyStackException());
        restaurant.addServer();
        addPartyHelper(restaurant, "", 2, new IllegalArgumentException());
        addPartyHelper(restaurant, "Caleb", 13, new IllegalArgumentException());
        addPartyHelper(restaurant, "Caleb", 0, new IllegalArgumentException());
        addPartyHelper(restaurant, "Caleb", -1, new IllegalArgumentException());
        restaurant.addParty("Caleb", 4);
        addPartyHelper(restaurant, "Caleb", 4, new IllegalArgumentException());
        addPartyHelper(restaurant, "Caleb", 2, new IllegalArgumentException());
        restaurant.checkWaitingList();
        addPartyHelper(restaurant, "Caleb", 4, new IllegalArgumentException());
        addPartyHelper(restaurant, "Caleb", 2, new IllegalArgumentException());
    }

    // Helps with testing parties with invalid arguments.
    private void addPartyHelper(Restaurant restaurant, String name, int size, Exception expected) {
        try {
            restaurant.addParty(name, size);
            Assert.fail();
        } catch(Exception actual) {
            Assert.assertTrue("The correct exception should be of type " + expected.toString(),
                    actual.getClass() == expected.getClass());
        }
    }

    /**
     * Tests the cancelParty() and getWaitingList() methods of the Restaurant class.
     */
    @Test
    public void cancelPartyTest() {
        Restaurant restaurant = new Restaurant();
        try {
            restaurant.readData("../src/resources/tables.txt");
        } catch (IOException e) {
            e.printStackTrace();
        }
        restaurant.addServer();

        restaurant.addParty("Caleb", 2);
        restaurant.addParty("Solorio", 4);

        restaurant.cancelParty("Solorio");
        int size1 = restaurant.getWaitingList().size();

        try {
            restaurant.cancelParty("Solorio");
            Assert.fail();
        } catch (IllegalArgumentException e) { }

        restaurant.cancelParty("Caleb");
        int size2 = restaurant.getWaitingList().size();

        Assert.assertEquals("Size should be 1", 1, size1);
        Assert.assertEquals("Size should be 0", 0, size2);
    }

    /**
     * Tests the setSubtotal(), checkWaitingList(), chargeParty(),
     * and getRegisterTotal() methods of the Restaurant class.
     */
    @Test
    public void subtotalTest() {
        Restaurant restaurant = new Restaurant();
        try {
            restaurant.readData("../src/resources/tables.txt");
        } catch (IOException e) {
            e.printStackTrace();
        }
        restaurant.addServer();
        subtotalHelper(restaurant, "Caleb", 12.99);
        restaurant.addParty("Caleb", 2);
        restaurant.addParty("Solorio", 4);
        restaurant.checkWaitingList();
        restaurant.checkWaitingList();

        subtotalHelper(restaurant, "Solorio", -1);
        restaurant.setPartySubtotal("Solorio", 42.99);
        double amount = 2.49;
        restaurant.setPartySubtotal( "Solorio", amount);

        double total1 = restaurant.getRegisterTotal();
        restaurant.chargeParty("Caleb");
        restaurant.chargeParty("Solorio");
        double total2 = restaurant.getRegisterTotal();

        Assert.assertEquals("Total is incorrect", amount * 1.1, total2 - total1, 0.0);
    }

    // Helps with IllegalArgumentExeptions while setting subtotals.
    private void subtotalHelper(Restaurant restaurant, String name, double amount) {
        try {
            restaurant.setPartySubtotal(name, amount);
            Assert.fail();
        } catch (IllegalArgumentException e) { }
    }

    /**
     * Tests the getPartyServer(), getServers(), and setPartyTip() methods of the Restaurant class.
     */
    @Test
    public void serverTest() {
        Restaurant restaurant = new Restaurant();
        try {
            restaurant.readData("../src/resources/tables.txt");
        } catch (IOException e) {
            e.printStackTrace();
        }
        restaurant.addServer();
        restaurant.addServer();
        restaurant.addServer();
        restaurant.addParty("Caleb", 2);
        restaurant.addParty("Anthony", 3);
        restaurant.addParty("Solorio", 4);
        restaurant.addParty("Mitch", 6);

        tipHelper(restaurant, "Caleb", 2.49);

        restaurant.checkWaitingList();
        restaurant.checkWaitingList();
        restaurant.checkWaitingList();
        restaurant.checkWaitingList();

        serverIdHelper(restaurant, "Austin");

        int id1 = restaurant.getPartyServer("Caleb");
        int id2 = restaurant.getPartyServer("Anthony");
        int id3 = restaurant.getPartyServer("Solorio");
        int id4 = restaurant.getPartyServer("Mitch");

        tipHelper(restaurant, "Caleb's Mom", 12.99);
        tipHelper(restaurant, "Anthony", -1);

        restaurant.setPartyTip("Caleb", 0);
        restaurant.setPartyTip("Caleb", 2);
        restaurant.setPartyTip("Solorio", 12.34);
        restaurant.setPartyTip("Mitch", 12.99);

        restaurant.chargeParty("Caleb");
        restaurant.chargeParty("Anthony");
        restaurant.chargeParty("Solorio");
        restaurant.chargeParty("Mitch");

        double server1Tip = restaurant.getServers().getTip(1);
        double server2Tip = restaurant.getServers().getTip(2);
        double server3Tip = restaurant.getServers().getTip(3);

        Assert.assertNotEquals("The two clones should reference different spots in memory",
                restaurant.getServers(), restaurant.getServers());
        Assert.assertEquals("Server 1 should be serving Caleb", 1, id1);
        Assert.assertEquals("Server 1 should be serving Anthony", 2, id2);
        Assert.assertEquals("Server 1 should be serving Solorio", 3, id3);
        Assert.assertEquals("Server 1 should be serving Mitch", 1, id4);
        Assert.assertEquals("Server 1 should have $14.99 in tips", 14.99, server1Tip, 0.0);
        Assert.assertEquals("Server 1 should have $0.00 in tips", 0, server2Tip, 0.0);
        Assert.assertEquals("Server 1 should have $12.99 in tips", 12.34, server3Tip, 0.0);
    }

    // Helps with IllegalArgumentExeptions while getting a party's server id.
    private void serverIdHelper(Restaurant restaurant, String name) {
        try {
            restaurant.getPartyServer(name);
            Assert.fail();
        } catch (IllegalArgumentException e) { }
    }

    // Helps with IllegalArgumentExeptions while setting subtotals.
    private void tipHelper(Restaurant restaurant, String name, double amount) {
        try {
            restaurant.setPartyTip(name, amount);
            Assert.fail();
        } catch (IllegalArgumentException e) { }
    }

    /**
     * Tests the dismissServer() method of the Restaurant class.
     */
    @Test
    public void dismissServerTest() {
        Restaurant restaurant = new Restaurant();
        try {
            restaurant.readData("../src/resources/tables.txt");
        } catch (IOException e) {
            e.printStackTrace();
        }
        dismissServerHelper(restaurant, new NoSuchElementException());
        restaurant.addServer();
        restaurant.addServer();
        restaurant.addParty("Caleb", 2);
        restaurant.addParty("Anthony", 3);
        restaurant.addParty("Solorio", 4);
        restaurant.checkWaitingList();
        restaurant.checkWaitingList();
        restaurant.checkWaitingList();
        restaurant.addServer();
        restaurant.dismissServer();
        restaurant.dismissServer();
        dismissServerHelper(restaurant, new IllegalStateException());

        int id1 = restaurant.getPartyServer("Caleb");
        int id2 = restaurant.getPartyServer("Anthony");
        int id3 = restaurant.getPartyServer("Solorio");

        Assert.assertEquals("Server 1 should be waiting on the Caleb party", 1, id1);
        Assert.assertEquals("Server 1 should be waiting on the Anthony party", 1, id2);
        Assert.assertEquals("Server 1 should be waiting on the Solorio party", 1, id3);

    }

    // Helps with testing parties with invalid arguments.
    private void dismissServerHelper(Restaurant restaurant, Exception expected) {
        try {
            restaurant.dismissServer();
            Assert.fail();
        } catch(Exception actual) {
            Assert.assertTrue("The correct exception should be of type " + expected.toString(),
                    actual.getClass() == expected.getClass());
        }
    }

}
