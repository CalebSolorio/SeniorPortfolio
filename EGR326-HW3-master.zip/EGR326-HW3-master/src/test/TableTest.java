package test;

import models.Party;
import models.Table;
import org.junit.Assert;
import org.junit.Test;

/**
 * This class holds the test cases for the Table class.
 * @author Caleb Solorio
 * @version 1.0 (Feb 20 2017)
 */

public class TableTest {
    /**
     * Tests the constructor, getId(), and getSize() methods of the Table class.
     */
    @Test
    public void constructorGetterTest() {
        constructorHelper(0);
        constructorHelper(-1);

        Table table = new Table(13, 13);
        int id = table.getId();
        int size = table.getSize();

        Assert.assertEquals("Id should equal 13", 13, id);
        Assert.assertEquals("Size should equal 13", 13, size);
    }

    // Helps test invalid sizes.
    private void constructorHelper(int size) {
        try {
            Table tableFail = new Table(1, size);
            Assert.fail();
        } catch (IllegalArgumentException e) {}
    }

    /**
     * Tests the setParty() and getParty() methods of the Table class.
     */
    @Test
    public void partyTest() {
        Table table = new Table(13, 13);

        Party partyNull = table.getParty();
        Party party = new Party("Caleb", 2);
        table.setParty(party);
        Party partyClone = table.getParty();

        Assert.assertNull("The returned party should be null", partyNull);
        Assert.assertEquals("Party names should be equal", party.getName(), partyClone.getName());
        Assert.assertEquals("Party sizes should be equal", party.getSize(), partyClone.getSize());
    }

    /**
     * Tests the toString() method of the Table class.
     */
    @Test
    public void toStringTest() {
        Table table = new Table(13, 13);

        String string1Expected = "Table 13 (13-top): empty";
        String string1Actual = table.toString();

        Party party = new Party("Caleb", 2);
        table.setParty(party);

        String string2Expected = "Table 13 (13-top): Caleb - Party of 2";
        String string2Actual = table.toString();

        Assert.assertEquals("Unequal strings", string1Expected, string1Actual);
        Assert.assertEquals("Unequal strings", string2Expected, string2Actual);
    }

    /**
     * Tests the clone() method of the Table class.
     */
    @Test
    public void cloneTest() {
        Table table = new Table(13, 13);
        Table tableSame = table;
        Table tableClone = table.clone();

        Assert.assertEquals("These Table objects should reference the same place in memory",
                table, tableSame);
        Assert.assertNotEquals("These Table objects should reference different places in memory",
                table, tableClone);
    }
}
