package test;

import models.Party;
import org.junit.Assert;
import org.junit.Test;

/**
 * This class stores test cases for the Party class.
 * @author Caleb Solorio
 * @version 1.0 (Feb 9 2017)
 */

public class PartyTest {
    /**
     * Tests the conditions under which a constructor fails.
     */
    @Test
    public void constructorFailTest() {
        Party party = new Party("Caleb", 1);
        constructorHelper("Caleb", 0);
        constructorHelper("Caleb", -1);
        constructorHelper("", 2);
    }

    // Helps assert failed constructions.
    private void constructorHelper(String name, int size) {
        try {
            Party party = new Party(name, size);
            Assert.fail("Construction of the party should fail with name " +
                    name + " and size " + size);
        } catch (IllegalArgumentException e) { }
    }

    /**
     * Tests the getter and setter of the subtotal variable.
     */
    @Test
    public void subtotalTest() {
        Party party = new Party("Caleb", 1);

        try {
            party.setSubtotal(-1);
            Assert.fail();
        } catch (IllegalArgumentException e) { }

        double[] input = {20, 12.99, 0};
        double[] expected = {20, 12.99, 0};
        for(int i = 0; i < input.length; i++) {
            party.setSubtotal(input[i]);
            Assert.assertEquals("Incorrect result for test #" + i, expected[i], party.getSubtotal(), 0.0);
        }
    }

    /**
     * Tests the getter and setter of the tip variable.
     */
    @Test
    public void tipTest() {
        Party party = new Party("Caleb", 1);

        try {
            party.setTip(-1);
            Assert.fail();
        } catch (IllegalArgumentException e) { }

        double[] input = {20, 12.99, 0};
        double[] expected = {20, 12.99, 0};
        for(int i = 0; i < input.length; i++) {
            party.setTip(input[i]);
            Assert.assertTrue("Incorrect result for test #" + i, party.getTip() == expected[i]);
        }
    }

    /**
     * Tests the getter and setter of the server id.
     */
    @Test
    public void serverIdTest() {
        Party party = new Party("Caleb", 1);

        party.setServerId(20);
        serverIdHelper(party, 0);
        serverIdHelper(party, -1);

        Assert.assertTrue("Id of 20 should be acceptable", party.getServerId() == 20);
    }

    // Helps with invalid ids
    private void serverIdHelper(Party party, int id) {
        try{
            party.setServerId(id);
            Assert.fail("Construction of the party with id " +
                    id + " should fail.");
        } catch (IllegalArgumentException e) { }
    }

    /**
     * Tests the getter and setter of the name and size variables
     */
    @Test
    public void nameSizeTest() {
        Party party = new Party("Caleb", 13);

        Assert.assertTrue("Incorrect name", party.getName().equals("Caleb"));
        Assert.assertTrue("Incorrect size", party.getSize() == 13);
    }

    /**
     * Tests the toString method of the Party class.
     */
    @Test
    public void toStringTest() {
        Party party = new Party("Caleb", 13);

        boolean noServerString = party.toString().equals("Caleb - Party of 13");
        party.setServerId(8);
        boolean serverString = party.toString().equals("Caleb - Party of 13 - Server #8");

        Assert.assertTrue("String without server id is incorrect", noServerString);
        Assert.assertTrue("String with server id is incorrect", serverString);
    }



}
