package models;

import java.io.*;
import java.util.*;

/**
 * This class handles the logistics of a restaurant.
 * @author Caleb Solorio
 * @version 1.0 (Feb 17 2017)
 */

public class Restaurant {
    private List<Table> tables;
    private List<Party> waitingList;
    private Servers servers;
    private double registerTotal;

    /**
     * Initializes a new instance of the Restaurant class.
     */
    public Restaurant() {
            tables = new ArrayList();
            waitingList = new ArrayList();
            servers = new Servers();
            registerTotal = 0;
    }

    /**
     * Reads data from a file into a List of Table objects.
     * @param filePath The string detailing the location of the file.
     * @throws IOException if the file cannot be found or read.
     */
    public void readData(String filePath) throws IOException {
        tables.clear();
        BufferedReader reader = new BufferedReader(new FileReader(filePath));

        reader.readLine();
        String[] tableStrings = reader.readLine().split(" ");
        for(int i = 0; i < tableStrings.length; i++) {
            tables.add(new Table(i + 1, Integer.parseInt(tableStrings[i])));
        }
        Collections.sort(tables, Comparator.comparingInt(Table::getSize));
    }

    /**
     * Gets the active servers of the restaurant.
     * @return the Servers object associated with this object.
     */
    public Servers getServers() {
        return servers.clone();
    }

    /**
     * Adds an active server into the rotation.
     */
    public void addServer() {
        servers.addServer();
    }

    /**
     * Verifies there are no more parties or multiple servers available,
     * then removes a server from the rotation.
     * @throws IllegalStateException if there are parties seated and only one active server.
     */
    public void dismissServer() throws IllegalArgumentException {
        int id = servers.getNextServerId();

        Stack<Party> parties = new Stack<>();
        for(Table table: tables) {
            if(table.getParty() != null && table.getParty().getServerId() == id) {
                parties.push(table.getParty());
            }
        }

        if(parties.size() > 0 && servers.getSize() == 1) {
            throw new IllegalStateException("Last server cannot leave if they are still serving parties");
        }

        servers.dismissServer();

        while(!parties.isEmpty()) {
            parties.pop().setServerId(servers.getNextServerId());
            servers.cycle();
        }
    }

    /**
     * Gets the data from all tables.
     * @return a clone of the tables List.
     */
    public List<Table> getTables() {
        return new ArrayList<>(tables);
    }

    /**
     * Adds a party to either a table or to the waiting list. Cycle the servers
     * @param name The proposed name of the party.
     * @param size The proposed size of the party.
     * @throws EmptyStackException if no servers are available.
     * @throws IllegalArgumentException if the proposed name already exists or is empty without spaces
     * (or if the size of the party is too big).
     */
    public void addParty(String name, int size) throws EmptyStackException, IllegalArgumentException{
        if(servers.getSize() == 0) {
            throw new EmptyStackException();
        }

        if(partyIsWaiting(name) || partyIsSeated(name)) {
            throw new IllegalArgumentException("We already have a party with that name in the restaurant. \n" +
                    "Please try again with a unique party name.");
        }

        if(!isValidPartySize(size)) {
            throw new IllegalArgumentException("Sorry, the restaurant is unable to seat a party of " + size);
        }

        waitingList.add(new Party(name, size));
    }

    /**
     * Removes a party from the waiting list.
     * @param name The name of the party to be removed.
     * @throws IllegalArgumentException if no Party with the given name was found.
     */
    public void cancelParty(String name) throws IllegalArgumentException {
        Party cancelledParty = null;
        for(Party party: waitingList) {
            if(party.getName().equals(name)) {
                cancelledParty = party;
            }
        }

        if(cancelledParty != null) {
            waitingList.remove(cancelledParty);
        } else {
            throw new IllegalArgumentException("No party with the name '" +
                    name + "' was found on the waiting list.");
        }
    }

    /**
     * Set the subtotal of a specified party.
     * @param name The name of the party.
     * @param amount The desired subtotal amount.
     * @throws IllegalArgumentException if no party with the given name was found or if amount was too low.
     */
    public void setPartySubtotal(String name, double amount) throws IllegalArgumentException {
        Table table = getTableByParty(name);
        if(table != null) {
            Party party = table.getParty();
            party.setSubtotal(amount);
        } else {
            throw new IllegalArgumentException("There is no party with the name '" +
                    name + "' currently sitting at a table.");
        }
    }

    /**
     * Set the tip amount of a specified party.
     * @param name The name of the party.
     * @param amount The desired tip amount.
     * @throws IllegalArgumentException if no party with the given name was found.
     */
    public void setPartyTip(String name, double amount) throws IllegalArgumentException {
        Table table = getTableByParty(name);
        if(table != null) {
            Party party = table.getParty();
            party.setTip(amount);
        } else {
            throw new IllegalArgumentException("There is no party with the name '" +
                    name + "' currently sitting at a table.");
        }
    }

    /**
     * Gets the server associated with a specified party.
     * @param name The name of the party.
     * @return the id of the party's server.
     */
    public int getPartyServer(String name) {
        Table table = getTableByParty(name);
        if(table != null) {
            Party party = getTableByParty(name).getParty();
            if(party != null) {
                return party != null ? party.getServerId() : 0;
            }
        }
        throw new IllegalArgumentException("No sitting party exists with this name.");
    }

    /**
     * Bills a party for the set amount. Removes them from the table.
     * @param name The name of the party to bill.
     * @throws IllegalArgumentException if no party with the given name exists.
     */
    public void chargeParty(String name) throws IllegalArgumentException {
        Table table = getTableByParty(name);
        if(table != null) {
            Party party = table.getParty();
            double subTotal = party.getSubtotal() * 1.1;
            double tipAmount = party.getTip();
            int serverId = party.getServerId();

            registerTotal += subTotal;
            servers.setTip(serverId, tipAmount);
            table.setParty(null);
        } else {
            throw new IllegalArgumentException("There is no party with the name '" +
                    name + "' currently sitting at a table.");
        }
    }

    /**
     * Gets the amount of money currently in the register.
     * @return the value of this object's registerTotal attribute.
     */
    public double getRegisterTotal() {
        return registerTotal;
    }

    /**
     * Gets the current waiting list of the restaurant.
     * @return a clone of the waitingList List.
     */
    public List<Party> getWaitingList() { return new ArrayList<>(waitingList); }

    /**
     * Checks to see if any tables are available. If so, a party from the waiting list is seated.
     * @return the clone of the Table the newly-seated party is associated with.
     */
    public Table checkWaitingList() {
        Table returnTable = null;

        if(servers.getSize() > 0) {
            Party seatedParty = null;

            loop:
            for(Party party: waitingList) {
                for(Table table: tables) {
                    if(table.getParty() == null && table.getSize() >= party.getSize()) {
                        table.setParty(party);
                        party.setServerId(servers.getNextServerId());
                        servers.cycle();
                        seatedParty = party;
                        returnTable = table.clone();
                        break loop;
                    }
                }
            }

            if(seatedParty != null) {
                waitingList.remove(seatedParty);
            }
        }

        return returnTable;
    }

    // Checks to see if a seated party matches the given name.
    private boolean partyIsSeated(String name) {
        return getTableByParty(name) != null ? true : false;
    }

    // Checks to see if a waiting party matches the given name.
    private boolean partyIsWaiting(String name) {
        for(Party party: waitingList) {
            if(name.equals(party.getName())) {
                return true;
            }
        }

        return false;
    }

    // Verifies that a table can seat a party of the given size.
    public boolean isValidPartySize(int size) {
        for(Table table: tables) {
            if(size <= table.getSize()) {
                return true;
            }
        }

        return false;
    }

    // Find a table by its party name and return the associated Table object.
    private Table getTableByParty(String name) {
        for(Table table: tables) {
            Party party = table.getParty();
            if(party != null && name.equals(party.getName())) {
                return table;
            }
        }

        return null;
    }
}
