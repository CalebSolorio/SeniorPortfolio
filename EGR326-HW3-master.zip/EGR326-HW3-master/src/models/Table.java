package models;

/**
 * This class stores information about a specific table entity.
 * @author Caleb Solorio
 * @version 1.0 (Feb 17 2017)
 */

public class Table implements Cloneable {
    private int id;
    private int size;
    private Party party;

    /**
     * Initializes and instance of Table
     * @param id The id value associated with the table.
     * @param size The number of people the table can seat.
     * @throws IllegalArgumentException if size is not greater than zero.
     */
    public Table(int id, int size) throws IllegalArgumentException {
        if(size > 0) {
            this.id = id;
            this.size = size;
        } else {
            throw new IllegalArgumentException("The size of a table should be greater than 0");
        }
    }

    /**
     * Gets the id of a Table object.
     * @return the id attribute of this object.
     */
    public int getId() {
        return id;
    }

    /**
     * Gets the size of a Table object.
     * @return the size attribute of this object.
     */
    public int getSize() {
        return size;
    }

    /**
     * Sets the Party seated at this Table object.
     * @param party The party object to store.
     */
    public void setParty(Party party) {
        this.party = party;
    }

    /**
     * Gets the Party object belonging to this object.
     * @return the party attribute of this object.
     */
    public Party getParty() {
        try {
            return party;
        } catch (NullPointerException e) {
            return null;
        }
    }

    /**
     * Summarizes the various attributes of this Table object.
     * @return the summary in type String.
     */
    public String toString() {
        String string = "Table " + id + " (" + size + "-top): ";

        if(party != null) {
            string += party.toString();
        } else {
            string += "empty";
        }

        return string;
    }

    /**
     * Clones this Servers object.
     * @return the deep copy of this object.
     */
    public Table clone() {
        Table copy = null;

        try {
            copy = (Table) super.clone();
            if (party != null) {
                copy.party = party.clone();
            }
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }

        return copy;
    }
}
