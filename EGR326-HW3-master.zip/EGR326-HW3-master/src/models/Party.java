package models;

/**
 * This class stores information about a specific party entity.
 * @author Caleb Solorio
 * @version 1.0 (Feb 17 2017)
 */

public class Party implements Cloneable {
    private String name;
    private int size;
    private double subTotal;
    private double tip;
    private int serverId;

    /**
     * Constructs a new instance of party.
     * @param name The desired name for the party.
     * @param size The number of people in the party.
     * @throws IllegalArgumentException if the size or name length is zero or less.
     */
    public Party(String name, int size) {
        if(size > 0 && name.replaceAll(" ", "").length() > 0) {
            this.name = name;
            this.size = size;
            this.subTotal = 0;
            this.tip = 0;
            this.serverId = 0;
        } else {
            throw new IllegalArgumentException("Invalid name or size");
        }
    }

    /**
     * Sets the subtotal of the party
     * @param amount The amount the subtotal should be changed for.
     * @throws IllegalArgumentException if amount is too low.
     */
    public void setSubtotal(double amount) throws IllegalArgumentException {
        if(amount >= 0) {
            subTotal = amount;
        } else {
            throw new IllegalArgumentException("Amount should not be negative");
        }
    }

    /**
     * Gets the subtotal of the party.
     * @return the subtotal of the party.
     */
    public double getSubtotal() {
        return subTotal;
    }

    /**
     * Sets the tip amount of the party.
     * @param amount The amount the party would like to tip their server
     * @throws IllegalArgumentException if amount is less than zero.
     */
    public void setTip(double amount) throws IllegalArgumentException {
        if(amount >= 0) {
            tip = amount;
        } else {
            throw new IllegalArgumentException("Tip should not be negative");
        }
    }

    /**
     * Gets the amount the party would like to tip.
     * @return the tip amount.
     */
    public double getTip() {
        return tip;
    }

    /**
     * Sets the id of the party's server
     * @param serverId The id of the employee serving the party.
     * @throws IllegalArgumentException if the given id is zero or less.
     */
    public void setServerId(int serverId) throws IllegalArgumentException {
        if(serverId > 0) {
            this.serverId = serverId;
        } else {
            throw new IllegalArgumentException("Server Id should not be negative");
        }
    }

    /**
     * Gets the id of the person serving them.
     * @return the server's id.
     * @throws NullPointerException if the party has no server.
     */
    public int getServerId() throws NullPointerException {
        return serverId;
    }

    /**
     * Gets the name of the Party.
     * @return the Party's name.
     */
    public String getName() {
        return name;
    }

    /**
     * Gets the size of the party.
     * @return the party's size.
     */
    public int getSize() {
        return size;
    }

    /**
     * Summarizes this object in String form.
     * @return the summary.
     */
    public String toString() {
        String string = name + " - Party of " + size;
        if(serverId > 0) {
            string += " - Server #" + serverId;
        }

        return string;
    }

    /**
     * Get a copy of a Party.
     * @return a clone of this object.
     */
    public Party clone() {
        Party copy = null;

        try {
            copy = (Party) super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }

        return copy;
    }
}
