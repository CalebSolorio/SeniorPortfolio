package models;

import java.text.DecimalFormat;
import java.util.*;

/**
 * This class holds the data of all active servers in the restaurant.
 * @author Caleb Solorio
 * @version 1.0 (Feb 17 2017)
 */

public class Servers implements Cloneable {
    private Map serverMap;
    private int serverNum;

    /**
     * Initializes a new server map an sets the number of servers to zero.
     */
    public Servers() {
        serverMap = new LinkedHashMap();
        serverNum = 0;
    }

    /**
     * Increments the number of servers and adds a new server to the map.
     */
    public void addServer() {
        serverNum++;
        serverMap.put(serverNum, 0.0);
    }

    /**
     * Removes a server from the map.
     * @throws NoSuchElementException if there are no active servers available.
     * @throws NullPointerException if, for whatever reason, the integrity of the id is compromised.
     */
    public void dismissServer() throws NoSuchElementException, NullPointerException {
        int id = getNextServerId();
        serverMap.remove(id);
    }

    /**
     * Moves a server to the back of the line, round-robin style.
     * @throws NoSuchElementException if there are no active servers available.
     * @throws NullPointerException if, for whatever reason, the integrity of the id is compromised.
     */
    public void cycle() throws NoSuchElementException, NullPointerException {
        int id = getNextServerId();
        double tipTotal = (Double) serverMap.get(id);
        serverMap.remove(id);
        serverMap.put(id, tipTotal);
    }

    /**
     * Gets the number of servers available.
     * @return the size of the server map.
     */
    public int getSize() {
        return serverMap.size();
    }

    /**
     * Get's the server next in line to host a party.
     * @return The first key value of the server map.
     * @throws NoSuchElementException if no active servers exist.
     */
    public int getNextServerId() throws NoSuchElementException {
        return (int) serverMap.keySet().iterator().next();
    }

    /**
     * Distributes a tip to the specified server.
     * @param key The id of the server.
     * @param amount The amount to be given to the specified server.
     * @throws IllegalArgumentException if the amount is negative.
     * @throws NullPointerException if no server correlates with the given key.
     */
    public void setTip(int key, double amount) throws IllegalArgumentException, NullPointerException {
        if(amount >= 0) {
            serverMap.put(key, getTip(key) + amount);
        } else {
            throw new IllegalArgumentException("Amount should be greater than or equal to zero");
        }
    }

    /**
     * Get's the tip amount of a specified server.
     * @param key The id of the server.
     * @return the amount the server can cash out with.
     * @throws NullPointerException if no server correlates with the given key.
     */
    public double getTip(int key) throws NullPointerException {
        return (Double) serverMap.get(key);
    }

    /**
     * Summarizes the various waiters on duty, if any, and their tip amounts.
     * @return the summary in type String.
     */
    public String toString() {
        if(serverMap.size() > 0) {
            Iterator keyIterator = serverMap.keySet().iterator();
            StringBuilder returnString = new StringBuilder();

            while(keyIterator.hasNext()) {
                int key = (Integer) keyIterator.next();
                returnString.append("Server #" + key + " ($" +
                        new DecimalFormat("0.00").format(serverMap.get(key)) + " in total tips)\n");
            }

            return returnString.toString();
        }

        return "There are no servers on duty yet.";
    }

    /**
     * Clones this Servers object.
     * @return the deep copy of this object.
     */
    public Servers clone() {
        Servers copy = null;
        try {
            copy = (Servers) super.clone();
            copy.serverMap = new LinkedHashMap(this.serverMap);
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }

        return copy;
    }
}
