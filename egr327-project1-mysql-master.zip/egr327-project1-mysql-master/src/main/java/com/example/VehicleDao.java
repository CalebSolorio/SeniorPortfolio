package com.example;

import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

/**
 * Created by Caleb Solorio on 11/4/2016.
 */

/**
 * Data Access Object - provide some specific data operations without exposing details of the data.
 * Acces data for the Vehicle entity.
 * Repository annotation allows Spring to find and configure the DAO.
 * Transactional annotation will cause Spring to call begin() and commit()
 * at the start/end of the method. If exception occurs it will also call rollback()
 */

@Repository
@Transactional
public class VehicleDao {

    // PersistenceContext annotation used to specify there is a database source.
    // EntityManager is used to create and remove persistent entity instances.
    // to find entities by their primary key, and to query over entities.
    @PersistenceContext
    private EntityManager entityManager;

    // Insert Vehicle into the database.
    public void create(Vehicle vehicle) {
        entityManager.persist(vehicle);
    }

    // Insert Vehicle with the id passed-in.
    public Vehicle getById(int id) {
        return entityManager.find(Vehicle.class, id);
    }

    // Update vehicle in the database.
    public Vehicle update(Vehicle vehicle) {
        entityManager.merge(vehicle);
        return vehicle;
    }

    // Delete vehicle from the database.
    public void delete(int id) {
        Vehicle vehicle = this.getById(id);
        entityManager.remove(vehicle);
    }
}
