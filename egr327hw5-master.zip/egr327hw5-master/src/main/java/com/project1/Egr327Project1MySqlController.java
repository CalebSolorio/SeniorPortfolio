package com.project1;

import com.project1.hw5.pt1.Timed;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;


/**
 * Created by Caleb Solorio on 10/28/2016.
 */
@RestController
public class Egr327Project1MySqlController {

    @Autowired
    private VehicleDao vehicleDao;

    @Timed
    @RequestMapping(value="/addVehicle", method = RequestMethod.POST)
    public Vehicle addVehicle(@RequestBody Vehicle vehicle) throws IOException {
        vehicleDao.create(vehicle);
        return vehicle;
    }

    @Timed
    @RequestMapping(value = "/getVehicle/{id}", method = RequestMethod.GET)
    public Vehicle getVehicle(@PathVariable("id") int id) throws IOException {
        return vehicleDao.getById(id);
    }

    @Timed
    @RequestMapping(value = "/updateVehicle", method = RequestMethod.PUT)
    public Vehicle updateVehicle(@RequestBody Vehicle vehicle) throws IOException {
        vehicleDao.update(vehicle);
        return vehicle;
    }

    @Timed
    @RequestMapping(value = "/deleteVehicle/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<String> deleteVehicle(@PathVariable("id") int id) throws IOException {
        vehicleDao.delete(id);
        return ResponseEntity.ok("Vehicle with id " + id + " deleted.");
    }

}
