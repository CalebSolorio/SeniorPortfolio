package com.project1.hw5.pt2;

import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created by Caleb Solorio on 11/30/2016.
 */

@Component
@EnableAspectJAutoProxy
public class Song {

    private String artist;
    private String title;
    private String link;
    private List<List<String>> verses;
    private List<List<String>> bridges;
    private List<String> chorus;

    public Song() {}

    public Song(String a, String t, String l, List<List<String>> v,
                List<List<String>> b, List<String> c) {
        setArtist(a);
        setTitle(t);
        setLink(l);
        setVerses(v);
        setBridges(b);
        setChorus(c);
    }

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public List<String> getVerseLines(int i) {
        return verses.get(i);
    }

    public int getVerseNum() {
        return verses.size();
    }

    public void setVerses(List<List<String>> verses) {
        this.verses = verses;
    }

    public List<String> getBridgeLines(int i) {
        return bridges.get(i);
    }

    public void setBridges(List<List<String>> bridges) {
        this.bridges = bridges;
    }

    public List<String> getChorus() {
        return chorus;
    }

    public void setChorus(List<String> chorus) {
        this.chorus = chorus;
    }
}
