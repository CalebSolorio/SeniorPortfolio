package com.project1.hw5.pt2;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * Created by Caleb Solorio on 11/30/2016.
 */

@Component
public class Rick {

    private static Song song;
    private static int verseCount = -1;
    private static int verseType = 0;

    public Rick(){}

    @RickRoll
    @Scheduled(fixedRate = 90000)
    public void roll() throws IOException {
        ObjectMapper mapper = new ObjectMapper();

        //JSON from file to Song object
        song = mapper.readValue(new File("./lyrics.json"), Song.class);
        verseCount = -1;
        verseType = 0;
    }

    @Header
    @Scheduled(fixedRate = 90000, initialDelay = 10)
    public void header() {
        title();
        artist();
    }

    private void title() {
        String title = song.getTitle().toUpperCase();
        System.out.println(title);
    }

    private void artist() {
        String artist = song.getArtist().toUpperCase();
        System.out.println("by " + artist);
    }

    @VerseType
    @Scheduled(fixedRate = 10000, initialDelay = 20)
    public int getNextVerseType() {
        int newVerseType = (verseCount + 1) % 3;
        if(newVerseType != verseType) {
            verseType = newVerseType;
            return newVerseType;
        }

        return 0;
    }

    @Verse
    @Scheduled(fixedRate = 10000, initialDelay = 30)
    public List<String> getVerses() {
        verseCount++;
        if (verseCount <= song.getVerseNum()) {
            List<String> verses = song.getVerseLines(verseCount);
            return verses;
        }

        return null;
    }

    @Link
    @Scheduled(fixedRate = 90000, initialDelay = 85000)
    public String link() throws IOException {
        String link = song.getLink();

        Runtime.getRuntime()
                .exec(new String[]{
                        "cmd",
                        "/c",
                        "start chrome " + link
                });

        return link;
    }

}
