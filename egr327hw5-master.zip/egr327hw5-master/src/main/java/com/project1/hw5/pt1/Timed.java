package com.project1.hw5.pt1;

/**
 * Created by Caleb Solorio on 11/30/2016.
 */

public @interface Timed {
}
