package com.project1.hw5.pt2;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created by Caleb Solorio on 11/30/2016.
 */

@Component
@Aspect
public class SongAspect {

    @Pointcut("execution(* com.project1..*(..))")
    public  void allMethods() {}

    @Before("allMethods() && @annotation(com.project1.hw5.pt2.RickRoll)")
    public void rickRoll() throws Throwable {
        System.out.println("COMMENCING RICK ROLL");
    }

    @Around("allMethods() && @annotation(com.project1.hw5.pt2.Header)")
    public Object header(final ProceedingJoinPoint joinPoint) throws Throwable {
        System.out.println("*******************************");
        try {
            final Object value = joinPoint.proceed();
            return value;
        } catch (Throwable t) {
            throw t;
        } finally {
            System.out.println("*******************************");
        }
    }

    @Around("allMethods() && @annotation(com.project1.hw5.pt2.VerseType)")
    public Object verseType(final ProceedingJoinPoint joinPoint) throws Throwable {
        try {
            int value = Integer.parseInt(joinPoint.proceed().toString());
            switch (value) {
                case 0:
                    System.out.println("\n++++++++++ Verse ++++++++++\n");
                    break;
                case 1:
                    System.out.println("\n////////// Bridge //////////\n");
                    break;
                case 2:
                    System.out.println("\n********** Chorus **********\n");
                    break;
            }

            return value;
        } catch (Throwable t) {
            throw t;
        }
    }


    @Around("allMethods() && @annotation(com.project1.hw5.pt2.Verse)")
    public Object verse(final ProceedingJoinPoint joinPoint) throws Throwable {
        try {
            final List<String> verses = (List) joinPoint.proceed();
            for(String verse : verses) {
                System.out.println(verse);
            }

            return verses;
        } catch (Throwable t) {
            throw t;
        }
    }

    @Around("allMethods() && @annotation(com.project1.hw5.pt2.Link)")
    public String link(final ProceedingJoinPoint joinPoint) throws Throwable {
        System.out.println("\n----------------------------");
        try {
            final String link = joinPoint.proceed().toString();
            System.out.println("\n/* LINK: " + link + " */\n");
            return link;
        } catch (Throwable t) {
            throw t;
        } finally {
            System.out.println("----------------------------\n");
        }
    }
}
