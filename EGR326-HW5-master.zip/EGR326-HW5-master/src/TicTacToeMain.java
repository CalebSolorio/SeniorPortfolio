import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

/**
 * This class starts up the game.
 * @author Caleb Solorio
 * @version 1.0 (Mar 29 2017)
 */

public class TicTacToeMain extends Application {
    /**
     * Initializes a JavaFX project.
     * @param stage The stage on which to display the GUI components.
     * @throws Exception if the resources required are not found.
     */
    @Override
    public void start(Stage stage) throws Exception {
        stage.setTitle("Tic-Tac-Toe");
        FXMLLoader loader = new FXMLLoader(getClass().getResource("./gameView.fxml"));
        BorderPane borderPane = loader.load();

        Scene scene = new Scene(borderPane, 500, 500);
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Starts up the program.
     * @param args Any arguments required to start.
     */
    public static void main(String[] args) {
        launch(args);
    }
}
