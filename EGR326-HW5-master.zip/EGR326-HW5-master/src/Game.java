import java.util.Observable;
import java.util.Observer;

/**
 * This class handles game logic.
 * @author Caleb Solorio
 * @version 1.0 (Mar 29 2017)
 */

public class Game extends Observable {
    private static Game game = new Game();
    private Player player1;
    private Player player2;
    private Board board;
    private GameState state;

    // Creates an instance of Game.
    private Game() {
        player1 = new Player(PlayerType.ONE, "Player 1");
        player2 = new Player(PlayerType.TWO, "Player 2");
        board = new Board();
        state = GameState.NOTSTARTED;
    }

    /**
     * Gets the instance of Game.
     * @return the Game object.
     */
    public static Game getInstance( ) {
        return game;
    }

    /**
     * Copy the player1 object.
     * @return a clone of player1.
     */
    public Player getPlayer1() {
        return player1.clone();
    }


    /**
     * Sets the name of Player 1.
     * @param name The desired name for player1.
     * @throws IllegalStateException if the player1 object is of type UNDEFINED.
     * @throws IllegalArgumentException if the desired name is invalid.
     */
    public void setPlayer1Name(String name) throws IllegalStateException, IllegalArgumentException {
        player1.setName(name);
    }

    /**
     * Copy the player2 object.
     * @return a clone of player2.
     */
    public Player getPlayer2() {
        return player2.clone();
    }

    /**
     * Sets the name of Player 2.
     * @param name The desired name for player2.
     * @throws IllegalStateException if the player2 object is of type UNDEFINED.
     * @throws IllegalArgumentException if the desired name is invalid.
     */
    public void setPlayer2Name(String name) throws IllegalStateException, IllegalArgumentException {
        player2.setName(name);
    }

    /**
     * Get the current state of the game board.
     * @return the cloned Board object.
     */
    public Board getBoard() {
        return board.clone();
    }

    /**
     * Initiates a new game.
     * @throws IllegalStateException if a game is already underway.
     */
    public void startGame() throws IllegalStateException {
        if(state != GameState.PLAYERONETURN && state != GameState.PLAYERTWOTURN) {
            state = GameState.PLAYERONETURN;
            board.resetSquares();

            setChanged();
            notifyObservers(state);
        } else {
            throw new IllegalStateException("Game already in progress");
        }
    }

    /**
     * Marks a square according to the game's state.
     * @param x The x coordinate of the square to mark.
     * @param y The y coordinate of the square to mark.
     * @throws IllegalStateException if no game is underway.
     */
    public void markSquare(int x, int y) throws IllegalStateException {
        switch (state) {
            case PLAYERONETURN:
                board.setSquare(x, y, player1.getPlayerType());
                state = GameState.PLAYERTWOTURN;
                break;
            case PLAYERTWOTURN:
                board.setSquare(x, y, player2.getPlayerType());
                state = GameState.PLAYERONETURN;
                break;
            default:
                throw new IllegalStateException("No game in progress");
        }

        updateState();
    }

    /**
     * Resets the game.
     * @throws IllegalStateException if the player objects are of type UNDEFINED.
     */
    public void resetGame() throws IllegalStateException {
        state = GameState.NOTSTARTED;
        player1.reset();
        player2.reset();
        board.resetSquares();

        setChanged();
        notifyObservers(state);
    }

    // Updates the state of the game.
    private void updateState() throws IllegalStateException {
        if(checkForWinner(player1.getPlayerType())) {
            state = GameState.PLAYERONEWIN;
            player1.addWin();
            player2.addLoss();
        } else if(checkForWinner(player2.getPlayerType())) {
            state = GameState.PLAYERTWOWIN;
            player2.addWin();
            player1.addLoss();
        } else if (board.squaresLeft() == 0) {
            state = GameState.TIE;
        }

        setChanged();
        notifyObservers(state);
    }

    // Checks if a specified type of player has won the game.
    private boolean checkForWinner(PlayerType playerType) throws IllegalArgumentException{
        if (playerType == board.getSquare(0, 0)) {
            if (playerType == board.getSquare(0, 1) && playerType == board.getSquare(0, 2) ||
                    playerType == board.getSquare(1, 0) && playerType == board.getSquare(2, 0) ||
                    playerType == board.getSquare(1, 1) && playerType == board.getSquare(2, 2)) {
                return true;
            }
        } else if (playerType == board.getSquare(1, 1)) {
            if (playerType == board.getSquare(0, 1) && playerType == board.getSquare(2, 1) ||
                    playerType == board.getSquare(1, 0) && playerType == board.getSquare(1, 2) ||
                    playerType == board.getSquare(0, 0) && playerType == board.getSquare(2, 2) ||
                    playerType == board.getSquare(2, 0) && playerType == board.getSquare(0, 2)) {
                return true;
            }
        } else if (playerType == board.getSquare(2, 2)) {
            if (playerType == board.getSquare(2, 0) && playerType == board.getSquare(2, 1) ||
                    playerType == board.getSquare(0, 2) && playerType == board.getSquare(1, 2)) {
                return true;
            }
        }

        return false;
    }
}
