
/**
 * This class starts up the game.
 * @author Caleb Solorio
 * @version 1.0 (Mar 29 2017)
 */

public class Board implements Cloneable {
    private PlayerType[][] squares;

    /**
     * Initializes the logic for a new 3x3 grid.
     */
    public Board() {
        squares = new PlayerType[3][3];
        resetSquares();
    }

    /**
     * Sets the state of a particular square.
     * @param x The x coordinate of the square to set.
     * @param y The y coordinate of the square to set.
     * @param playerType The type of player who is declaring ownership of the square.
     * @throws IllegalArgumentException if invalid coordinates are provided.
     */
    public void setSquare(int x, int y, PlayerType playerType) throws IllegalArgumentException {
        if(x >= 0 && x <= 2 && y >=0 && y <= 2) {
            squares[x][y] = playerType;
        } else {
            throw new IllegalArgumentException("Coordinates must specify point within the 3x3 grid.");
        }
    }

    /**
     * Gets the state of a square
     * @param x The x coordinate of the square to get.
     * @param y The y coordinate of the square to get.
     * @return The type of player who has ownership over the square.
     * @throws IllegalArgumentException if invalid coordinates are provided.
     */
    public PlayerType getSquare(int x, int y) throws IllegalArgumentException {
        if(x >= 0 && x <= 2 && y >=0 && y <= 2) {
            return squares[x][y];
        }
        throw new IllegalArgumentException("Coordinates must specify point within the 3x3 grid.");
    }

    /**
     * Sets ownership of all squares to UNDEFINED.
     */
    public void resetSquares() {
        for(int i = 0; i < 3; i++) {
            for(int j = 0; j < 3; j++) {
                squares[i][j] = PlayerType.UNDEFINED;
            }
        }
    }

    /**
     * Calculates the number of squares that have not been marked.
     * @return an integer of the squares that are UNDEFINED.
     */
    public int squaresLeft() {
        int count = 0;

        for(int i = 0; i < 3; i++) {
            for(int j = 0; j < 3; j++) {
                if(squares[i][j] == PlayerType.UNDEFINED) {
                    count++;
                }
            }
        }

        return count;
    }

    /**
     * Makes a copy of the board.
     * @return a clone of this object.
     */
    public Board clone() {
        Board copy = null;

        try {
            copy = (Board) super.clone();
            for(int i = 0; i < 3; i++) {
                for(int j = 0; j < 3; j++) {
                    copy.squares[i][j] = squares[i][j];
                }
            }
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }

        return copy;
    }
}
