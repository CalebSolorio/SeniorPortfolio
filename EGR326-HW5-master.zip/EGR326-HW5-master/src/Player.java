/**
 * This class handles game logic.
 * @author Caleb Solorio
 * @version 1.0 (Mar 29 2017)
 */

public class Player implements Cloneable {
    private PlayerType playerType;
    private String name;
    private int wins;
    private int losses;

    /**
     * Initializes a new player object
     * @param playerType The type of player this object should be.
     * @param name The desired name of this object.
     */
    public Player(PlayerType playerType, String name) {
        this.playerType = playerType;
        this.name = name;
        wins = 0;
    }

    /**
     * Set the name of the player.
     * @param name The desired name.
     * @throws IllegalStateException if the player type is UNDEFINED.
     * @throws IllegalArgumentException if the desired name is invalid.
     */
    public void setName(String name) throws IllegalStateException, IllegalArgumentException {
        if(!isPlayer()) {
            throw new IllegalStateException("Player Unknown");
        } else if(!isValidName(name)) {
            throw new IllegalArgumentException("Illegal player name(s).");
        } else {
            this.name = name;
        }
    }

    /**
     * Gets the name of this player object.
     * @return the name value of this object.
     * @throws IllegalStateException if the player type is UNDEFINED.
     */
    public String getName() throws IllegalStateException {
        if(isPlayer()) {
            return name;
        }
        throw new IllegalStateException("Player Unknown");
    }

    /**
     * Gets the type of this player.
     * @return the value of playerType.
     */
    public PlayerType getPlayerType() {
        return playerType;
    }

    /**
     * Adds a win to this player object.
     * @throws IllegalStateException if this player's type is UNDEFINED.
     */
    public void addWin() throws IllegalStateException {
        if(isPlayer()) {
            wins++;
        } else {
            throw new IllegalStateException("Player Unknown");
        }
    }

    /**
     * Adds a loss to this player object.
     * @throws IllegalStateException if this player's type is UNDEFINED.
     */
    public void addLoss() throws IllegalStateException {
        if(isPlayer()) {
            losses++;
        } else {
            throw new IllegalStateException("Player Unknown");
        }
    }

    /**
     * Resets this player's state.
     * @throws IllegalStateException if this player's type is UNDEFINED.
     */
    public void reset() throws IllegalStateException {
        if(isPlayer()) {
            name = playerType == PlayerType.ONE ? "Player 1" : "Player 2";
            wins = 0;
            losses = 0;
        } else {
            throw new IllegalStateException("Player(s) Unknown");
        }
    }

    /**
     * Gets the number of wins this player has obtained.
     * @return the value of wins.
     * @throws IllegalStateException if this player's type is UNDEFINED.
     */
    public int getWins() throws IllegalStateException {
        if(isPlayer()) {
            return wins;
        }
        throw new IllegalStateException("Player Unknown");
    }

    /**
     * Gets the number of losses this player has obtained.
     * @return the value of losses.
     * @throws IllegalStateException if this player's type is UNDEFINED.
     */
    public int getLosses() throws IllegalStateException {
        if(isPlayer()) {
            return losses;
        }
        throw new IllegalStateException("Player Unknown");
    }

    /**
     * Gets a copy of a player.
     * @return a clone of this object.
     */
    public Player clone() {
        Player copy = null;

        try {
            copy = (Player) super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }

        return copy;
    }

    // Checks if the player type is defined.
    private boolean isPlayer() {
        return playerType != PlayerType.UNDEFINED;
    }

    // Checks if the given string is a valid name.
    private boolean isValidName(String name) {
        return name.replaceAll("\\s+","").length() > 0;
    }
}
