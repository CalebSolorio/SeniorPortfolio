import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

import java.net.URL;
import java.util.Observable;
import java.util.Observer;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * This class controls the GUI.
 * @author Caleb Solorio
 * @version 1.0 (Mar 29 2017)
 */

public class GameController implements Initializable, Observer {
    private Game game;

    @FXML private TextField p1TextField;
    @FXML private Label p1Wins;
    @FXML private Label p1Losses;
    @FXML private TextField p2TextField;
    @FXML private Label p2Wins;
    @FXML private Label p2Losses;
    @FXML private Button newGameBtn;
    @FXML private Button resetBtn;
    @FXML private Button exitBtn;
    @FXML private Button square0;
    @FXML private Button square1;
    @FXML private Button square2;
    @FXML private Button square3;
    @FXML private Button square4;
    @FXML private Button square5;
    @FXML private Button square6;
    @FXML private Button square7;
    @FXML private Button square8;
    @FXML private Label prompt;

    /**
     * Initializes a new GUI and gets the game object.
     * @param location The location of any JavaFX resources required.
     * @param resources The resources required to launch the GUI.
     */
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        game = Game.getInstance();
        game.addObserver(this);

        newGameBtn.setOnAction(e -> startGame());
        resetBtn.setOnAction(e -> reset());
        exitBtn.setOnAction(e -> Platform.exit());

        square0.setOnAction(e -> markSquare(0, 0));
        square1.setOnAction(e -> markSquare(0, 1));
        square2.setOnAction(e -> markSquare(0, 2));
        square3.setOnAction(e -> markSquare(1, 0));
        square4.setOnAction(e -> markSquare(1, 1));
        square5.setOnAction(e -> markSquare(1, 2));
        square6.setOnAction(e -> markSquare(2, 0));
        square7.setOnAction(e -> markSquare(2, 1));
        square8.setOnAction(e -> markSquare(2, 2));

        update(null, GameState.NOTSTARTED);
    }

    /**
     * Updates this object based on the updated state of the Observable object.
     * @param o The observable component.
     * @param arg What the updated object has returned.
     */
    public void update(Observable o, Object arg) {
        if(arg.getClass().isEnum()) {
            GameState state = (GameState) arg;

            try {
                switch (state) {
                    case NOTSTARTED:
                        endGame();
                        prompt.setText("");
                        break;
                    case PLAYERONETURN:
                        prompt.setText(game.getPlayer1().getName() + "'s Turn");
                        break;
                    case PLAYERONEWIN:
                        endGame();
                        prompt.setText(game.getPlayer1().getName() + " wins!");
                        break;
                    case PLAYERTWOTURN:
                        prompt.setText(game.getPlayer2().getName() + "'s Turn");
                        break;
                    case PLAYERTWOWIN:
                        endGame();
                        prompt.setText(game.getPlayer2().getName() + " wins!");
                        break;
                    case TIE:
                        endGame();
                        prompt.setText("The game ends in a tie.");
                        break;
                }

                updateBoard(state);
            } catch (IllegalStateException e) {
                showException(e); // Probably won't ever happen.
            };
        }
    }

    // Updates the game board.
    private void updateBoard(GameState state) {
        Board board = game.getBoard();
        for(int i = 0; i < 3; i++) {
            for(int j = 0; j < 3; j++) {
                try {
                    PlayerType playerType = board.getSquare(i, j);
                    boolean unknown = playerType == PlayerType.UNDEFINED;
                    String text;

                    if(unknown) {
                        text = "";
                    } else {
                        text = playerType == PlayerType.ONE ? "X" : "O";
                    }

                    boolean inProgress = state == GameState.PLAYERONETURN || state == GameState.PLAYERTWOTURN;
                    boolean disable = !inProgress || (!unknown && inProgress);

                    switch (i * 3 + j) {
                        case 0:
                            square0.setText(text);
                            square0.setDisable(disable);
                            break;
                        case 1:
                            square1.setText(text);
                            square1.setDisable(disable);
                            break;
                        case 2:
                            square2.setText(text);
                            square2.setDisable(disable);
                            break;
                        case 3:
                            square3.setText(text);
                            square3.setDisable(disable);
                            break;
                        case 4:
                            square4.setText(text);
                            square4.setDisable(disable);
                            break;
                        case 5:
                            square5.setText(text);
                            square5.setDisable(disable);
                            break;
                        case 6:
                            square6.setText(text);
                            square6.setDisable(disable);
                            break;
                        case 7:
                            square7.setText(text);
                            square7.setDisable(disable);
                            break;
                        default:
                            square8.setText(text);
                            square8.setDisable(disable);
                            break;
                    }
                } catch (IllegalArgumentException e) {
                    showException(e); // Probably won't ever happen.
                }
            }
        }
    }

    // Changes the GUI to accommodate the start of a new game.
    private void startGame() {
        try {
            game.setPlayer1Name(p1TextField.getText());
            game.setPlayer2Name(p2TextField.getText());

            p1TextField.setDisable(true);
            p2TextField.setDisable(true);
            newGameBtn.setDisable(true);

            game.startGame();
        } catch (IllegalArgumentException e) {
            showException(e);
        }
    }

    // Marks a square based on whose turn it is.
    private void markSquare(int x, int y) {
        try {
            game.markSquare(x, y);
        } catch (IllegalArgumentException e) {
            showException(e); // Probably will never happen.
        }
    }

    // Changes the GUI to accommodate the end of a game.
    private void endGame() {
        p1TextField.setDisable(false);
        p2TextField.setDisable(false);
        newGameBtn.setDisable(false);

        updateStats();
    }

    // Updates the wins/losses of each player displayed in the GUI.
    private void updateStats() {
        try {
            p1Wins.setText(Integer.toString(game.getPlayer1().getWins()));
            p1Losses.setText(Integer.toString(game.getPlayer1().getLosses()));

            p2Wins.setText(Integer.toString(game.getPlayer2().getWins()));
            p2Losses.setText(Integer.toString(game.getPlayer2().getLosses()));
        } catch (IllegalStateException e) {
            showException(e); // Probably will never happen.
        }
    }

    // Asks the user if they actually want to reset, then update the GUI accordingly.
    private void reset() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Are you sure?");
        alert.setHeaderText(null);
        alert.setContentText("This will end the game and set the win/loss stats to 0. Are you sure?");

        ButtonType yesBtn = new ButtonType("Yes", ButtonBar.ButtonData.YES);
        ButtonType noBtn = new ButtonType("No", ButtonBar.ButtonData.NO);

        alert.getButtonTypes().setAll(yesBtn, noBtn);
        Optional<ButtonType> result = alert.showAndWait();

        if (result.get() == yesBtn){
            try {
                game.resetGame();
            } catch (IllegalStateException e) {
                showException(e); // Probably will never happen.
            }
        }
    }

    // Alert the user of an exception.
    private void showException(Exception e) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(e.getMessage());

        alert.showAndWait();
    }
}
