package ttt.model;

/**
 * This enum specifies the different states a game can be in..
 * @author Caleb Solorio
 * @version 1.0 (Mar 29 2017)
 */

public enum GameState {
    NOTSTARTED, PLAYERONETURN, PLAYERONEWIN, PLAYERTWOTURN, PLAYERTWOWIN, TIE
}
