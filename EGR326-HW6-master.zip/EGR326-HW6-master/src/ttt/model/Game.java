package ttt.model;

import ttt.strategy.BotFarm;
import ttt.strategy.IntelligenceType;

import java.util.Observable;

/**
 * This class handles game logic.
 * @author Caleb Solorio
 * @version 1.0 (Mar 29 2017)
 */

public class Game extends Observable {
    private static Game game = new Game();
    private Player p1;
    private Player p2;
    private Board board;
    private GameState state;

    // Creates an instance of ttt.model.Game.
    private Game() {
        state = GameState.NOTSTARTED;
        p1 = Player.getInstance(PlayerType.ONE, "Player 1");
        p2 = Player.getInstance(PlayerType.TWO, "Player 2");
        board = new Board();
    }

    /**
     * Gets the instance of ttt.model.Game.
     * @return the Game object.
     */
    public static Game getInstance( ) {
        return game;
    }

    /**
     * Copy a player object.
     * @param playerType The type of player to get.
     * @return a clone of the designated player.
     */
    public Player getPlayer(PlayerType playerType) {
        if(playerType == PlayerType.ONE) {
            return p1.clone();
        } else if(playerType == PlayerType.TWO) {
            return p2.clone();
        } else {
            throw new IllegalArgumentException("Not valid player type.");
        }
    }


    /**
     * Sets the name of the specified player.
     * @param playerType The type of player to set the name of.
     * @param name The desired name for the player.
     * @throws IllegalStateException if the player object is of type UNDEFINED.
     * @throws IllegalArgumentException if the desired name is invalid.
     */
    public void setPlayerName(PlayerType playerType, String name) throws IllegalStateException, IllegalArgumentException {
        if(playerType == PlayerType.ONE) {
            p1.setName(name);
            setChanged();
            notifyObservers(p1);
        } else if(playerType == PlayerType.TWO) {
            p2.setName(name);
            setChanged();
            notifyObservers(p2);
        } else {
            throw new IllegalArgumentException("Not valid player type.");
        }
    }

    /**
     * Sets the intelligence level of the designated player.
     * @param playerType The type of player to update the intelligence of.
     * @param intelligence The desired intelligence level of the player
     * @throws IllegalArgumentException if playerType is UNDEFINED.
     */
    public void setPlayerIntelligence(PlayerType playerType, IntelligenceType intelligence) throws IllegalArgumentException {
        if(playerType == PlayerType.ONE) {
            p1.setIntelligence(intelligence);
            BotFarm.getInstance();
            setChanged();
            notifyObservers(p1);
        } else if(playerType == PlayerType.TWO) {
            p2.setIntelligence(intelligence);
            BotFarm.getInstance();
            setChanged();
            notifyObservers(p2);
        } else {
            throw new IllegalArgumentException("Not valid player type.");
        }
    }

    /**
     * Get the current state of the game board.
     * @return the cloned ttt.model.Board object.
     */
    public Board getBoard() {
        return board.clone();
    }

    /**
     * Get the current state of the game board.
     * @return the cloned ttt.model.Board object.
     */
    public GameState getState() {
        return state;
    }

    /**
     * Initiates a new game.
     * @throws IllegalStateException if a game is already underway.
     */
    public void startGame() throws IllegalStateException {
        if(state != GameState.PLAYERONETURN && state != GameState.PLAYERTWOTURN) {
            state = GameState.PLAYERONETURN;
            board.resetSquares();

            setChanged();
            notifyObservers(state);
        } else {
            throw new IllegalStateException("ttt.model.Game already in progress");
        }
    }

    /**
     * Marks a square according to the game's state.
     * @param x The x coordinate of the square to mark.
     * @param y The y coordinate of the square to mark.
     * @throws IllegalArgumentException if the square has already been marked.
     * @throws IllegalStateException if no game is underway.
     */
    public void markSquare(int x, int y) throws IllegalArgumentException, IllegalStateException {
        if(board.getSquare(x, y) != PlayerType.UNDEFINED) {
            throw new IllegalArgumentException("Square already marked");
        }

        switch (state) {
            case PLAYERONETURN:
                board.setSquare(x, y, p1.getPlayerType());
                state = GameState.PLAYERTWOTURN;
                break;
            case PLAYERTWOTURN:
                board.setSquare(x, y, p2.getPlayerType());
                state = GameState.PLAYERONETURN;
                break;
            default:
                throw new IllegalStateException("No game in progress");
        }

        updateState();
    }

    /**
     * Checks if a specified type of player has won the game.
     * @param playerType The type of player to check for.
     * @return an array of the winning set of marked squares.
     * @throws IllegalArgumentException if invalid coordinates are provided (will not happen).
     */
    public int[] checkForWinner(PlayerType playerType) throws IllegalArgumentException{
        if (playerType == board.getSquare(0, 0)) {
            if(playerType == board.getSquare(0, 1) && playerType == board.getSquare(0, 2)) {
                return new int[]{0, 1, 2};
            } else if(playerType == board.getSquare(1, 0) && playerType == board.getSquare(2, 0)) {
                return new int[]{0, 3, 6};
            } else if(playerType == board.getSquare(1, 1) && playerType == board.getSquare(2, 2)) {
                return new int[]{0, 4, 8};
            }
        }

        if (playerType == board.getSquare(1, 1)) {
            if(playerType == board.getSquare(0, 1) && playerType == board.getSquare(2, 1)) {
                return new int[]{1, 4, 7};
            } else if(playerType == board.getSquare(2, 0) && playerType == board.getSquare(0, 2)) {
                return new int[]{2, 4, 6};
            }
        }

        if (playerType == board.getSquare(2, 2) && playerType == board.getSquare(2, 0) &&
                playerType == board.getSquare(2, 1)) {
            return new int[]{6, 7, 8};
        }

        return new int[0];
    }

    /**
     * Resets the game.
     * @throws IllegalStateException if the player objects are of type UNDEFINED.
     */
    public void resetGame() throws IllegalStateException {
        state = GameState.NOTSTARTED;
        p1.reset();
        p2.reset();
        board.resetSquares();

        setChanged();
        notifyObservers(state);
        setChanged();
        notifyObservers(p1);
        setChanged();
        notifyObservers(p2);
    }

    // Updates the state of the game.
    private void updateState() throws IllegalStateException {
        if(checkForWinner(p1.getPlayerType()).length > 0) {
            state = GameState.PLAYERONEWIN;
            p1.addWin();
            p2.addLoss();
            setChanged();
            notifyObservers(p1);
            setChanged();
            notifyObservers(p2);
        } else if(checkForWinner(p2.getPlayerType()).length > 0) {
            state = GameState.PLAYERTWOWIN;
            p2.addWin();
            p1.addLoss();
            setChanged();
            notifyObservers(p2);
            setChanged();
            notifyObservers(p1);
        } else if (board.squaresLeft() == 0) {
            state = GameState.TIE;
        }

        // Notify twice (only one won't trigger changes in GameController).
        setChanged();
        notifyObservers(state);
        setChanged();
        notifyObservers(state);
    }
}
