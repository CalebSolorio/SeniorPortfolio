package ttt.model;

import ttt.strategy.IntelligenceType;

import java.util.HashMap;

/**
 * This class handles player data and logic.
 * @author Caleb Solorio
 * @version 1.0 (Mar 29 2017)
 */

public class Player implements Cloneable {
    private static final HashMap<PlayerType, Player> players = new HashMap();
    private PlayerType playerType;
    private String name;
    private IntelligenceType intelligence;
    private int wins;
    private int losses;

    // Initializes a new Player object.
    private Player(PlayerType playerType, String name) {
        this.playerType = playerType;
        this.name = name;
        intelligence = IntelligenceType.HUMAN;
        wins = 0;
        losses = 0;
    }

    /**
     * Gets a player instance or creates a new one if no object exists.
     * @param playerType The type of player this object should be.
     * @param name The desired name of this object.
     */
    public static Player getInstance(PlayerType playerType, String name) {
        Player player = players.get(playerType);

        if(player == null) {
            player = new Player(playerType, name);
            players.put(playerType, player);
        }

        return player;
    }

    /**
     * Sets the name of the player.
     * @param name The desired name.
     * @throws IllegalStateException if the player type is UNDEFINED.
     * @throws IllegalArgumentException if the desired name is invalid.
     */
    public void setName(String name) throws IllegalStateException, IllegalArgumentException {
        if(!isPlayer()) {
            throw new IllegalStateException("Player Unknown");
        } else if(!isValidName(name)) {
            throw new IllegalArgumentException("Illegal player name(s).");
        } else {
            this.name = name;
        }
    }

    /**
     * Gets the name of this player object.
     * @return the name value of this object.
     * @throws IllegalStateException if the player type is UNDEFINED.
     */
    public String getName() throws IllegalStateException {
        if(isPlayer()) {
            return name;
        }
        throw new IllegalStateException("Player Unknown");
    }

    /**
     * Gets the intelligence of the player.
     * @return the intelligence level of the player.
     */
    public IntelligenceType getIntelligence() {
        return intelligence;
    }

    /**
     * Sets the intelligence of the player
     * @param intelligence The intelligence level of the player.
     */
    public void setIntelligence(IntelligenceType intelligence) {
        this.intelligence = intelligence;
    }

    /**
     * Gets the type of this player.
     * @return the value of playerType.
     */
    public PlayerType getPlayerType() {
        return playerType;
    }

    /**
     * Adds a win to this player object.
     * @throws IllegalStateException if this player's type is UNDEFINED.
     */
    public void addWin() throws IllegalStateException {
        if(isPlayer()) {
            wins++;
        } else {
            throw new IllegalStateException("Player Unknown");
        }
    }

    /**
     * Adds a loss to this player object.
     * @throws IllegalStateException if this player's type is UNDEFINED.
     */
    public void addLoss() throws IllegalStateException {
        if(isPlayer()) {
            losses++;
        } else {
            throw new IllegalStateException("Player Unknown");
        }
    }

    /**
     * Resets this player's state.
     * @throws IllegalStateException if this player's type is UNDEFINED.
     */
    public void reset() throws IllegalStateException {
        if(isPlayer()) {
            name = playerType == PlayerType.ONE ? "Player 1" : "Player 2";
            wins = 0;
            losses = 0;
        } else {
            throw new IllegalStateException("Player(s) Unknown");
        }
    }

    /**
     * Gets the number of wins this player has obtained.
     * @return the value of wins.
     * @throws IllegalStateException if this player's type is UNDEFINED.
     */
    public int getWins() throws IllegalStateException {
        if(isPlayer()) {
            return wins;
        }
        throw new IllegalStateException("Player Unknown");
    }

    /**
     * Gets the number of losses this player has obtained.
     * @return the value of losses.
     * @throws IllegalStateException if this player's type is UNDEFINED.
     */
    public int getLosses() throws IllegalStateException {
        if(isPlayer()) {
            return losses;
        }
        throw new IllegalStateException("Player Unknown");
    }

    /**
     * Gets a copy of a player.
     * @return a clone of this object.
     */
    public Player clone() {
        Player copy = null;

        try {
            copy = (Player) super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }

        return copy;
    }

    // Checks if the player type is defined.
    private boolean isPlayer() {
        return playerType != PlayerType.UNDEFINED;
    }

    // Checks if the given string is a valid name.
    private boolean isValidName(String name) {
        return name.replaceAll("\\s+","").length() > 0;
    }
}
