package ttt.model;

/**
 * This enum denotes the various types of game board.
 * @author Caleb Solorio
 * @version 1.0 (Mar 29 2017)
 */

public enum BoardType {
    BUTTONS, PAINTED
}
