package ttt.strategy;

import ttt.model.Board;
import ttt.model.Game;
import ttt.model.GameState;
import ttt.model.PlayerType;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * This class implements bot behavior at a Random level of intelligence.
 * @author Caleb Solorio
 * @version 1.0 (Apr 6 2017)
 */

public class RandomBot implements Bot {
    /**
     * Determines which square to mark, then marks it.
     * @throws IllegalStateException if no game is currently in progress.
     * @throws IllegalArgumentException if the square picked is invalid (highly unlikely).
     */
    @Override
    public void markSquare() throws IllegalStateException, IllegalArgumentException {
        Game game = Game.getInstance();
        if(game.getState() == GameState.PLAYERONETURN || game.getState() == GameState.PLAYERTWOTURN) {
            Board board = game.getBoard();
            List<Integer> openSquares = new ArrayList<>();

            for(int x = 0; x < 3; x++) {
                for(int y = 0; y < 3; y++) {
                    if(board.getSquare(x, y) == PlayerType.UNDEFINED) {
                        openSquares.add(x*3 + y);
                    }
                }
            }

            int square = openSquares.get(new Random().nextInt(openSquares.size()));
            game.markSquare(square / 3, square % 3);
        } else {
            throw new IllegalStateException("Game not in progress.");
        }
    }
}
