package ttt.strategy;

/**
 * This interface specifies the core bot behavior.
 * @author Caleb Solorio
 * @version 1.0 (Apr 6 2017)
 */

public interface Bot {
    void markSquare() throws IllegalStateException, IllegalArgumentException;
}
