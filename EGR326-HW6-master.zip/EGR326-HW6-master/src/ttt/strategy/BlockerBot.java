package ttt.strategy;

import ttt.model.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * This class implements bot behavior at a Blocker level of intelligence.
 * @author Caleb Solorio
 * @version 1.0 (Apr 6 2017)
 */

public class BlockerBot implements Bot {
    /**
     * Determines which square to mark, then marks it.
     * @throws IllegalStateException if no game is currently in progress.
     * @throws IllegalArgumentException if the square picked is invalid (highly unlikely).
     */
    @Override
    public void markSquare() throws IllegalStateException, IllegalArgumentException {
        Game game = Game.getInstance();
        PlayerType foe;
        if(game.getState() == GameState.PLAYERONETURN) {
            foe = PlayerType.TWO;
        } else if(game.getState() == GameState.PLAYERTWOTURN) {
            foe = PlayerType.ONE;
        } else {
            throw new IllegalStateException("Game not in progress.");
        }

        Board board = game.getBoard();
        List<Integer> openSquares = new ArrayList<>();

        int square = -1;

        loop:
        for(int x = 0; x < 3; x++) {
            for(int y = 0; y < 3; y++) {
                if(board.getSquare(x, y) == PlayerType.UNDEFINED) {
                    int openSquare = x*3 + y;
                    if(validBlock(board, openSquare, foe)) {
                        square = openSquare;
                        break loop;
                    } else {
                        openSquares.add(openSquare);
                    }
                }
            }
        }

        if(square < 0) {
            square = openSquares.get(new Random().nextInt(openSquares.size()));
        }

        game.markSquare(square / 3, square % 3);
    }

    /**
     * Determines if the proposed block is valid.
     * @param board The board of the game.
     * @param square The square to mark.
     * @param foe Which player the bot is playing against.
     * @return True if block is valid, false otherwise.
     */
    public boolean validBlock(Board board, int square, PlayerType foe) {
        for(int j = 1; j < 5; j++) {
            int square1 = square + j;
            int square2 = square + j*2;
            boolean blockValid = (square1 / 3 == square2 / 3 && square2 / 3== square / 3) ||
                    (square1 % 3 == square2 % 3 && square2 % 3== square % 3) ||
                    (square / 3 != square1 / 3 && square / 3 != square2 / 3 &&
                            square2 / 3 != square1 / 3 && square % 3 != square1 % 3 &&
                            square % 3 != square2 % 3 && square2 % 3 != square1 % 3);

            if(foeOccupiesSquares(board, foe, square1, square2) && blockValid) {
                return true;
            }

            square1 = square - j;
            square2 = square + j;
            blockValid = (square1 / 3 == square2 / 3 && square2 / 3 == square / 3) ||
                    (square1 % 3 == square2 % 3 && square2 % 3== square % 3) ||
                    ((square2 / 3) != (square1 / 3) && (square2 % 3) != (square1 % 3) & square == 4);

            if(foeOccupiesSquares(board, foe, square1, square2) && blockValid) {
                return true;
            }

            square1 = square - j*2;
            square2 = square - j;
            blockValid = (square1 / 3 == square2 / 3 && square2 / 3== square / 3) ||
                    (square1 % 3 == square2 % 3 && square2 % 3 == square % 3) ||
                    (square / 3 != square1 / 3 && square / 3 != square2 / 3 &&
                            square2 / 3 != square1 / 3 && square % 3 != square1 % 3 &&
                            square % 3 != square2 % 3 && square2 % 3 != square1 % 3);

            if(foeOccupiesSquares(board, foe, square1, square2) && blockValid) {
                return true;
            }
        }

        return false;
    }

    // Checks if a foe occupies a set of squares.
    private boolean foeOccupiesSquares(Board board, PlayerType foe, int square1, int square2) {
        try {
            return board.getSquare(square1 / 3, square1 % 3) == foe &&
                    board.getSquare(square2 / 3, square2 % 3) == foe;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }
}
