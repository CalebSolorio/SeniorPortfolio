package ttt.strategy;

import ttt.model.*;

import java.util.Observable;
import java.util.Observer;

/**
 * This class holds the bots relevant to the game.
 * @author Caleb Solorio
 * @version 1.0 (Apr 6 2017)
 */

public class BotFarm implements Observer {
    private static BotFarm botFarm = new BotFarm();
    private Bot p1Bot;
    private Bot p2Bot;

    // Creates a new instance of BotFarm.
    private BotFarm() {
        p1Bot = null;
        p2Bot = null;
        Game.getInstance().addObserver(this);
    }

    /**
     * Gets an instance of BotFarm
     * @return the BotFarm object.
     */
    public static BotFarm getInstance() {
        return botFarm;
    }

    /**
     * Updates the BotFarm object.
     * @param o The Observable component.
     * @param arg The argument sent from the Observable component.
     */
    @Override
    public void update(Observable o, Object arg) {
        if(arg != null) {
            if(arg.getClass() == Player.class) {
                Player player = (Player) arg;
                PlayerType playerType = player.getPlayerType();
                IntelligenceType intelligenceType = player.getIntelligence();
                if(playerType != PlayerType.UNDEFINED) {
                    if(playerType == PlayerType.ONE) {
                        p1Bot = BotFactory.createBot(intelligenceType);
                    } else {
                        p2Bot = BotFactory.createBot(intelligenceType);
                    }
                }
            } else if(arg instanceof GameState) {
                GameState state = (GameState) arg;
                if(state == GameState.PLAYERONETURN && p1Bot != null) {
                    p1Bot.markSquare();
                } else if(state == GameState.PLAYERTWOTURN && p2Bot != null) {
                    p2Bot.markSquare();
                }
            }
        }
    }


}
