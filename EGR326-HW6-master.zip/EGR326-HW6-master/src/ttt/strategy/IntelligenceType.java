package ttt.strategy;

/**
 * This class denotes the difference intelligence types.
 */

public enum IntelligenceType {
    HUMAN, RANDOM, SEQUENTIAL, BLOCKER, SMART;

    /**
     * Summarizes the enum type in a String.
     * @return the corresponding String.
     */
    public String toString() {
        switch (this) {
            case RANDOM:
                return "Random";
            case SEQUENTIAL:
                return "Sequential";
            case BLOCKER:
                return "Blocker";
            case SMART:
                return "Smart";
            default:
                return "Human";
        }
    }
}
