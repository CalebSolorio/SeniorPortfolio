package ttt.strategy;

/**
 * This class assists with bot creation.
 * @author Caleb Solorio
 * @version 1.0 (Apr 6 2017)
 */

public class BotFactory {
    /**
     * Creates a new bot.
     * @param intelligence The desired intelligence of the bot.
     * @return the desired type of bot.
     */
    public static Bot createBot(IntelligenceType intelligence) {
        switch (intelligence) {
            case RANDOM:
                return new RandomBot();
            case SEQUENTIAL:
                return new SequentialBot();
            case BLOCKER:
                return new BlockerBot();
            case SMART:
                return new SmartBot();
            default:
                return null;
        }
    }
}
