package ttt.strategy;

import ttt.model.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * This class implements bot behavior at a Smart level of intelligence.
 * @author Caleb Solorio
 * @version 1.0 (Apr 6 2017)
 */

public class SmartBot implements Bot {
    /**
     * Determines which square to mark, then marks it.
     * @throws IllegalStateException if no game is currently in progress.
     * @throws IllegalArgumentException if the square picked is invalid (highly unlikely).
     */
    @Override
    public void markSquare() throws IllegalStateException, IllegalArgumentException {
        Game game = Game.getInstance();
        PlayerType foe;
        if(game.getState() == GameState.PLAYERONETURN) {
            foe = PlayerType.TWO;
        } else if(game.getState() == GameState.PLAYERTWOTURN) {
            foe = PlayerType.ONE;
        } else {
            throw new IllegalStateException("Game not in progress.");
        }

        Board board = game.getBoard();
        BlockerBot bot = new BlockerBot();
        int square = -1;
        List<Integer> openCorners = new ArrayList<>();
        boolean centerSquareOpen = false;
        List<Integer> openSides = new ArrayList<>();

        loop:
        for(int x = 0; x < 3; x++) {
            for(int y = 0; y < 3; y++) {
                if(board.getSquare(x, y) == PlayerType.UNDEFINED) {
                    int openSquare = x*3 + y;
                    if(bot.validBlock(board, openSquare, foe)) {
                        square = openSquare;
                        break loop;
                    } else {
                        if(openSquare == 0 || openSquare == 2 || openSquare == 6 || openSquare == 8) {
                            openCorners.add(openSquare);
                        } else if(openSquare == 4) {
                            centerSquareOpen = true;
                        } else {
                            openSides.add(openSquare);
                        }
                    }
                }
            }
        }

        if(square < 0) {
            if(openCorners.size() > 0) {
                square = openCorners.get(new Random().nextInt(openCorners.size()));
            } else if(centerSquareOpen) {
                square = 4;
            } else {
                square = openSides.get(new Random().nextInt(openSides.size()));
            }
        }

        game.markSquare(square / 3, square % 3);
    }
}
