package ttt.view;

import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.canvas.*;
import javafx.scene.layout.GridPane;
import ttt.model.BoardType;

import java.awt.*;
import java.io.IOException;

import static ttt.view.ExceptionWindow.showException;

/**
 * This class helps with creating Board views.
 * @author Caleb Solorio
 * @version 1.0 (Apr 6 2017)
 */

public class BoardViewFactory {
    /**
     * Creates the specified board view
     * @param type The type of board view desired.
     * @return The relevant board view.
     * @throws IllegalArgumentException if type is invalid.
     * @throws IOException If the fxml files cannot be found.
     */
    public Node createBoardView(String type) throws IllegalArgumentException, IOException {
        try {
            BoardType boardType = BoardType.valueOf(type);
            String name = boardType == BoardType.BUTTONS ? "buttonBoardView.fxml" : "paintedBoardView.fxml" ;
            FXMLLoader loader = new FXMLLoader(getClass().getResource(name));
            Node node = loader.load();

            return node;
        } catch (IllegalArgumentException e) {
            showException(e); // Shouldn't happen under normal use.
        } catch (IOException e) {
            showException(e); // Will probably never happen.
        }

        return null;
    }
}
