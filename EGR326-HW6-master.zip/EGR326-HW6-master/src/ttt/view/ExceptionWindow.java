package ttt.view;

import javafx.scene.control.Alert;

/**
 * This class helps with showing error windows.
 * @author Caleb Solorio
 * @version 1.0 (Apr 6 2017)
 */

public class ExceptionWindow {
    /**
     * Displays a window with the appropriate error message.
     * @param e The exception thrown.
     */
    public static void showException(Exception e) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(e.getMessage());

        alert.showAndWait();
    }
}
