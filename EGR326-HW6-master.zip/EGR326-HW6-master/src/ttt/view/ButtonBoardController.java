package ttt.view;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import ttt.model.Board;
import ttt.model.Game;
import ttt.model.GameState;
import ttt.model.PlayerType;

import java.net.URL;
import java.util.Observable;
import java.util.ResourceBundle;

import static ttt.view.ExceptionWindow.showException;

/**
 * This class implements the button board view.
 * @author Caleb Solorio
 * @version 1.0 (Apr 6 2017)
 */

public class ButtonBoardController extends BoardController {
    @FXML protected Button square0;
    @FXML protected Button square1;
    @FXML protected Button square2;
    @FXML protected Button square3;
    @FXML protected Button square4;
    @FXML protected Button square5;
    @FXML protected Button square6;
    @FXML protected Button square7;
    @FXML protected Button square8;

    /**
     * Initializes the view.
     * @param location The location of the controller.
     * @param resources The resources required to initialize the controller.
     */
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        square0.setOnAction(e -> markSquare(0, 0));
        square1.setOnAction(e -> markSquare(0, 1));
        square2.setOnAction(e -> markSquare(0, 2));
        square3.setOnAction(e -> markSquare(1, 0));
        square4.setOnAction(e -> markSquare(1, 1));
        square5.setOnAction(e -> markSquare(1, 2));
        square6.setOnAction(e -> markSquare(2, 0));
        square7.setOnAction(e -> markSquare(2, 1));
        square8.setOnAction(e -> markSquare(2, 2));

        game = Game.getInstance();
        game.addObserver(this);
        update(null, game.getState());
    }

    /**
     * Updates the view.
     * @param o The Observable component
     * @param arg The object the Observable component has provided.
     */
    @Override
    public void update(Observable o, Object arg) {
        if(arg != null && arg instanceof GameState) {
            Board board = game.getBoard();
            for(int i = 0; i < 3; i++) {
                for(int j = 0; j < 3; j++) {
                    try {
                        PlayerType playerType = board.getSquare(i, j);
                        boolean unknown = playerType == PlayerType.UNDEFINED;
                        String text;

                        if(unknown) {
                            text = "";
                        } else {
                            text = playerType == PlayerType.ONE ? "X" : "O";
                        }

                        boolean inProgress = game.getState() == GameState.PLAYERONETURN ||
                                game.getState() == GameState.PLAYERTWOTURN;
                        boolean disable = !inProgress || (!unknown && inProgress);

                        switch (i * 3 + j) {
                            case 0:
                                square0.setText(text);
                                square0.setDisable(disable);
                                break;
                            case 1:
                                square1.setText(text);
                                square1.setDisable(disable);
                                break;
                            case 2:
                                square2.setText(text);
                                square2.setDisable(disable);
                                break;
                            case 3:
                                square3.setText(text);
                                square3.setDisable(disable);
                                break;
                            case 4:
                                square4.setText(text);
                                square4.setDisable(disable);
                                break;
                            case 5:
                                square5.setText(text);
                                square5.setDisable(disable);
                                break;
                            case 6:
                                square6.setText(text);
                                square6.setDisable(disable);
                                break;
                            case 7:
                                square7.setText(text);
                                square7.setDisable(disable);
                                break;
                            default:
                                square8.setText(text);
                                square8.setDisable(disable);
                                break;
                        }
                    } catch (IllegalArgumentException e) {
                        showException(e); // Probably won't ever happen.
                    }
                }
            }
        }
    }
}
