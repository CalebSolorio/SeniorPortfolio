package ttt.view;

import javafx.fxml.FXML;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import ttt.model.*;

import java.net.URL;
import java.util.Observable;
import java.util.ResourceBundle;

import static ttt.view.ExceptionWindow.showException;

/**
 * This class controls the painted board view.
 * @author Caleb Solorio
 * @version 1.0 (Mar 29 2017)
 */

public class PaintedBoardController extends BoardController {

    @FXML protected Canvas canvas;

    private GraphicsContext gc;

    /**
     * Initializes the view.
     * @param location The location of the controller.
     * @param resources The resources required to initialize the controller.
     */
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        canvas.setHeight(325);
        canvas.setWidth(540);

        gc = canvas.getGraphicsContext2D();
        gc.setStroke(Color.GRAY);
        gc.setLineWidth(5);
        gc.strokeLine(0, 110, 540, 110);
        gc.strokeLine(0, 220, 540, 220);
        gc.strokeLine(180, 0, 180, 390);
        gc.strokeLine(360, 0, 360, 390);

        game = Game.getInstance();
        game.addObserver(this);
        canvas.setOnMouseClicked(e -> {
            if((game.getState() == GameState.PLAYERONETURN || game.getState() == GameState.PLAYERTWOTURN) &&
                    game.getBoard().getSquare((int) e.getY()/110, (int) e.getX()/180) == PlayerType.UNDEFINED) {
                markSquare((int) e.getY()/110, (int) e.getX()/180);
            }
        });

        update(null, game.getState());
    }

    /**
     * Updates the view.
     * @param o The Observable component
     * @param arg The object the Observable component has provided.
     */
    @Override
    public void update(Observable o, Object arg) {
        if(arg != null && arg instanceof GameState) {
            GameState state = (GameState) arg;
            Board board = game.getBoard();
            int[] winningRow = new int[0];
            if(state == GameState.PLAYERONEWIN) {
                winningRow = game.checkForWinner(PlayerType.ONE);
            } else if(state == GameState.PLAYERTWOWIN) {
                winningRow = game.checkForWinner(PlayerType.TWO);
            }
            for(int i = 0; i < 3; i++) {
                for(int j = 0; j < 3; j++) {
                    try {
                        PlayerType playerType = board.getSquare(i, j);

                        drawBackground(gc, i, j, state != GameState.PLAYERONETURN &&
                                state != GameState.PLAYERTWOTURN ? Color.LIGHTGRAY : Color.WHITESMOKE);

                        if(playerType != PlayerType.UNDEFINED) {
                            int square = i*3 + j;
                            for(int item : winningRow) {
                                if(square == item) {
                                    drawBackground(gc, i, j, Color.LIGHTYELLOW);
                                }
                            }

                            if(playerType == PlayerType.ONE) {
                                drawX(gc, i, j);
                            } else {
                                drawO(gc, i, j);
                            }
                        }
                    } catch (IllegalArgumentException e) {
                        showException(e); // Probably won't ever happen.
                    }
                }
            }
        }
    }

    private void drawX(GraphicsContext gc, int row, int column) {
        int startX = column * 180 + 50;
        int endX = startX + 80;
        int startY = row * 110 + 15;
        int endY = startY + 80;

        gc.setStroke(Color.RED);
        gc.setLineWidth(10);
        gc.strokeLine(startX, startY, endX, endY);
        gc.strokeLine(startX, endY, endX, startY);
    }

    private void drawO(GraphicsContext gc, int row, int column) {
        int startX = column * 180 + 50;
        int startY = row * 110 + 15;

        gc.setStroke(Color.BLUE);
        gc.setLineWidth(10);
        gc.strokeArc(startX, startY, 80, 80, 0, 350, ArcType.CHORD);

    }

    private void drawBackground(GraphicsContext gc, int row, int column, Color color) {
        int startX = column * 181 + 1;
        int startY = row * 110 + 1;

        gc.setFill(color);
        gc.fillRect(startX, startY, 176, 106);
    }
}
