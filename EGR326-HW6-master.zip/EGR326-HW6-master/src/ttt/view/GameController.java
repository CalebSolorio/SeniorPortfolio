package ttt.view;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import ttt.model.*;

import java.io.IOException;
import java.net.URL;
import java.util.Observable;
import java.util.Observer;
import java.util.Optional;
import java.util.ResourceBundle;

import static ttt.view.ExceptionWindow.showException;

/**
 * This class controls the highest-level view.
 * @author Caleb Solorio
 * @version 1.0 (Mar 29 2017)
 */

public class GameController implements Initializable, Observer {
    private Game game;
    private PlayerStatsController p1Stats;
    private PlayerStatsController p2Stats;

    @FXML private BorderPane container;
    @FXML private HBox statsContainer;
    @FXML private Button newGameBtn;
    @FXML private Button resetBtn;
    @FXML private Button exitBtn;
    @FXML private ToggleGroup toggleView;
    @FXML private Label prompt;

    /**
     * Initializes a new GUI and gets the game object.
     * @param location The location of any JavaFX resources required.
     * @param resources The resources required to launch the GUI.
     */
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        game = Game.getInstance();
        game.addObserver(this);

        addPlayerStats(PlayerType.ONE, game);
        addPlayerStats(PlayerType.TWO, game);

        setBoard("BUTTONS");

        newGameBtn.setOnAction(e -> startGame());
        resetBtn.setOnAction(e -> reset());
        exitBtn.setOnAction(e -> Platform.exit());
        toggleView.selectedToggleProperty().addListener((observable, oldValue, newValue) ->
                setBoard(newValue.getUserData().toString()));

        update(null, GameState.NOTSTARTED);

        Platform.runLater(() -> {
            setMnemonic(newGameBtn, KeyCode.N);
            setMnemonic(resetBtn, KeyCode.R);
            setMnemonic(exitBtn, KeyCode.X);
            setMnemonic((ToggleButton) toggleView.getToggles().get(0), KeyCode.B);
            setMnemonic((ToggleButton) toggleView.getToggles().get(1), KeyCode.P);
        });
    }

    /**
     * Updates this object based on the updated state of the Observable object.
     * @param o The observable component.
     * @param arg What the updated object has returned.
     */
    @Override
    public void update(Observable o, Object arg) {
        if(arg instanceof GameState) {
            GameState state = (GameState) arg;

            try {
                switch (state) {
                    case NOTSTARTED:
                        endGame();
                        prompt.setText("");
                        break;
                    case PLAYERONETURN:
                        prompt.setText(game.getPlayer(PlayerType.ONE).getName() + "'s Turn");
                        break;
                    case PLAYERONEWIN:
                        endGame();
                        prompt.setText(game.getPlayer(PlayerType.ONE).getName() + " wins!");
                        break;
                    case PLAYERTWOTURN:
                        prompt.setText(game.getPlayer(PlayerType.TWO).getName() + "'s Turn");
                        break;
                    case PLAYERTWOWIN:
                        endGame();
                        prompt.setText(game.getPlayer(PlayerType.TWO).getName() + " wins!");
                        break;
                    case TIE:
                        endGame();
                        prompt.setText("The game ends in a tie.");
                        break;
                }
            } catch (IllegalStateException e) {
                showException(e); // Probably won't ever happen.
            }
        }
    }

    // Adds a player stats component to the view.
    private void addPlayerStats(PlayerType playerType, Game game)  {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("playerStatsView.fxml"));
        try {
            VBox vBox = loader.load();

            if(playerType == PlayerType.ONE) {
                p1Stats = loader.getController();
                p1Stats.setProperties(playerType, game);
            } else {
                p2Stats = loader.getController();
                p2Stats.setProperties(playerType, game);
            }

            statsContainer.getChildren().add(vBox);
        } catch (IllegalArgumentException e) {
            showException(e); // Shouldn't happen under normal use.
        } catch (IOException e) {
            showException(e); // Will probably never happen.
        }
    }

    // Sets the board to be used.
    private void setBoard(String type) {
        try {
            container.centerProperty().setValue(new BoardViewFactory().createBoardView(type));
        } catch (IllegalArgumentException e) {
            showException(e); // Shouldn't happen under normal use.
        } catch (IOException e) {
            showException(e); // Will probably never happen.
        }
    }

    private void setMnemonic(ButtonBase button, KeyCode key) {
        if (button != null && key != null) {
            Scene scene = button.getScene();
            scene.getAccelerators().put(
                    new KeyCodeCombination(key, KeyCombination.ALT_DOWN),
                    () -> {
                        button.fire();
                    }
            );
        } else {
            throw new IllegalArgumentException("A scene, button, and key combination must be provided");
        }

    }

    // Changes the GUI to accommodate the start of a new game.
    private void startGame() {
        try {
            game.setPlayerName(PlayerType.ONE, p1Stats.getName());
            game.setPlayerIntelligence(PlayerType.ONE, p1Stats.getIntelligenceType());
            game.setPlayerName(PlayerType.TWO, p2Stats.getName());
            game.setPlayerIntelligence(PlayerType.TWO, p2Stats.getIntelligenceType());

            p1Stats.startGame();
            p2Stats.startGame();

            newGameBtn.setDisable(true);

            game.startGame();
        } catch (IllegalArgumentException e) {
            showException(e);
        }
    }

    // Changes the GUI to accommodate the end of a game.
    private void endGame() {
        p1Stats.endGame();
        p2Stats.endGame();

        newGameBtn.setDisable(false);
    }

    // Asks the user if they actually want to reset, then update the GUI accordingly.
    private void reset() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Are you sure?");
        alert.setHeaderText(null);
        alert.setContentText("This will end the game and set the win/loss stats to 0. Are you sure?");

        ButtonType yesBtn = new ButtonType("Yes", ButtonBar.ButtonData.YES);
        ButtonType noBtn = new ButtonType("No", ButtonBar.ButtonData.NO);

        alert.getButtonTypes().setAll(yesBtn, noBtn);
        Optional<ButtonType> result = alert.showAndWait();

        if (result.get() == yesBtn){
            try {
                game.resetGame();
            } catch (IllegalStateException e) {
                showException(e); // Probably will never happen.
            }
        }
    }
}
