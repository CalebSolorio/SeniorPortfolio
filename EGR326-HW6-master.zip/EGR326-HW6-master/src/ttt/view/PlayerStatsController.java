package ttt.view;

import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import ttt.model.Game;
import ttt.strategy.IntelligenceType;
import ttt.model.Player;
import ttt.model.PlayerType;

import java.net.URL;
import java.util.*;

import static ttt.view.ExceptionWindow.showException;

/**
 * This class controls the player stats view.
 * @author Caleb Solorio
 * @version 1.0 (Mar 29 2017)
 */

public class PlayerStatsController implements Initializable, Observer {
    PlayerType playerType;

    @FXML private Label label;
    @FXML private TextField textField;
    @FXML private ComboBox type;
    @FXML private Label wins;
    @FXML private Label losses;

    /**
     * Initializes the view.
     * @param location The location of the controller.
     * @param resources The resources required to initialize the controller.
     */
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        ObservableList<String> items = type.getItems();

        for(IntelligenceType type : IntelligenceType.values()) {
            items.add(type.toString());
        }

        type.getSelectionModel().select(0);
    }

    /**
     * Updates the view.
     * @param o The Observable component
     * @param arg The object the Observable component has provided.
     */
    @Override
    public void update(Observable o, Object arg) {
        if(arg != null && arg.getClass() == Player.class && ((Player) arg).getPlayerType() == playerType) {
            Player newPlayer = (Player) arg;
            try {
                textField.setText(newPlayer.getName());
                wins.setText(Integer.toString(newPlayer.getWins()));
                losses.setText(Integer.toString(newPlayer.getLosses()));
            } catch (IllegalStateException e) {
                showException(e); // Probably won't ever happen.
            }
        }
    }

    /**
     * Sets the different visual properties of the view.
     * @param playerType The type of player this view is summarizing.
     * @param game The game to draw information from.
     */
    public void setProperties(PlayerType playerType, Game game) {
        if(playerType != PlayerType.UNDEFINED) {
            this.playerType = playerType;
            label.setText(playerType == PlayerType.ONE ? "Player 1 (X):" : "Player 2 (O):");
            textField.setText(playerType == PlayerType.ONE ? "Player 1" : "Player 2");
            game.addObserver(this);
        } else {
            showException(new IllegalArgumentException("Player is UNDEFINED."));
        }
    }

    /**
     * Gets the name entered in the name text field.
     * @return the associated string.
     */
    public String getName() {
        return textField.getText();
    }

    /**
     * Get the intelligence type chosen by the user.
     * @return the associated Intelligence object.
     */
    public IntelligenceType getIntelligenceType() {
        try {
            return IntelligenceType.valueOf(type.getValue().toString().toUpperCase());
        } catch (IllegalArgumentException e) {
            showException(e); // Shouldn't happen under normal use.
        }

        return null;
    }

    /**
     * Adjusts the view for the start of a game.
     */
    public void startGame() {
        textField.setDisable(true);
        type.setDisable(true);
    }

    /**
     * Adjusts the view for the end of a game.
     */
    public void endGame() {
        textField.setDisable(false);
        type.setDisable(false);
    }
}
