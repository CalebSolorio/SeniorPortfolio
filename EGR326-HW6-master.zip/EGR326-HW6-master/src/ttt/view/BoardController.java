package ttt.view;

import javafx.fxml.Initializable;

import ttt.model.Game;

import java.net.URL;
import java.util.Observable;
import java.util.Observer;
import java.util.ResourceBundle;

import static ttt.view.ExceptionWindow.showException;

/**
 * This class details the core functionality of the various Board controllers.
 * @author Caleb Solorio
 * @version 1.0 (Apr 6 2017)
 */

public abstract class BoardController implements Initializable, Observer {
    protected Game game;

    /**
     * Initializes the controller
     * @param location The location of the controller.
     * @param resources The resources required to initialize the controller.
     */
    @Override
    public abstract void initialize(URL location, ResourceBundle resources);

    /**
     * Updates the controller.
     * @param o The Observable component
     * @param arg The object the Observable component has provided.
     */
    @Override
    public abstract void update(Observable o, Object arg);

    // Marks a square based on whose turn it is.
    protected void markSquare(int x, int y) throws IllegalArgumentException, IllegalStateException {
        try {
            game.markSquare(x, y);
        } catch (IllegalArgumentException e) {
            showException(e); // Probably will never happen.
        } catch (IllegalStateException e) {
            showException(e); // Probably will never happen.
        }
    }
}
